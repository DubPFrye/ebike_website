"""Part-number and material labels for etching onto cut parts.

SendCutSend's single-line etching works on laser-cut metals (6061 aluminum included) but not
on router-cut polycarbonate, so a label is only placed where the material can be etched. The
text is the part number and the material requirement, e.g. ``20S4P-BP`` / ``6061 ALUMINUM 6.35MM``.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from .contours import Circle, Polyline, bbox_gap
from .geometry import Part
from .strokefont import text_strokes, text_width

Point = tuple[float, float]

DEFAULTS = {
    "label_height_mm": 6.0,        # cap height of the etched text
    "label_margin_mm": 4.0,        # keep-out around the label from edges and cutouts
    "etch_materials": ["6061 aluminum"],
}


@dataclass(frozen=True)
class Label:
    lines: tuple[str, ...]
    etch: bool                      # True: strokes are placed and go on the etch layer
    reason: str                     # why the label is not etched (empty when it is)
    strokes: tuple[tuple[Point, ...], ...] = ()   # in part coordinates (lower-left = 0, 0)
    height_mm: float = 0.0


def dxf_settings(cfg: dict[str, Any]) -> dict[str, Any]:
    out = dict(DEFAULTS)
    out.update(cfg.get("dxf", {}))
    return out


def label_lines(part: Part) -> tuple[str, ...]:
    return (part.part_number, f"{part.material.upper()} {part.thickness_mm:g}MM")


def _inside(poly_pts: list[Point], p: Point) -> bool:
    x, y = p
    inside = False
    n = len(poly_pts)
    for i in range(n):
        (x1, y1), (x2, y2) = poly_pts[i], poly_pts[(i + 1) % n]
        if (y1 > y) != (y2 > y) and x < (x2 - x1) * (y - y1) / (y2 - y1) + x1:
            inside = not inside
    return inside


def _seg_dist(p: Point, a: Point, b: Point) -> float:
    abx, aby = b[0] - a[0], b[1] - a[1]
    d = abx * abx + aby * aby
    t = 0.0 if d == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * abx + (p[1] - a[1]) * aby) / d))
    return math.hypot(p[0] - a[0] - t * abx, p[1] - a[1] - t * aby)


def _find_spot(part: Part, w: float, h: float, margin: float) -> Point | None:
    """Lower-left corner of a w x h rectangle that is inside the part and clear of its edges
    and cutouts by ``margin``; the free spot closest to the part's center, or None."""
    outline = part.outline.points(0.05)
    x0, y0, x1, y1 = part.outline.bbox()
    cut_boxes = [c.bbox() for c in part.cutouts]
    edge = [(outline[i], outline[(i + 1) % len(outline)]) for i in range(len(outline))]
    # sample points around the label rectangle, grown by the margin
    gx, gy = w + 2 * margin, h + 2 * margin
    samples: list[tuple[float, float]] = []
    nx, ny = max(2, int(gx // 3) + 1), max(2, int(gy // 3) + 1)
    for i in range(nx + 1):
        for j in (0, ny):
            samples.append((gx * i / nx, gy * j / ny))
    for j in range(ny + 1):
        for i in (0, nx):
            samples.append((gx * i / nx, gy * j / ny))
    cx, cy = (x0 + x1) / 2, (y0 + y1) / 2
    step = 2.0
    cands = []
    px = x0 + margin
    while px + w <= x1 - margin:
        py = y0 + margin
        while py + h <= y1 - margin:
            cands.append((math.hypot(px + w / 2 - cx, py + h / 2 - cy), px, py))
            py += step
        px += step
    cands.sort()
    for _, px, py in cands:
        box = (px - margin, py - margin, px + w + margin, py + h + margin)
        if any(bbox_gap(box, cb) == 0.0 for cb in cut_boxes):
            continue
        ok = True
        for sx, sy in samples:
            p = (box[0] + sx, box[1] + sy)
            if not _inside(outline, p):
                ok = False
                break
        if ok:
            return px, py
    return None


def make_label(part: Part, cfg: dict[str, Any]) -> Label:
    """Build the etched label for a part, or explain why it is not etched."""
    s = dxf_settings(cfg)
    lines = label_lines(part)
    etchable = {m.lower() for m in s["etch_materials"]}
    if part.material.lower() not in etchable:
        return Label(lines, False, f"{part.material} cannot be etched by SendCutSend")
    height = float(s["label_height_mm"])
    gap = height * 0.5
    widths = [text_width(t, height) for t in lines]
    w = max(widths)
    h = height * len(lines) + gap * (len(lines) - 1)
    spot = _find_spot(part, w, h, float(s["label_margin_mm"]))
    if spot is None:
        return Label(lines, False, f"no clear area of {w:.0f} x {h:.0f} mm for the label on this part")
    strokes: list[tuple[Point, ...]] = []
    top = spot[1] + h
    for i, text in enumerate(lines):
        y = top - height * (i + 1) - gap * i
        x = spot[0] + (w - widths[i]) / 2           # centered block
        strokes += [tuple(st) for st in text_strokes(text, height, x, y)]
    return Label(lines, True, "", tuple(strokes), height)
