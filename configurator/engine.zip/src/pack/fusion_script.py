"""Write a copy of fusion/ebike_enclosure.py whose parameter defaults come from a config.

The Fusion script still carries its own defaults in PARAMS. For a build package we rewrite
every numeric default that maps to the config (FUSION_PARAM_MAP), so running the copy in Fusion
builds exactly the configured pack. Derived parameters are expressions and follow automatically.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import Any

from .config import FUSION_PARAM_MAP, get_path, has_base_plate, validate_config

FUSION_SCRIPT = Path(__file__).resolve().parents[2] / "fusion" / "ebike_enclosure.py"


def _fmt(value: Any) -> str:
    v = float(value)
    return str(int(v)) if v.is_integer() else repr(v)


def render_fusion_script(cfg: dict[str, Any], template: str | None = None) -> str:
    validate_config(cfg)
    src = template if template is not None else FUSION_SCRIPT.read_text(encoding="utf-8")
    from .geometry import derive_dimensions   # late import: geometry imports config, like this module
    dims = derive_dimensions(cfg)   # config values, with the small hook applied for short packs
    for name, path in FUSION_PARAM_MAP.items():
        pattern = re.compile(r"(\(\s*'" + re.escape(name) + r"',\s*')([0-9.]+)(')")
        value = getattr(dims, name.lower())
        src, n = pattern.subn(lambda m: m.group(1) + _fmt(value) + m.group(3), src, count=1)
        if n != 1:
            raise ValueError(f"parameter {name} not found in the Fusion script's PARAMS")
    src, n = re.subn(r"^BASE_PLATE = (True|False)$", f"BASE_PLATE = {has_base_plate(cfg)}", src,
                     count=1, flags=re.M)
    if n != 1:
        raise ValueError("BASE_PLATE not found in the Fusion script")
    label = cfg.get("name", "pack")
    src, n = re.subn(r"^CONFIG_NAME = ''$", f"CONFIG_NAME = {label!r}", src, count=1, flags=re.M)
    if n != 1:
        raise ValueError("CONFIG_NAME not found in the Fusion script")
    header = (f"# Generated for config '{label}' ({cfg['pack']['series']}S{cfg['pack']['parallel']}P). "
              f"Parameter defaults below come from that config.\n")
    return header + src
