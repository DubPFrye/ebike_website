"""Load and validate pack configuration files (config/*.json).

The config is the single source of truth for every dimension. Validation here catches
nonsense input (missing keys, non-positive sizes, series/parallel not matching the
layout, features that cannot be drawn). Manufacturing advice (minimum web widths and
so on) is reported separately by ``pack.geometry.check_design`` as warnings.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any


class ConfigError(ValueError):
    """The config is invalid. The message lists every problem found."""


# Fusion 360 user-parameter name -> path into the config. The Fusion script, the geometry
# module and the parity test all use this one table.
FUSION_PARAM_MAP: dict[str, tuple[str, ...]] = {
    "Columns": ("pack", "columns"),
    "Rows": ("pack", "rows"),
    "Cell_Diameter": ("cell", "diameter_mm"),
    "Cell_Height": ("cell", "height_mm"),
    "Cell_Pitch": ("pack", "cell_pitch_mm"),
    "Busbar_Height": ("pack", "busbar_height_mm"),
    "Foam_Thickness": ("pack", "foam_thickness_mm"),
    "Foam_Compression": ("pack", "foam_compression_mm"),
    "BMS_Height": ("pack", "bms_height_mm"),
    "Polycarbonate_Thickness": ("enclosure", "polycarbonate_thickness_mm"),
    "Lip_Width": ("enclosure", "lip_width_mm"),
    "Corner_Strap_Clearance": ("enclosure", "corner_strap_clearance_mm"),
    "Alu_Thickness": ("enclosure", "alu_thickness_mm"),
    "Base_Front_Extension": ("enclosure", "base_front_extension_mm"),
    "Base_Rear_Extension": ("enclosure", "base_rear_extension_mm"),
    "Side_Extension": ("enclosure", "side_extension_mm"),
    "Min_CNC_Router_Diameter": ("enclosure", "min_router_diameter_mm"),
    "Slot_Clearance": ("enclosure", "slot_clearance_mm"),
    "Tab_Shortfall": ("enclosure", "tab_shortfall_mm"),
    "Tab_Max_Spacing": ("enclosure", "tabs", "max_spacing_mm"),
    "Tab_Min_Spacing": ("enclosure", "tabs", "min_spacing_mm"),
    "Tab_Length_Ratio": ("enclosure", "tabs", "length_ratio"),
    "Tab_Min_Length": ("enclosure", "tabs", "min_length_mm"),
    "Tab_Max_Length": ("enclosure", "tabs", "max_length_mm"),
    "Cut_Overshoot": ("fusion", "cut_overshoot_mm"),
    "Bolt_Hole_Diameter": ("enclosure", "bolt_hole_diameter_mm"),
    "Standoff_OD": ("enclosure", "standoff_od_mm"),
    "Standoff_ID": ("enclosure", "standoff_id_mm"),
    "Hook_Neck_Width": ("enclosure", "hook", "neck_width_mm"),
    "Hook_Nose": ("enclosure", "hook", "nose_mm"),
    "Hook_Drop_Extra": ("enclosure", "hook", "drop_extra_mm"),
    "Hook_Overlap": ("enclosure", "hook", "overlap_mm"),
    "Hook_Slot_Length": ("enclosure", "hook", "slot_length_mm"),
    "Hook_Slot_Offset": ("enclosure", "hook", "slot_offset_mm"),
    "Hook_Slot_Clearance": ("enclosure", "hook", "slot_clearance_mm"),
    "Fillet_Large": ("enclosure", "fillet_large_mm"),
    "Fillet_Small": ("enclosure", "fillet_small_mm"),
}

# Values that may legitimately be zero (everything else numeric must be > 0).
_MAY_BE_ZERO = {
    "Base_Front_Extension", "Base_Rear_Extension", "Side_Extension", "Slot_Clearance",
    "Tab_Shortfall", "Hook_Overlap", "Hook_Slot_Offset", "Hook_Slot_Clearance",
    "Fillet_Large", "Fillet_Small", "Cut_Overshoot", "Busbar_Height", "Foam_Thickness",
    "Foam_Compression", "Corner_Strap_Clearance",
    "Standoff_ID",
}


def get_path(cfg: dict[str, Any], path: tuple[str, ...]) -> Any:
    """Read cfg[path[0]][path[1]]...; raises KeyError naming the dotted path if missing."""
    node: Any = cfg
    for i, key in enumerate(path):
        if not isinstance(node, dict) or key not in node:
            raise KeyError(".".join(path[: i + 1]))
        node = node[key]
    return node


SMALL_HOOK_KEYS = ("max_series", "neck_width_mm", "nose_mm", "drop_extra_mm", "slot_length_mm", "slot_offset_mm")


def hook_profile(cfg: dict[str, Any]) -> dict[str, Any]:
    """The hook this pack uses: enclosure.hook, with enclosure.small_hook's values laid over it
    for packs of up to small_hook.max_series cells in series (short side plates)."""
    enc = cfg["enclosure"]
    hook = dict(enc["hook"])
    small = enc.get("small_hook")
    if isinstance(small, dict) and cfg["pack"]["series"] <= small.get("max_series", 0):
        hook.update({k: v for k, v in small.items() if k != "max_series"})
    return hook


def has_base_plate(cfg: dict[str, Any]) -> bool:
    """enclosure.base_plate: with a base plate the side plates get L-hooks that latch into it.
    Without one there are no hooks and no base plate part. Missing means True."""
    return bool(cfg.get("enclosure", {}).get("base_plate", True))


def validate_config(cfg: dict[str, Any]) -> None:
    """Raise ConfigError listing every problem; return None if the config is usable."""
    errors: list[str] = []

    for name, path in FUSION_PARAM_MAP.items():
        dotted = ".".join(path)
        try:
            value = get_path(cfg, path)
        except KeyError:
            errors.append(f"missing {dotted}")
            continue
        if isinstance(value, bool) or not isinstance(value, (int, float)):
            errors.append(f"{dotted} must be a number, got {value!r}")
        elif value < 0 or (value == 0 and name not in _MAY_BE_ZERO):
            errors.append(f"{dotted} must be {'>= 0' if name in _MAY_BE_ZERO else '> 0'}, got {value}")

    for path in (("pack", "series"), ("pack", "parallel"),
                 ("enclosure", "wall_material"), ("enclosure", "base_material")):
        try:
            get_path(cfg, path)
        except KeyError:
            errors.append(f"missing {'.'.join(path)}")

    small = cfg.get("enclosure", {}).get("small_hook")
    if small is not None:
        if not isinstance(small, dict):
            errors.append("enclosure.small_hook must be an object")
        else:
            for key in SMALL_HOOK_KEYS:
                value = small.get(key)
                if key not in small:
                    errors.append(f"missing enclosure.small_hook.{key}")
                elif isinstance(value, bool) or not isinstance(value, (int, float)) or value <= 0:
                    errors.append(f"enclosure.small_hook.{key} must be a number > 0, got {value!r}")

    if not isinstance(cfg.get("enclosure", {}).get("base_plate", True), bool):
        errors.append("enclosure.base_plate must be true or false")

    if errors:  # the cross-checks below need the numbers to exist
        raise ConfigError("invalid config:\n  - " + "\n  - ".join(errors))

    g = lambda *p: get_path(cfg, p)  # noqa: E731
    if g("pack", "series") != g("pack", "columns"):
        errors.append(f"pack.series ({g('pack', 'series')}) must equal pack.columns "
                      f"({g('pack', 'columns')}): each column is one series group")
    if g("pack", "parallel") != g("pack", "rows"):
        errors.append(f"pack.parallel ({g('pack', 'parallel')}) must equal pack.rows "
                      f"({g('pack', 'rows')}): each row is one parallel cell")
    for key in ("series", "parallel", "columns", "rows"):
        if g("pack", key) != int(g("pack", key)):
            errors.append(f"pack.{key} must be a whole number")
    if g("pack", "cell_pitch_mm") < g("cell", "diameter_mm"):
        errors.append(f"pack.cell_pitch_mm ({g('pack', 'cell_pitch_mm')}) is smaller than the cell "
                      f"diameter ({g('cell', 'diameter_mm')})")

    foam, squeeze = g("pack", "foam_thickness_mm"), g("pack", "foam_compression_mm")
    if squeeze > 0 and squeeze >= foam:
        errors.append(f"pack.foam_compression_mm ({squeeze}) must be smaller than pack.foam_thickness_mm "
                      f"({foam}): the foam cannot be squeezed to nothing")

    enc = g("enclosure")
    router = enc["min_router_diameter_mm"]
    slot_width = enc["polycarbonate_thickness_mm"] + enc["slot_clearance_mm"]
    if slot_width <= router:
        errors.append(f"slot width ({slot_width:.2f} mm = thickness + clearance) must be larger than "
                      f"min_router_diameter_mm ({router}) so the dogbones do not overlap")
    tabs = enc["tabs"]
    if tabs["min_length_mm"] <= 2 * router:
        errors.append(f"enclosure.tabs.min_length_mm ({tabs['min_length_mm']}) must be longer than twice the "
                      f"router diameter ({2 * router:.2f}) to fit a dogbone at each slot end")
    if tabs["min_length_mm"] > tabs["max_length_mm"]:
        errors.append("enclosure.tabs.min_length_mm must not be larger than max_length_mm")
    if tabs["min_spacing_mm"] > tabs["max_spacing_mm"]:
        errors.append("enclosure.tabs.min_spacing_mm must not be larger than max_spacing_mm")
    if not tabs["length_ratio"] < 0.5:
        errors.append(f"enclosure.tabs.length_ratio ({tabs['length_ratio']}) must be below 0.5 so the bolt "
                      "between two tabs keeps clear of both slots")
    if enc["tab_shortfall_mm"] >= enc["polycarbonate_thickness_mm"]:
        errors.append("enclosure.tab_shortfall_mm must be smaller than the polycarbonate thickness")
    hook = hook_profile(cfg)
    hooks = has_base_plate(cfg)   # the hook checks only matter when there are hooks
    slide = hook["slot_length_mm"] - hook["slot_offset_mm"] - hook["neck_width_mm"] / 2 - hook["slot_clearance_mm"]
    if hooks and slide < 0:
        errors.append("hook slot is too short: the hook neck does not fit "  # (this pack's hook profile)
                      f"(hook.slot_length_mm - slot_offset_mm - neck_width_mm/2 - slot_clearance_mm = {slide:.2f})")
    if hooks and hook["slot_length_mm"] < hook["neck_width_mm"] + hook["nose_mm"]:
        errors.append(f"hook.slot_length_mm ({hook['slot_length_mm']}) must be at least neck_width_mm + "
                      f"nose_mm ({hook['neck_width_mm'] + hook['nose_mm']}) so the hook drops through the base plate")
    if hooks and router >= enc["alu_thickness_mm"]:
        errors.append(f"min_router_diameter_mm ({router}) is too big for the hook root relief: it must fit "
                      f"in the neck below the side plate (alu_thickness_mm = {enc['alu_thickness_mm']})")
    if hooks and enc["fillet_small_mm"] * 2 > hook["drop_extra_mm"]:
        errors.append("enclosure.fillet_small_mm is too large for the hook nose "
                      f"(needs 2 x fillet <= hook.drop_extra_mm = {hook['drop_extra_mm']})")

    if errors:
        raise ConfigError("invalid config:\n  - " + "\n  - ".join(errors))


def load_config(path: str | Path) -> dict[str, Any]:
    """Read a config JSON file and validate it."""
    try:
        with open(path, encoding="utf-8") as fh:
            cfg = json.load(fh)
    except json.JSONDecodeError as exc:
        raise ConfigError(f"{path} is not valid JSON: {exc}") from exc
    validate_config(cfg)
    return cfg
