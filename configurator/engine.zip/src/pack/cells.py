"""Cell catalog (data/cells.csv) and the electrical specs of a pack built from it."""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

from .config import ConfigError

DEFAULT_CELLS = Path(__file__).resolve().parents[2] / "data" / "cells.csv"


@dataclass(frozen=True)
class Cell:
    key: str
    name: str
    format: str
    diameter_mm: float
    height_mm: float
    capacity_ah: float
    max_continuous_a: float
    grams: float
    nominal_v: float
    max_v: float


def load_cells(path: str | Path = DEFAULT_CELLS) -> dict[str, Cell]:
    """Read the cell catalog into {key: Cell}, failing with a clear message on a bad row."""
    cells: dict[str, Cell] = {}
    with open(path, newline="", encoding="utf-8") as fh:
        for row in csv.DictReader(fh):
            key = row["key"].strip()
            try:
                cells[key] = Cell(
                    key=key, name=row["name"].strip(), format=row["format"].strip(),
                    **{f: float(row[f]) for f in ("diameter_mm", "height_mm", "capacity_ah",
                                                    "max_continuous_a", "grams", "nominal_v", "max_v")})
            except (KeyError, ValueError) as exc:
                raise ConfigError(f"{path}: bad row for cell {key!r}: {exc}") from None
    if not cells:
        raise ConfigError(f"{path} has no cells")
    return cells


def apply_cell(cfg: dict, cell: Cell) -> None:
    """Put the cell's geometry into a config (in place)."""
    cfg["cell"] = {"key": cell.key, "name": cell.name, "format": cell.format,
                   "diameter_mm": cell.diameter_mm, "height_mm": cell.height_mm}


def pack_specs(cell: Cell, series: int, parallel: int) -> dict[str, float]:
    """Nominal electrical specs (cells only: no BMS, nickel, enclosure or wiring)."""
    v_nom = series * cell.nominal_v
    ah = parallel * cell.capacity_ah
    return {
        "nominal_v": round(v_nom, 1),
        "max_v": round(series * cell.max_v, 1),
        "capacity_ah": round(ah, 1),
        "energy_wh": round(v_nom * ah),
        "max_continuous_a": round(parallel * cell.max_continuous_a),
        "cells": series * parallel,
        "cell_weight_kg": round(series * parallel * cell.grams / 1000, 2),
    }
