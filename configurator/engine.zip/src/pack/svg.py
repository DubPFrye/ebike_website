"""Draw a flat part as an SVG string (for the web page preview). Units are mm."""
from __future__ import annotations

from html import escape

from .contours import Circle, Polyline, Shape
from .geometry import Part


def _path(shape: Shape, height: float) -> str:
    """SVG path data with Y flipped (DXF/geometry Y points up, SVG Y points down)."""
    if isinstance(shape, Circle):
        cx, cy, r = shape.cx, height - shape.cy, shape.r
        return (f"M{cx - r:.3f},{cy:.3f}a{r:.3f},{r:.3f} 0 1,0 {2 * r:.3f},0"
                f"a{r:.3f},{r:.3f} 0 1,0 {-2 * r:.3f},0Z")
    pts = shape.points(tol=0.05)
    return "M" + "L".join(f"{x:.3f},{height - y:.3f}" for x, y in pts) + "Z"


def part_svg(part: Part, margin: float = 4.0) -> str:
    """The part outline with its cutouts as holes (even-odd fill), sized to the part."""
    w, h = part.size
    d = " ".join([_path(part.outline, h)] + [_path(c, h) for c in part.cutouts])
    title = escape(f"{part.part_number} {part.description}: {w:.1f} x {h:.1f} mm")
    return (f'<svg xmlns="http://www.w3.org/2000/svg" viewBox="{-margin} {-margin} {w + 2 * margin:.3f} '
            f'{h + 2 * margin:.3f}" role="img"><title>{title}</title>'
            f'<path class="part" fill-rule="evenodd" d="{d}"/></svg>')
