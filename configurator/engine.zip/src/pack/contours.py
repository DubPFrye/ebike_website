"""2D contour primitives for flat (cut-from-sheet) parts. Pure Python, millimeters.

A ``Polyline`` is a closed contour of ``(x, y, bulge)`` vertices, the same convention as a
DXF polyline: the bulge on a vertex describes the segment from that vertex to the next.
bulge = 0 is a straight line; bulge = tan(sweep / 4), positive for a counter-clockwise arc.
Arcs therefore stay true arcs all the way to the output file.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Iterator, Sequence

Point = tuple[float, float]
Vertex = tuple[float, float, float]
BBox = tuple[float, float, float, float]  # xmin, ymin, xmax, ymax

_TWO_PI = 2 * math.pi


def arc_geometry(p1: Point, p2: Point, bulge: float) -> tuple[Point, float, float, float]:
    """Return (center, radius, start_angle, signed_sweep) of the arc from p1 to p2."""
    dx, dy = p2[0] - p1[0], p2[1] - p1[1]
    chord = math.hypot(dx, dy)
    sweep = 4 * math.atan(bulge)
    radius = chord / (2 * math.sin(abs(sweep) / 2))
    offset = (chord / 2) * (1 - bulge * bulge) / (2 * bulge)   # along the left normal of p1 -> p2
    cx = (p1[0] + p2[0]) / 2 + (-dy / chord) * offset
    cy = (p1[1] + p2[1]) / 2 + (dx / chord) * offset
    return (cx, cy), radius, math.atan2(p1[1] - cy, p1[0] - cx), sweep


@dataclass(frozen=True)
class Circle:
    cx: float
    cy: float
    r: float

    def bbox(self) -> BBox:
        return (self.cx - self.r, self.cy - self.r, self.cx + self.r, self.cy + self.r)

    def translated(self, dx: float, dy: float) -> "Circle":
        return Circle(self.cx + dx, self.cy + dy, self.r)

    def area(self) -> float:
        return math.pi * self.r ** 2

    def points(self, tol: float = 0.02) -> list[Point]:
        n = 128
        return [(self.cx + self.r * math.cos(_TWO_PI * i / n),
                 self.cy + self.r * math.sin(_TWO_PI * i / n)) for i in range(n)]


@dataclass(frozen=True)
class Polyline:
    """A closed contour. Orientation is counter-clockwise for outer boundaries."""
    vertices: tuple[Vertex, ...]

    def segments(self) -> Iterator[tuple[Point, Point, float]]:
        n = len(self.vertices)
        for i in range(n):
            x1, y1, b = self.vertices[i]
            x2, y2, _ = self.vertices[(i + 1) % n]
            yield (x1, y1), (x2, y2), b

    def bbox(self) -> BBox:
        xs = [v[0] for v in self.vertices]
        ys = [v[1] for v in self.vertices]
        xmin, ymin, xmax, ymax = min(xs), min(ys), max(xs), max(ys)
        for p1, p2, b in self.segments():
            if b == 0:
                continue
            (cx, cy), r, a1, sweep = arc_geometry(p1, p2, b)
            for k, (ex, ey) in enumerate(((r, 0), (0, r), (-r, 0), (0, -r))):
                axis = k * math.pi / 2
                delta = (axis - a1) % _TWO_PI if sweep > 0 else (a1 - axis) % _TWO_PI
                if delta <= abs(sweep):
                    xmin, xmax = min(xmin, cx + ex), max(xmax, cx + ex)
                    ymin, ymax = min(ymin, cy + ey), max(ymax, cy + ey)
        return xmin, ymin, xmax, ymax

    def area(self) -> float:
        """Enclosed area (positive for counter-clockwise), arcs included."""
        total = 0.0
        for (x1, y1), (x2, y2), b in self.segments():
            total += (x1 * y2 - x2 * y1) / 2
            if b != 0:
                _, r, _, sweep = arc_geometry((x1, y1), (x2, y2), b)
                seg = r * r / 2 * (abs(sweep) - math.sin(abs(sweep)))
                total += seg if b > 0 else -seg
        return total

    def translated(self, dx: float, dy: float) -> "Polyline":
        return Polyline(tuple((x + dx, y + dy, b) for x, y, b in self.vertices))

    def rotated90(self) -> "Polyline":
        """Rotate 90 degrees counter-clockwise about the origin."""
        return Polyline(tuple((-y, x, b) for x, y, b in self.vertices))

    def points(self, tol: float = 0.02) -> list[Point]:
        """Flatten arcs into straight segments no further than ``tol`` mm from the true arc."""
        pts: list[Point] = []
        for p1, p2, b in self.segments():
            pts.append(p1)
            if b == 0:
                continue
            (cx, cy), r, a1, sweep = arc_geometry(p1, p2, b)
            step = 2 * math.acos(max(0.0, 1 - tol / r)) if r > tol else math.pi / 2
            n = max(2, math.ceil(abs(sweep) / step))
            for i in range(1, n):
                a = a1 + sweep * i / n
                pts.append((cx + r * math.cos(a), cy + r * math.sin(a)))
        return pts


Shape = Polyline | Circle


# ---------------------------------------------------------------------------------------
# Builders
# ---------------------------------------------------------------------------------------
def rectangle(x0: float, y0: float, x1: float, y1: float) -> Polyline:
    return Polyline(((x0, y0, 0.0), (x1, y0, 0.0), (x1, y1, 0.0), (x0, y1, 0.0)))


def fillet_polygon(corners: Sequence[tuple[float, float, float]]) -> Polyline:
    """Build a closed polyline from counter-clockwise ``(x, y, fillet_radius)`` corners.

    A corner with radius > 0 is replaced by a tangent arc (convex or concave).
    """
    n = len(corners)
    info = []  # per corner: unit vector to prev, unit vector to next, tangent length, phi
    for i, (x, y, r) in enumerate(corners):
        if r <= 0:
            info.append(None)
            continue
        px, py, _ = corners[i - 1]
        qx, qy, _ = corners[(i + 1) % n]
        l1, l2 = math.hypot(px - x, py - y), math.hypot(qx - x, qy - y)
        u1, u2 = ((px - x) / l1, (py - y) / l1), ((qx - x) / l2, (qy - y) / l2)
        phi = math.acos(max(-1.0, min(1.0, u1[0] * u2[0] + u1[1] * u2[1])))
        info.append((u1, u2, r / math.tan(phi / 2), phi))

    def edge_len(i: int) -> float:
        a, b = corners[i], corners[(i + 1) % n]
        return math.hypot(b[0] - a[0], b[1] - a[1])

    for i in range(n):
        used = (info[i][2] if info[i] else 0.0) + (info[(i + 1) % n][2] if info[(i + 1) % n] else 0.0)
        if used > edge_len(i) + 1e-9:
            raise ValueError(f"fillets on the edge starting at ({corners[i][0]:.2f}, {corners[i][1]:.2f}) "
                             f"need {used:.2f} mm but the edge is only {edge_len(i):.2f} mm long")

    out: list[Vertex] = []
    for i, (x, y, r) in enumerate(corners):
        if info[i] is None:
            out.append((x, y, 0.0))
            continue
        u1, u2, t, phi = info[i]
        px, py, _ = corners[i - 1]
        qx, qy, _ = corners[(i + 1) % n]
        cross = (x - px) * (qy - y) - (y - py) * (qx - x)   # > 0: left turn (convex when CCW)
        bulge = math.tan((math.pi - phi) / 4) * (1 if cross > 0 else -1)
        out.append((x + u1[0] * t, y + u1[1] * t, bulge))
        out.append((x + u2[0] * t, y + u2[1] * t, 0.0))
    return Polyline(tuple(out))


def rounded_rectangle(x0: float, y0: float, x1: float, y1: float, radius: float) -> Polyline:
    """Rectangle with all four corners filleted (radius 0 gives a plain rectangle)."""
    return fillet_polygon([(x0, y0, radius), (x1, y0, radius), (x1, y1, radius), (x0, y1, radius)])


def rect_with_tabs(width: float, depth: float, tab_centers: Sequence[float],
                   tab_length: float, tab_depth: float, relief: float = 0.0) -> Polyline:
    """Rectangle centered on the origin (``width`` along x, ``depth`` along y) with a tab of
    ``tab_length`` x ``tab_depth`` sticking out of each long edge at every x in ``tab_centers``.

    ``relief`` > 0 (a router radius) adds a relief at both inside corners of every tab: a
    semicircle centered on the wall edge, tangent to the tab side, cut into the wall body. The
    tab keeps its full length and width, and the router leaves no radius in the corner, so the
    side plate seats right against the wall edge.
    """
    centers = sorted(tab_centers)
    hw, hd, hl, r = width / 2, depth / 2, tab_length / 2, relief
    for a, b in zip(centers, centers[1:]):
        if b - a < tab_length + 4 * r:
            raise ValueError("tabs overlap")
    if centers and (centers[0] - hl - 2 * r < -hw or centers[-1] + hl + 2 * r > hw):
        raise ValueError("a tab sticks out past the end of the wall")
    arc = -1.0 if r else 0.0     # clockwise on this counter-clockwise outline: into the body
    pts: list[Vertex] = [(-hw, -hd, 0.0)]
    for c in centers:            # bottom edge, left to right
        if r:
            pts.append((c - hl - 2 * r, -hd, arc))
        pts += [(c - hl, -hd, 0.0), (c - hl, -hd - tab_depth, 0.0),
                (c + hl, -hd - tab_depth, 0.0), (c + hl, -hd, arc)]
        if r:
            pts.append((c + hl + 2 * r, -hd, 0.0))
    pts += [(hw, -hd, 0.0), (hw, hd, 0.0)]
    for c in reversed(centers):  # top edge, right to left
        if r:
            pts.append((c + hl + 2 * r, hd, arc))
        pts += [(c + hl, hd, 0.0), (c + hl, hd + tab_depth, 0.0),
                (c - hl, hd + tab_depth, 0.0), (c - hl, hd, arc)]
        if r:
            pts.append((c - hl - 2 * r, hd, 0.0))
    pts.append((-hw, hd, 0.0))
    return Polyline(tuple(pts))


def slot_with_dogbones(cx: float, cy: float, length: float, width: float,
                       dogbone_diameter: float, vertical: bool = False) -> Polyline:
    """A rectangular slot with a router-relief circle at each corner, as one merged contour.

    Each circle is centered on a long edge of the slot, one radius in from the short end, so it
    is tangent to the short end: the end stays flat across the full slot width and the tab
    corner seats against it. The relief bulges outward into the material beside the slot.
    """
    r = dogbone_diameter / 2
    if width <= dogbone_diameter:
        raise ValueError("slot is not wider than the dogbone circle")
    if length <= 2 * dogbone_diameter:
        raise ValueError("slot is too short to fit a dogbone at each end")
    x0, x1, y0, y1 = -length / 2, length / 2, -width / 2, width / 2
    d = 2 * r
    poly = Polyline((
        (x0, y0, 1.0), (x0 + d, y0, 0.0),        # lower-left dogbone, then straight along the bottom edge
        (x1 - d, y0, 1.0), (x1, y0, 0.0),        # lower-right dogbone
        (x1, y1, 1.0), (x1 - d, y1, 0.0),        # flat right end, upper-right dogbone
        (x0 + d, y1, 1.0), (x0, y1, 0.0),        # top edge, upper-left dogbone, flat left end
    ))
    if vertical:
        poly = poly.rotated90()
    return poly.translated(cx, cy)


# ---------------------------------------------------------------------------------------
# Distances (used for manufacturing checks)
# ---------------------------------------------------------------------------------------
def shape_bbox(shape: Shape) -> BBox:
    return shape.bbox()


def bbox_gap(a: BBox, b: BBox) -> float:
    dx = max(a[0] - b[2], b[0] - a[2], 0.0)
    dy = max(a[1] - b[3], b[1] - a[3], 0.0)
    return math.hypot(dx, dy)


def _point_segment(p: Point, a: Point, b: Point) -> float:
    abx, aby = b[0] - a[0], b[1] - a[1]
    denom = abx * abx + aby * aby
    t = 0.0 if denom == 0 else max(0.0, min(1.0, ((p[0] - a[0]) * abx + (p[1] - a[1]) * aby) / denom))
    return math.hypot(p[0] - (a[0] + t * abx), p[1] - (a[1] + t * aby))


def min_gap(a: Shape, b: Shape, cap: float = math.inf) -> float:
    """Smallest distance between the boundaries of two shapes (not for overlapping shapes).

    With ``cap``, only gaps smaller than ``cap`` are measured exactly: points and segments further
    than ``cap`` from the other shape's bounding box are skipped (the closest pair of a gap under
    ``cap`` always lies inside that window), and a gap of ``cap`` or more may come back as any
    value >= ``cap`` (inf if nothing is in range). This keeps the web check fast on big plates."""
    pa, pb = a.points(), b.points()
    ba, bb = a.bbox(), b.bbox()
    best = math.inf
    for src, dst, b_src, b_dst in ((pa, pb, ba, bb), (pb, pa, bb, ba)):
        n = len(dst)
        segs = [(dst[i], dst[(i + 1) % n]) for i in range(n)]
        if cap != math.inf:
            segs = [(p, q) for p, q in segs
                    if bbox_gap((min(p[0], q[0]), min(p[1], q[1]), max(p[0], q[0]), max(p[1], q[1])), b_src) < cap]
            src = [p for p in src if bbox_gap((p[0], p[1], p[0], p[1]), b_dst) < cap]
        for p in src:
            for s0, s1 in segs:
                d = _point_segment(p, s0, s1)
                if d < best:
                    best = d
    return best
