"""Pack and enclosure geometry in plain Python: dimensions, layout and flat part outlines.

Nothing here depends on Fusion 360. The Fusion script, the DXF generator and the BOM all
read the same numbers from here, and everything is computed from one config dict
(see ``pack.config``). Units are millimeters.

Model frame (matches the Fusion script): X = pack length along the bike (front = +X,
rear = -X), Y = height, Z = cell length. Side plates lie in the XY plane at +/-Z.
"""
from __future__ import annotations

import math
from dataclasses import dataclass
from typing import Any

from .config import FUSION_PARAM_MAP, get_path, has_base_plate, hook_profile, validate_config
from .contours import (
    Circle, Polyline, Shape, bbox_gap, fillet_polygon, min_gap, rect_with_tabs,
    rectangle, rounded_rectangle, slot_with_dogbones,
)

SCS_MIN_ROUTED_FEATURE_MM = 3.175   # 0.125 in: smallest cutout SendCutSend routes
SCS_MIN_WEB_FACTOR = 2.0            # minimum web (bridge) between features, x material thickness


@dataclass(frozen=True)
class Dimensions:
    """Every parameter, named as the lower-case form of its Fusion user parameter."""
    # --- inputs ---
    columns: int
    rows: int
    cell_diameter: float
    cell_height: float
    cell_pitch: float
    busbar_height: float
    foam_thickness: float
    bms_height: float
    polycarbonate_thickness: float
    lip_width: float
    alu_thickness: float
    base_front_extension: float
    base_rear_extension: float
    side_extension: float
    min_cnc_router_diameter: float
    slot_clearance: float
    tab_shortfall: float
    cut_overshoot: float
    bolt_hole_diameter: float
    standoff_od: float
    standoff_id: float
    hook_neck_width: float
    hook_nose: float
    hook_drop_extra: float
    hook_overlap: float
    hook_slot_length: float
    hook_slot_offset: float
    hook_slot_clearance: float
    fillet_large: float
    fillet_small: float
    # --- derived ---
    bolt_edge_offset: float
    side_plate_corner_radius: float
    slot_width: float
    tab_depth: float
    hook_drop: float
    core_depth: float
    cavity_depth: float
    cell_core_width: float
    cell_core_height: float
    cavity_width: float
    cavity_height: float
    plate_width: float
    plate_height: float
    base_plate_x_length: float
    base_plate_z_width: float
    battery_latch_slide: float
    # --- wall-tab rule (enclosure.tabs) ---
    tab_max_spacing: float = 125.0
    tab_min_spacing: float = 50.0
    tab_length_ratio: float = 0.33
    tab_min_length: float = 15.0
    tab_max_length: float = 40.0
    base_plate: bool = True        # False: no base plate and no hooks


def derive_dimensions(cfg: dict[str, Any]) -> Dimensions:
    """Validate the config and compute every dimension (same formulas as the Fusion script)."""
    validate_config(cfg)
    v: dict[str, Any] = {name.lower(): get_path(cfg, path) for name, path in FUSION_PARAM_MAP.items()}
    v["columns"], v["rows"] = int(v["columns"]), int(v["rows"])
    # Short packs use the small hook profile (enclosure.small_hook) in place of enclosure.hook
    for key, value in hook_profile(cfg).items():
        v["hook_" + key.removesuffix("_mm")] = value
    f = lambda k: float(v[k])  # noqa: E731

    # Standoffs sit tangent to the outside of the inner walls (they brace them)
    v["bolt_edge_offset"] = f("lip_width") - f("standoff_od") / 2
    # Side-plate corner arcs are centered on the corner bolts, so the web from the corner bolt
    # hole to the plate edge equals the web along the straight edges.
    v["side_plate_corner_radius"] = v["bolt_edge_offset"]
    v["slot_width"] = f("polycarbonate_thickness") + f("slot_clearance")
    v["tab_depth"] = f("polycarbonate_thickness") - f("tab_shortfall")
    v["hook_drop"] = f("alu_thickness") + f("hook_drop_extra")
    v["core_depth"] = f("cell_height") + 2 * f("busbar_height")
    v["cavity_depth"] = v["core_depth"] + 2 * f("foam_thickness")
    v["cell_core_width"] = v["columns"] * f("cell_pitch")
    v["cell_core_height"] = v["rows"] * f("cell_pitch")
    v["cavity_width"] = v["cell_core_width"] + 2 * f("foam_thickness")
    v["cavity_height"] = v["cell_core_height"] + f("bms_height") + 2 * f("foam_thickness")
    v["plate_width"] = v["cavity_width"] + 2 * f("polycarbonate_thickness") + 2 * f("lip_width")
    v["plate_height"] = v["cavity_height"] + 2 * f("polycarbonate_thickness") + 2 * f("lip_width")
    v["base_plate_x_length"] = v["plate_width"] + f("base_front_extension") + f("base_rear_extension")
    v["base_plate_z_width"] = v["cavity_depth"] + 2 * f("polycarbonate_thickness") + 2 * f("side_extension")
    v["battery_latch_slide"] = (f("hook_slot_length") - f("hook_slot_offset")
                                - f("hook_neck_width") / 2 - f("hook_slot_clearance"))
    v["base_plate"] = has_base_plate(cfg)
    return Dimensions(**v)


@dataclass(frozen=True)
class EdgeTabs:
    """Tabs along one edge of the side plate, spaced evenly between its two corner bolts."""
    span: float                     # corner bolt to corner bolt
    pitch: float                    # bolt spacing = tab spacing = span / count
    length: float                   # tab (and slot) length
    centers: tuple[float, ...]      # tab centers, relative to the edge's middle
    bolts: tuple[float, ...]        # bolt positions along the edge, corners included


def edge_tabs(span: float, d: Dimensions, min_count: int = 1) -> EdgeTabs:
    """The tab rule: bolt, tab, bolt, tab, ..., bolt, all evenly spaced.

    count  = fewest tabs that keep the pitch <= tab_max_spacing; at least 2 unless that would
             make the pitch smaller than tab_min_spacing (very short edges get 1), and never
             fewer than min_count (the long edges always get 2)
    pitch  = span / count; tabs sit midway between bolts, bolts at the corners and between tabs
    length = tab_length_ratio x pitch, clamped to [tab_min_length, tab_max_length], to 0.5 mm
    """
    n = max(1, math.ceil(span / d.tab_max_spacing - 1e-9))
    if n < 2 and span / 2 >= d.tab_min_spacing:
        n = 2
    n = max(n, min_count)
    pitch = span / n
    if n == 2 and pitch < d.tab_min_spacing:
        # Tight edge (two tabs forced onto a very short edge, 1-3S): no bolt between the tabs,
        # shorter tabs (as short as the dogbones allow), and the tabs placed so the gap between
        # the two slots matches the gap from each slot to its corner bolt hole.
        length = max(2 * d.min_cnc_router_diameter + 3.0, d.tab_length_ratio * pitch)
        length = round(length * 2) / 2
        c = (span / 2 + length / 2 - d.bolt_hole_diameter / 2) / 3
        return EdgeTabs(span, pitch, length, (-c, c), (-span / 2, span / 2))
    length = min(d.tab_max_length, max(d.tab_min_length, d.tab_length_ratio * pitch))
    length = round(length * 2) / 2
    centers = tuple(-span / 2 + (i + 0.5) * pitch for i in range(n))
    bolts = tuple(-span / 2 + i * pitch for i in range(n + 1))
    return EdgeTabs(span, pitch, length, centers, bolts)


def _hooks_fit(hook_xs: tuple[float, ...], d: Dimensions) -> bool:
    """Neighbouring base-plate slots keep at least one plate thickness of aluminum between them,
    and every hook neck (with its corner reliefs) stays on the straight part of the side plate's
    bottom edge."""
    gap = min(b - a for a, b in zip(hook_xs, hook_xs[1:])) - d.hook_slot_length
    straight = d.plate_width / 2 - d.side_plate_corner_radius
    return gap >= d.alu_thickness and max(abs(x) for x in hook_xs) + d.hook_neck_width / 2 + d.min_cnc_router_diameter <= straight


@dataclass(frozen=True)
class Layout:
    """Positions that depend on the pack size (all relative to the cavity center)."""
    long_edge: EdgeTabs                             # top / bottom edges: long-wall tabs along X
    short_edge: EdgeTabs                            # left / right edges: short-wall tabs along Y
    hook_xs: tuple[float, ...]                      # L-hook centers along X: one under each bottom tab
                                                    # (none without a base plate)
    bolt_points: tuple[tuple[float, float], ...]    # bolt / standoff centers in the side plate

    @property
    def tab_xs(self) -> tuple[float, ...]:
        return self.long_edge.centers

    @property
    def short_tab_ys(self) -> tuple[float, ...]:
        return self.short_edge.centers


def derive_layout(d: Dimensions) -> Layout:
    bx = d.plate_width / 2 - d.bolt_edge_offset
    by = d.plate_height / 2 - d.bolt_edge_offset
    long_edge, short_edge = edge_tabs(2 * bx, d, min_count=2), edge_tabs(2 * by, d)
    # One hook per bottom tab at the even pitch (under the tab, midway between two bolts), so the
    # hooks scale with the pack. On a tight edge the tabs are pulled in; the hooks stay spread out.
    even = tuple(-long_edge.span / 2 + (i + 0.5) * long_edge.pitch for i in range(len(long_edge.centers)))
    hook_xs: tuple[float, ...] = even if d.base_plate else ()
    if len(hook_xs) > 1 and not _hooks_fit(hook_xs, d):
        hook_xs = (0.0,)   # tiny plate: two hooks' base-plate slots would leave no web between them
    # Bolts at the corners and midway between tabs on every edge (the standoffs hug the walls)
    side_ys = short_edge.bolts[1:-1]   # corners are already in the top / bottom rows
    bolts = tuple([(x, by) for x in long_edge.bolts] + [(x, -by) for x in long_edge.bolts]
                  + [(-bx, y) for y in side_ys] + [(bx, y) for y in side_ys])
    return Layout(long_edge, short_edge, hook_xs, bolts)


@dataclass(frozen=True)
class Part:
    """One flat part, ready to cut. Coordinates have their lower-left bounding corner at (0, 0)."""
    key: str                      # 'side_plate', 'long_wall', ...
    part_number: str              # e.g. '20S4P-SP'
    description: str
    material: str                 # e.g. 'Polycarbonate'
    thickness_mm: float
    quantity: int
    process: str                  # 'cnc_router' or 'laser'
    outline: Polyline
    cutouts: tuple[Shape, ...]
    origin: tuple[float, float]   # model-frame position of the flat part's (0, 0)

    @property
    def size(self) -> tuple[float, float]:
        x0, y0, x1, y1 = self.outline.bbox()
        return (x1 - x0, y1 - y0)


def _title(material: str) -> str:
    return material.title() if material.islower() else material


def _process(material: str) -> str:
    return "cnc_router" if "polycarbonate" in material.lower() else "laser"


def _normalized(outline: Polyline, cutouts: list[Shape]) -> tuple[Polyline, tuple[Shape, ...], tuple[float, float]]:
    x0, y0, _, _ = outline.bbox()
    return (outline.translated(-x0, -y0),
            tuple(c.translated(-x0, -y0) for c in cutouts),
            (x0, y0))


def _slot(cx: float, cy: float, length: float, width: float, d: Dimensions,
          router: bool, vertical: bool = False) -> Polyline:
    """A through-slot; routed parts get dogbone reliefs, laser parts a plain rectangle."""
    if router:
        return slot_with_dogbones(cx, cy, length, width, d.min_cnc_router_diameter, vertical)
    w, h = (width, length) if vertical else (length, width)
    return rectangle(cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2)


def _with_hook_root_reliefs(outline: Polyline, hook_xs: tuple[float, ...], half_neck: float,
                            y_nose_top: float, r: float) -> Polyline:
    """Add a router-diameter relief at each hook's inside corner (neck meets nose top).

    The circle is centered on the neck's inside edge and tangent to the nose top, so it cuts only
    upward into the neck: the nose top stays flat for the base plate and the nose keeps its full
    height. In the outline the neck edge stops one diameter above the nose top and a semicircle
    (bulge -1: clockwise, bulging into the neck) runs down to the corner."""
    corners = {(round(hx - half_neck, 9), round(y_nose_top, 9)) for hx in hook_xs}
    out: list[tuple[float, float, float]] = []
    for x, y, b in outline.vertices:
        if (round(x, 9), round(y, 9)) in corners:
            out.append((x, y + 2 * r, -1.0))
        out.append((x, y, b))
    return Polyline(tuple(out))


def _with_hook_neck_reliefs(outline: Polyline, hook_xs: tuple[float, ...], half_neck: float,
                            y_edge: float, r: float) -> Polyline:
    """Add a router-diameter relief where each hook neck meets the plate's bottom edge.

    Same idea as the wall-tab reliefs: a semicircle centered on the bottom edge, tangent to the
    neck side, cut up into the plate. The router then leaves no radius in the corner, so the side
    plate seats flat on the base plate."""
    left = {(round(hx - half_neck, 9), round(y_edge, 9)) for hx in hook_xs}
    right = {(round(hx + half_neck, 9), round(y_edge, 9)) for hx in hook_xs}
    out: list[tuple[float, float, float]] = []
    for x, y, b in outline.vertices:
        key = (round(x, 9), round(y, 9))
        if key in left:          # the edge runs +x into the neck: arc ends at the neck side
            out += [(x - 2 * r, y, -1.0), (x, y, b)]
        elif key in right:       # coming up the neck side: arc starts at the corner
            out += [(x, y, -1.0), (x + 2 * r, y, b)]
        else:
            out.append((x, y, b))
    return Polyline(tuple(out))


def build_parts(cfg: dict[str, Any]) -> list[Part]:
    """All distinct cut parts for the pack: side plate, long wall, short wall, base plate (if any)."""
    d = derive_dimensions(cfg)
    lay = derive_layout(d)
    enc = cfg["enclosure"]
    pack_code = f"{cfg['pack']['series']}S{cfg['pack']['parallel']}P"
    wall_mat, base_mat = _title(enc["wall_material"]), _title(enc["base_material"])
    wall_router = _process(wall_mat) == "cnc_router"
    base_router = _process(base_mat) == "cnc_router"
    pct, alu = d.polycarbonate_thickness, d.alu_thickness
    parts: list[Part] = []

    # ---- Side plate (x2: front and rear are identical flat parts) --------------------
    pw2, ph2 = d.plate_width / 2, d.plate_height / 2
    cw2, ch2 = d.cavity_width / 2, d.cavity_height / 2
    nk, sm = d.hook_neck_width / 2, d.fillet_small
    rc = d.side_plate_corner_radius
    corners: list[tuple[float, float, float]] = [(-pw2, -ph2, rc)]
    for hx in sorted(lay.hook_xs):   # L-hooks along the bottom edge, nose pointing -X
        y_nose_top, y_low = -ph2 - alu, -ph2 - d.hook_drop
        corners += [
            (hx - nk, -ph2, 0.0), (hx - nk, y_nose_top, 0.0),
            (hx - nk - d.hook_nose, y_nose_top, sm), (hx - nk - d.hook_nose, y_low, sm),
            (hx + nk, y_low, sm), (hx + nk, -ph2, 0.0),
        ]
    corners += [(pw2, -ph2, rc), (pw2, ph2, rc), (-pw2, ph2, rc)]
    r_wall = d.min_cnc_router_diameter / 2 if wall_router else 0.0   # inside-corner reliefs
    outline = _with_hook_root_reliefs(fillet_polygon(corners), lay.hook_xs, nk, -ph2 - alu,
                                      d.min_cnc_router_diameter / 2)
    if r_wall:
        outline = _with_hook_neck_reliefs(outline, lay.hook_xs, nk, -ph2, r_wall)

    cuts: list[Shape] = []
    slot_y = ch2 + pct / 2
    for tx in lay.tab_xs:
        for sy in (-slot_y, slot_y):
            cuts.append(_slot(tx, sy, lay.long_edge.length, d.slot_width, d, wall_router))
    slot_x = cw2 + pct / 2
    for sx in (-slot_x, slot_x):
        for ty in lay.short_tab_ys:
            cuts.append(_slot(sx, ty, lay.short_edge.length, d.slot_width, d, wall_router, vertical=True))
    cuts += [Circle(bx, by, d.bolt_hole_diameter / 2) for bx, by in lay.bolt_points]
    o, c, org = _normalized(outline, cuts)
    parts.append(Part("side_plate", f"{pack_code}-SP", "Side plate", wall_mat, pct, 2,
                      _process(wall_mat), o, c, org))

    # ---- Long wall (x2: top and bottom are identical) ---------------------------------
    o, c, org = _normalized(
        rect_with_tabs(d.cavity_width + 2 * pct, d.cavity_depth, lay.tab_xs, lay.long_edge.length, d.tab_depth, r_wall), [])
    parts.append(Part("long_wall", f"{pack_code}-LW", "Long wall (top / bottom)", wall_mat, pct, 2,
                      _process(wall_mat), o, c, org))

    # ---- Short wall (x2: left and right are identical) --------------------------------
    o, c, org = _normalized(
        rect_with_tabs(d.cavity_height, d.cavity_depth,
                       lay.short_tab_ys, lay.short_edge.length, d.tab_depth, r_wall), [])
    parts.append(Part("short_wall", f"{pack_code}-SW", "Short wall (left / right)", wall_mat, pct, 2,
                      _process(wall_mat), o, c, org))

    # ---- Base plate (x1) --------------------------------------------------------------
    if not d.base_plate:
        return parts
    slide = d.battery_latch_slide
    bx0 = -(pw2 + d.base_rear_extension + slide)
    bx1 = pw2 + d.base_front_extension - slide
    bz = d.base_plate_z_width / 2
    outline = rounded_rectangle(bx0, -bz, bx1, bz, d.fillet_large)
    cuts = []
    z_slot = d.cavity_depth / 2 + pct / 2
    for hx in lay.hook_xs:
        xa, xb = hx - (d.hook_slot_length - d.hook_slot_offset), hx + d.hook_slot_offset
        for zc in (-z_slot, z_slot):
            cuts.append(_slot(( xa + xb) / 2, zc, d.hook_slot_length, d.slot_width, d, base_router))
    o, c, org = _normalized(outline, cuts)
    parts.append(Part("base_plate", f"{pack_code}-BP", "Base plate", base_mat, alu, 1,
                      _process(base_mat), o, c, org))
    return parts


def check_design(cfg: dict[str, Any], parts: list[Part] | None = None) -> list[str]:
    """Manufacturing warnings for a valid config. An empty list means nothing to flag."""
    d = derive_dimensions(cfg)
    parts = parts if parts is not None else build_parts(cfg)
    warnings: list[str] = []

    if d.min_cnc_router_diameter < SCS_MIN_ROUTED_FEATURE_MM:
        warnings.append(f"min_router_diameter_mm ({d.min_cnc_router_diameter}) is below SendCutSend's "
                        f"~{SCS_MIN_ROUTED_FEATURE_MM} mm (0.125 in) smallest routed feature")
    if d.lip_width < d.standoff_od:
        warnings.append(f"lip_width_mm ({d.lip_width}) is smaller than the standoff OD ({d.standoff_od}): "
                        "the standoffs will overhang the plate edge")

    for part in parts:
        if part.process != "cnc_router":
            continue
        limit = SCS_MIN_WEB_FACTOR * part.thickness_mm
        shapes: list[tuple[str, Shape]] = [("edge", part.outline)] + [
            ("hole" if isinstance(c, Circle) else "slot", c) for c in part.cutouts]
        found: list[tuple[float, str]] = []
        for i in range(len(shapes)):
            for j in range(i + 1, len(shapes)):
                (ka, a), (kb, b) = shapes[i], shapes[j]
                if ka == "edge" and kb == "edge":
                    continue
                if bbox_gap(a.bbox(), b.bbox()) >= limit:
                    continue
                gap = min_gap(a, b, cap=limit)
                if gap < limit:
                    found.append((gap, "-to-".join(sorted((ka, kb)))))
        if found:
            found.sort()
            kinds = ", ".join(sorted({k for _, k in found}))
            warnings.append(
                f"{part.part_number} {part.description}: {len(found)} web(s) thinner than "
                f"{limit:.1f} mm (2 x thickness, SendCutSend's routed minimum); thinnest "
                f"{found[0][0]:.2f} mm ({found[0][1]}). Kinds: {kinds}")
    return warnings
