"""A small single-stroke (centerline) font for etched labels. Pure Python, no dependencies.

Single-line etching traces each path once, so the lettering has to be strokes, not outlined
glyphs. Each glyph is drawn on a 4 x 6 grid (x right, y up); the advance between characters
is 6 units. Supported characters: A-Z, 0-9, space, ``- . /`` (lower case is upper-cased).
"""
from __future__ import annotations

Point = tuple[float, float]

_OCT = [(1, 0), (3, 0), (4, 1), (4, 5), (3, 6), (1, 6), (0, 5), (0, 1), (1, 0)]

GLYPHS: dict[str, list[list[Point]]] = {
    "0": [_OCT, [(0.8, 0.8), (3.2, 5.2)]],     # slashed so it differs from the letter O
    "1": [[(1, 5), (2, 6), (2, 0)], [(1, 0), (3, 0)]],
    "2": [[(0, 5), (1, 6), (3, 6), (4, 5), (4, 4), (0, 0), (4, 0)]],
    "3": [[(0, 5), (1, 6), (3, 6), (4, 5), (4, 4), (3, 3), (1.5, 3)],
          [(3, 3), (4, 2), (4, 1), (3, 0), (1, 0), (0, 1)]],
    "4": [[(3, 0), (3, 6), (0, 2), (4, 2)]],
    "5": [[(4, 6), (0, 6), (0, 3), (3, 3), (4, 2), (4, 1), (3, 0), (1, 0), (0, 1)]],
    "6": [[(4, 5), (3, 6), (1, 6), (0, 5), (0, 1), (1, 0), (3, 0), (4, 1), (4, 2), (3, 3), (1, 3), (0, 2)]],
    "7": [[(0, 6), (4, 6), (1.5, 0)]],
    "8": [[(1, 3), (0, 4), (0, 5), (1, 6), (3, 6), (4, 5), (4, 4), (3, 3), (1, 3),
           (0, 2), (0, 1), (1, 0), (3, 0), (4, 1), (4, 2), (3, 3)]],
    "9": [[(4, 4), (3, 3), (1, 3), (0, 4), (0, 5), (1, 6), (3, 6), (4, 5), (4, 1), (3, 0), (1, 0), (0, 1)]],
    "A": [[(0, 0), (2, 6), (4, 0)], [(0.7, 2), (3.3, 2)]],
    "B": [[(0, 0), (0, 6), (3, 6), (4, 5), (4, 4), (3, 3), (0, 3)], [(3, 3), (4, 2), (4, 1), (3, 0), (0, 0)]],
    "C": [[(4, 5), (3, 6), (1, 6), (0, 5), (0, 1), (1, 0), (3, 0), (4, 1)]],
    "D": [[(0, 0), (0, 6), (2.5, 6), (4, 4.5), (4, 1.5), (2.5, 0), (0, 0)]],
    "E": [[(4, 6), (0, 6), (0, 0), (4, 0)], [(0, 3), (3, 3)]],
    "F": [[(4, 6), (0, 6), (0, 0)], [(0, 3), (3, 3)]],
    "G": [[(4, 5), (3, 6), (1, 6), (0, 5), (0, 1), (1, 0), (3, 0), (4, 1), (4, 3), (2, 3)]],
    "H": [[(0, 0), (0, 6)], [(4, 0), (4, 6)], [(0, 3), (4, 3)]],
    "I": [[(1, 6), (3, 6)], [(2, 6), (2, 0)], [(1, 0), (3, 0)]],
    "J": [[(4, 6), (4, 1), (3, 0), (1, 0), (0, 1)]],
    "K": [[(0, 0), (0, 6)], [(4, 6), (0, 2)], [(1.3, 3.3), (4, 0)]],
    "L": [[(0, 6), (0, 0), (4, 0)]],
    "M": [[(0, 0), (0, 6), (2, 3), (4, 6), (4, 0)]],
    "N": [[(0, 0), (0, 6), (4, 0), (4, 6)]],
    "O": [_OCT],
    "P": [[(0, 0), (0, 6), (3, 6), (4, 5), (4, 4), (3, 3), (0, 3)]],
    "Q": [_OCT, [(2, 2), (4, 0)]],
    "R": [[(0, 0), (0, 6), (3, 6), (4, 5), (4, 4), (3, 3), (0, 3)], [(2, 3), (4, 0)]],
    "S": [[(4, 5), (3, 6), (1, 6), (0, 5), (0, 4), (1, 3), (3, 3), (4, 2), (4, 1), (3, 0), (1, 0), (0, 1)]],
    "T": [[(0, 6), (4, 6)], [(2, 6), (2, 0)]],
    "U": [[(0, 6), (0, 1), (1, 0), (3, 0), (4, 1), (4, 6)]],
    "V": [[(0, 6), (2, 0), (4, 6)]],
    "W": [[(0, 6), (1, 0), (2, 3), (3, 0), (4, 6)]],
    "X": [[(0, 6), (4, 0)], [(4, 6), (0, 0)]],
    "Y": [[(0, 6), (2, 3), (4, 6)], [(2, 3), (2, 0)]],
    "Z": [[(0, 6), (4, 6), (0, 0), (4, 0)]],
    "-": [[(0.5, 3), (3.5, 3)]],
    ".": [[(2, 0), (2, 0.7)]],
    "/": [[(0, 0), (4, 6)]],
    " ": [],
}

GLYPH_HEIGHT = 6.0
ADVANCE = 6.0        # grid units from one character to the next
SPACE_ADVANCE = 4.0


def _glyph(ch: str) -> list[list[Point]]:
    try:
        return GLYPHS[ch.upper()]
    except KeyError:
        raise ValueError(f"character {ch!r} is not in the etch font "
                         f"(supported: A-Z 0-9 space - . /)") from None


def text_width(text: str, height: float) -> float:
    """Width of the text in mm for a cap height of ``height`` mm."""
    if not text:
        return 0.0
    units = sum(SPACE_ADVANCE if ch == " " else ADVANCE for ch in text) - (ADVANCE - 4.0)
    return units * height / GLYPH_HEIGHT


def text_strokes(text: str, height: float, x: float = 0.0, y: float = 0.0) -> list[list[Point]]:
    """Strokes (open polylines) for ``text`` with its lower-left corner at (x, y)."""
    scale = height / GLYPH_HEIGHT
    strokes: list[list[Point]] = []
    cursor = 0.0
    for ch in text:
        for stroke in _glyph(ch):
            strokes.append([(x + (cursor + px) * scale, y + py * scale) for px, py in stroke])
        cursor += SPACE_ADVANCE if ch == " " else ADVANCE
    return strokes
