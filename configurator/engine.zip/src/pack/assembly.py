"""The assembled pack in 3D: where every part sits, in plain Python (for the web 3D view).

``build_parts`` gives each cut part as a flat outline. This module puts those outlines, the cells,
busbars, BMS tray, foam liner, standoffs and screw heads into the model frame, the same way the
Fusion script places them:

    X = pack length along the bike (front = +X), Y = height, Z = cell axis.
    Side plates lie in XY at -Z (front plate) and +Z (rear plate, the mirror of the front one).
    Long walls (top / bottom) lie in XZ, short walls (left / right) in YZ.
    With a base plate, everything but the base plate is slid -X by the battery latch slide, so the
    hooks sit latched in their base-plate slots (as in the Fusion model).

Solids are plain dicts, ready for JSON:

    extrusion  outline + holes in the part's flat (u, v) coordinates, extruded ``thickness`` along w.
               frame = {origin, u, v, w}: flat point (a, b), height c -> origin + a*u + b*v + c*w.
    cylinders  one or more cylinders (optionally tubes) along an axis, given by their centers.
    boxes      axis-aligned boxes, each [[xmin, ymin, zmin], [xmax, ymax, zmax]].

Exploded view: every solid also has ``explode`` (one [dx, dy, dz] for the whole solid) and, for a
solid made of separate pieces (busbars, foam strips, screws), ``explode_each`` (one per box or
center). That is the full offset in mm; the viewer moves each piece by ``t * offset``, t in 0..1.
``bbox_exploded`` is the bounding box at t = 1.
"""
from __future__ import annotations

import math
from typing import Any

from .contours import Circle, Polyline, Shape
from .geometry import Part, build_parts, derive_dimensions, derive_layout

Vec = tuple[float, float, float]
FLATTEN_TOL_MM = 0.1     # arcs are flattened to straight segments within this distance
CIRCLE_SEGMENTS = 24     # bolt holes


def _r(v: float) -> float:
    return round(v, 2)


def _pts(shape: Shape) -> list[list[float]]:
    if isinstance(shape, Circle):
        n = CIRCLE_SEGMENTS
        return [[_r(shape.cx + shape.r * math.cos(2 * math.pi * i / n)),
                 _r(shape.cy + shape.r * math.sin(2 * math.pi * i / n))] for i in range(n)]
    return [[_r(x), _r(y)] for x, y in shape.points(tol=FLATTEN_TOL_MM)]


def _extrusion(name: str, part: Part, material: str, origin: Vec, u: Vec, v: Vec, w: Vec) -> dict[str, Any]:
    """A flat part placed in the model. ``origin`` is where the part's flat (0, 0), bottom face, goes."""
    return {
        "type": "extrusion", "name": name, "part": part.key, "material": material,
        "outline": _pts(part.outline), "holes": [_pts(c) for c in part.cutouts],
        "thickness": part.thickness_mm,
        "frame": {"origin": [_r(c) for c in origin], "u": list(u), "v": list(v), "w": list(w)},
    }


def to_model(solid: dict[str, Any], a: float, b: float, c: float = 0.0) -> Vec:
    """Model coordinates of a point given in an extrusion's flat (a, b) and height (c) coordinates."""
    f = solid["frame"]
    return tuple(f["origin"][i] + a * f["u"][i] + b * f["v"][i] + c * f["w"][i] for i in range(3))  # type: ignore[return-value]


def build_assembly(cfg: dict[str, Any]) -> dict[str, Any]:
    """Every solid of the assembled pack, plus its overall bounding box. Units are mm."""
    d = derive_dimensions(cfg)
    lay = derive_layout(d)
    parts = {p.key: p for p in build_parts(cfg)}
    pct, cd = d.polycarbonate_thickness, d.cavity_depth
    cw2, ch2, ph2 = d.cavity_width / 2, d.cavity_height / 2, d.plate_height / 2
    s = d.battery_latch_slide if d.base_plate else 0.0     # battery parts slide -X to latch
    X, Y, Z = (1.0, 0.0, 0.0), (0.0, 1.0, 0.0), (0.0, 0.0, 1.0)
    solids: list[dict[str, Any]] = []

    # Side plates: flat (u, v) is model (X, Y); front at -Z, rear at +Z
    sp = parts["side_plate"]
    ox, oy = sp.origin
    solids.append(_extrusion("Front side plate", sp, "polycarbonate", (ox - s, oy, -(cd / 2 + pct)), X, Y, Z))
    solids.append(_extrusion("Rear side plate", sp, "polycarbonate", (ox - s, oy, cd / 2), X, Y, Z))

    # Long walls (top / bottom): flat (u, v) is model (X, Z), thickness along Y
    lw = parts["long_wall"]
    ox, oz = lw.origin
    solids.append(_extrusion("Top wall", lw, "polycarbonate", (ox - s, ch2, oz), X, Z, Y))
    solids.append(_extrusion("Bottom wall", lw, "polycarbonate", (ox - s, -ch2 - pct, oz), X, Z, Y))

    # Short walls (left = rear end, right = front end): flat (u, v) is model (Y, Z), thickness along X
    sw = parts["short_wall"]
    oy, oz = sw.origin
    solids.append(_extrusion("Rear end wall", sw, "polycarbonate", (-cw2 - pct - s, oy, oz), Y, Z, X))
    solids.append(_extrusion("Front end wall", sw, "polycarbonate", (cw2 - s, oy, oz), Y, Z, X))

    # Base plate: flat (u, v) is model (X, Z), under the side plates; it does not slide
    if "base_plate" in parts:
        bp = parts["base_plate"]
        ox, oz = bp.origin
        solids.append(_extrusion("Base plate", bp, "aluminum", (ox, -ph2 - d.alu_thickness, oz), X, Z, Y))

    # Internal core (same layout as the Fusion script): BMS tray at the bottom, cells above it
    ccw2 = d.cell_core_width / 2
    y_tray_bot = -ch2 + d.foam_thickness
    y_tray_top = y_tray_bot + d.bms_height
    solids.append({"type": "boxes", "name": "BMS tray", "material": "abs",
                   "boxes": [[[_r(-ccw2 - s), _r(y_tray_bot), _r(-d.core_depth / 2)],
                              [_r(ccw2 - s), _r(y_tray_top), _r(d.core_depth / 2)]]]})
    cells = [[_r(-ccw2 + d.cell_pitch * (i + 0.5) - s), _r(y_tray_top + d.cell_pitch * (j + 0.5)), 0.0]
             for i in range(d.columns) for j in range(d.rows)]
    solids.append({"type": "cylinders", "name": "Cells", "material": "cell", "axis": "z",
                   "radius": d.cell_diameter / 2, "inner_radius": 0.0, "length": d.cell_height,
                   "centers": cells})
    if d.busbar_height > 0:
        y0, y1 = y_tray_top, y_tray_top + d.cell_core_height
        h2 = d.cell_height / 2
        solids.append({"type": "boxes", "name": "Busbars", "material": "nickel", "boxes": [
            [[_r(-ccw2 - s), _r(y0), _r(z0)], [_r(ccw2 - s), _r(y1), _r(z0 + d.busbar_height)]]
            for z0 in (-h2 - d.busbar_height, h2)]})
    if d.foam_thickness > 0:
        f, z2 = d.foam_thickness, d.core_depth / 2
        ring = [((-cw2, -ch2), (cw2, -ch2 + f)), ((-cw2, ch2 - f), (cw2, ch2)),
                ((-cw2, -ch2 + f), (-cw2 + f, ch2 - f)), ((cw2 - f, -ch2 + f), (cw2, ch2 - f))]
        solids.append({"type": "boxes", "name": "Foam liner", "material": "foam", "boxes": [
            [[_r(x0 - s), _r(y0), _r(-z2)], [_r(x1 - s), _r(y1), _r(z2)]] for (x0, y0), (x1, y1) in ring]})

    # Standoffs between the side plates at every bolt point, and a screw head on each outer face
    bolts = [[_r(bx - s), _r(by), 0.0] for bx, by in lay.bolt_points]
    solids.append({"type": "cylinders", "name": "Standoffs", "material": "aluminum", "axis": "z",
                   "radius": d.standoff_od / 2, "inner_radius": d.standoff_id / 2, "length": cd,
                   "centers": bolts})
    screw = cfg["enclosure"].get("screw")
    if isinstance(screw, dict) and screw.get("head_diameter_mm") and screw.get("head_height_mm"):
        hh = float(screw["head_height_mm"])
        zc = cd / 2 + pct + hh / 2
        solids.append({"type": "cylinders", "name": "Screws", "material": "steel", "axis": "z",
                       "radius": float(screw["head_diameter_mm"]) / 2, "inner_radius": 0.0, "length": hh,
                       "centers": [[x, y, _r(side * zc)] for x, y, _ in bolts for side in (-1, 1)]})

    _add_explode(solids, d)
    return {"solids": solids, "bbox": [list(v) for v in _bbox(solids)],
            "bbox_exploded": [list(v) for v in _bbox([_exploded(sol) for sol in solids])],
            "slide_mm": _r(s)}


# Exploded view: how far each part moves out, in gaps (see _add_explode)
EXPLODE_GAP_MIN_MM = 40.0
EXPLODE_GAP_FRACTION = 0.6     # one gap = this fraction of the larger of cavity height / depth
EXPLODE_STEPS = {               # whole solids: direction x number of gaps
    "Front side plate": (0, 0, -2.0), "Rear side plate": (0, 0, 2.0),
    "Top wall": (0, 1.5, 0), "Bottom wall": (0, -1.5, 0),
    "Rear end wall": (-1.5, 0, 0), "Front end wall": (1.5, 0, 0),
    "Base plate": (0, -2.6, 0), "BMS tray": (0, -0.35, 0),
}
EXPLODE_FOAM_GAPS = 0.75        # foam strips move out from the core, each its own way
EXPLODE_BUSBAR_GAPS = 0.6       # busbars move off the cell ends
EXPLODE_SCREW_GAPS = 2.8        # screws back out past the side plates


def _add_explode(solids: list[dict[str, Any]], d: Any) -> None:
    """Give every solid its exploded-view offset. Cells and standoffs stay put."""
    g = max(EXPLODE_GAP_MIN_MM, EXPLODE_GAP_FRACTION * max(d.cavity_height, d.cavity_depth))
    vec = lambda gx, gy, gz: [_r(gx * g), _r(gy * g), _r(gz * g)]  # noqa: E731
    for sol in solids:
        name = sol["name"]
        sol["explode"] = vec(*EXPLODE_STEPS.get(name, (0, 0, 0)))
        if name == "Busbars":
            sol["explode_each"] = [vec(0, 0, EXPLODE_BUSBAR_GAPS * (1 if b0[2] > 0 else -1))
                                   for b0, _ in sol["boxes"]]
        elif name == "Foam liner":     # bottom, top, rear end, front end strips
            sol["explode_each"] = [vec(*(EXPLODE_FOAM_GAPS * k for k in way))
                                   for way in ((0, -1, 0), (0, 1, 0), (-1, 0, 0), (1, 0, 0))]
        elif name == "Screws":
            sol["explode_each"] = [vec(0, 0, EXPLODE_SCREW_GAPS * (1 if z > 0 else -1))
                                   for _, _, z in sol["centers"]]


def _offsets(sol: dict[str, Any]) -> list[list[float]]:
    """The exploded-view offset of each piece of a solid (one for an extrusion)."""
    n = 1 if sol["type"] == "extrusion" else len(sol["boxes"] if sol["type"] == "boxes" else sol["centers"])
    return sol.get("explode_each") or [sol.get("explode", [0.0, 0.0, 0.0])] * n


def _exploded(sol: dict[str, Any]) -> dict[str, Any]:
    """A copy of a solid moved to its fully exploded position."""
    out = dict(sol)
    offs = _offsets(sol)
    add = lambda p, o: [p[i] + o[i] for i in range(3)]  # noqa: E731
    if sol["type"] == "extrusion":
        out["frame"] = dict(sol["frame"], origin=add(sol["frame"]["origin"], offs[0]))
    elif sol["type"] == "boxes":
        out["boxes"] = [[add(b0, o), add(b1, o)] for (b0, b1), o in zip(sol["boxes"], offs)]
    else:
        out["centers"] = [add(c, o) for c, o in zip(sol["centers"], offs)]
    return out


def _bbox(solids: list[dict[str, Any]]) -> tuple[Vec, Vec]:
    lo, hi = [math.inf] * 3, [-math.inf] * 3

    def grow(p: Vec | list[float]) -> None:
        for i in range(3):
            lo[i], hi[i] = min(lo[i], p[i]), max(hi[i], p[i])

    for sol in solids:
        if sol["type"] == "extrusion":
            for a, b in sol["outline"]:
                grow(to_model(sol, a, b))
                grow(to_model(sol, a, b, sol["thickness"]))
        elif sol["type"] == "boxes":
            for b0, b1 in sol["boxes"]:
                grow(b0)
                grow(b1)
        else:   # cylinders along Z
            r, h = sol["radius"], sol["length"] / 2
            for x, y, z in sol["centers"]:
                grow((x - r, y - r, z - h))
                grow((x + r, y + r, z + h))
    return (tuple(_r(v) for v in lo), tuple(_r(v) for v in hi))  # type: ignore[return-value]
