# Hardware models

`ebike_enclosure.py` imports purchased parts from STEP files in this folder. A file is matched by
its name starting with the part number (`.step` or `.stp`, any case).

| Part number | What | Used for | Qty per pack |
|---|---|---|---|
| McMaster 92137A420 | Black-oxide alloy steel flanged button head hex-drive screw, M5 x 0.8 x 16 mm | Side plate to standoff, both sides | 2 per bolt point (24 with the default 20S4P) |

Getting the STEP file: on mcmaster.com open the part number, log in, choose **3-D STEP** in the CAD
menu, and save it here (for example `92137A420.STEP`). The script works out the screw's axis and
the underside of its head from the geometry, so the model's orientation in the file does not matter.

Without the file the script still runs and reports that the screws were skipped.

The standoffs the screws thread into are modeled as M5 x 0.8 female-threaded both ends
(`Standoff_ID` = 4.2 mm tap drill): 3/8 in OD aluminum, length = `Cavity_Depth`.
