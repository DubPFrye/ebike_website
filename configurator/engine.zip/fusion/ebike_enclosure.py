# Author: Gemini CAD Generator v4, parameterized rewrite
# Description: Parametric e-bike battery enclosure (polycarbonate side plates and walls,
#   6061 aluminum base plate, standoffs, foam liner, BMS tray, busbars, cells).
#
# To run in Fusion 360: Shift+S (Scripts and Add-Ins) -> '+' next to My Scripts ->
# Create a new Python script, paste this in -> Run.
#
# HOW IT WORKS
#   * Every dimension is a Fusion USER PARAMETER (Modify > Change Parameters). Edit a value
#     there and the model regenerates, including Columns and Rows (the cells are built with
#     a rectangular pattern whose counts are bound to those parameters).
#   * Re-running the script keeps any parameter values you already edited, and deletes the
#     previously generated assembly before building a new one.
#   * The tab count, tab positions, bolt positions and hook count are chosen when the script
#     runs. If you change Columns a lot, re-run the script to respace them.
#   * Orientation: X = pack length along the bike (front = +X, rear = -X), Y = height,
#     Z = cell length (the two side plates are the bike's left/right, +/-Z).
#   * Latching: the side-plate hook noses point -X. The base plate and its slots
#     stay fixed; the whole battery is slid -X by Battery_Latch_Slide so the hooks
#     sit latched in the nominal model.

import adsk.core, adsk.fusion, traceback, re, os, math, time

MM = 0.1        # 1 mm in Fusion's internal length unit (cm)
# McMaster-Carr 92137A420: black-oxide alloy steel flanged button head hex-drive screw,
# M5 x 0.8 x 16 mm. Its STEP file goes in fusion/hardware/ (any name starting with the part number).
SCREW_PART = '92137A420'
# Config enclosure.base_plate. False builds the enclosure with no aluminum base plate and no
# L-hooks on the side plates (the battery then mounts by its side plates some other way).
BASE_PLATE = True
# Set in the build-package copy of this script (pack.fusion_script) to the pack it was made for.
# A package script overwrites the design's plain-value parameters with its own values, so it
# always builds its pack; the repo copy (empty name) keeps values you edited in Fusion.
CONFIG_NAME = ''
VALS = {}       # parameter name -> value in mm (unitless for counts)
SKETCHES = []   # every sketch we create, checked for full definition at the end
ISSUES = []     # non-fatal problems (a dimension that failed, etc.)

# (name, expression, units, comment). Order matters: derived entries use earlier names.
PARAMS = [
    # ---- Pack ----
    ('Columns', '20', '', 'Cells across the pack width'),
    ('Rows', '4', '', 'Cells in each column (parallel count)'),
    ('Cell_Diameter', '21', 'mm', '21700 cell diameter'),
    ('Cell_Height', '70', 'mm', '21700 cell length'),
    ('Cell_Pitch', '23.4', 'mm', 'Cell-to-cell pitch of the holder (square grid)'),
    ('Busbar_Height', '2', 'mm', 'Busbar plate thickness at each end of the cells'),
    ('Foam_Thickness', '3', 'mm', 'Neoprene foam liner thickness'),
    ('BMS_Height', '10', 'mm', 'ABS BMS / fuse / wiring tray height'),
    # ---- Plates / base ----
    ('Polycarbonate_Thickness', '5.6', 'mm', 'SendCutSend 0.220 in polycarbonate'),
    ('Lip_Width', '15', 'mm', 'Plate margin outside the walls; holds the bolts and standoffs'),
    ('Alu_Thickness', '6.35', 'mm', 'SendCutSend 0.250 in 6061 aluminum'),
    ('Base_Front_Extension', '20', 'mm', 'Base plate extension past the battery front edge (+X)'),
    ('Base_Rear_Extension', '20', 'mm', 'Base plate extension past the battery rear edge (-X)'),
    ('Side_Extension', '5', 'mm', 'Base plate extension past the outer faces of the side plates (+/-Z)'),
    # ---- Slots, tabs, router ----
    ('Min_CNC_Router_Diameter', '3.2', 'mm', 'Dogbone circle diameter'),
    ('Slot_Clearance', '0.25', 'mm', 'Slot width minus polycarbonate thickness'),
    ('Tab_Shortfall', '0.2', 'mm', 'How far short of flush the tab ends sit in the side plate'),
    # Tab rule: each side-plate edge runs bolt, tab, bolt, ..., bolt, evenly spaced between its
    # corner bolts. The count per edge is set when the script runs (re-run after resizing).
    ('Tab_Max_Spacing', '125', 'mm', 'Largest bolt / tab spacing along an edge (sets the tab count)'),
    ('Tab_Min_Spacing', '50', 'mm', 'Below this spacing an edge gets fewer tabs (long edges: tight layout)'),
    ('Tab_Length_Ratio', '0.33', '', 'Tab length as a fraction of the tab spacing'),
    ('Tab_Min_Length', '15', 'mm', 'Shortest tab (tight edges may go shorter, down to the dogbone limit)'),
    ('Tab_Max_Length', '40', 'mm', 'Longest tab'),
    ('Cut_Overshoot', '1', 'mm', 'Extra cut depth so cuts pass fully through'),
    # ---- Bolts and standoffs ----
    ('Bolt_Hole_Diameter', '5.3', 'mm', 'M5 clearance hole'),
    ('Standoff_OD', '9.525', 'mm', '3/8 in aluminum spacer OD'),
    ('Standoff_ID', '4.2', 'mm', 'Standoff bore: M5 x 0.8 female thread both ends (4.2 mm tap drill)'),
    # ---- Hooks ----
    # One hook under each bottom tab. The package script for a 2-3S pack carries the small hook
    # (config enclosure.small_hook) in these values.
    ('Hook_Neck_Width', '28', 'mm', 'L-hook neck width'),
    ('Hook_Nose', '10', 'mm', 'L-hook nose length: how far the nose latches under the base plate'),
    ('Hook_Drop_Extra', '10', 'mm', 'Hook nose height below the base plate underside (nose strength)'),
    ('Hook_Overlap', '2', 'mm', 'Hook neck overlap into the side plate'),
    ('Hook_Slot_Length', '40', 'mm', 'Base plate hook slot length'),
    ('Hook_Slot_Offset', '15', 'mm', 'Base slot extent on the +X side of the hook center (battery unslid)'),
    ('Hook_Slot_Clearance', '0.25', 'mm', 'Gap between the hook neck and the front (-X) end of its base slot when latched'),
    # ---- Fillets ----
    ('Fillet_Large', '8', 'mm', 'Outside corners of the base plate'),
    ('Fillet_Small', '2', 'mm', 'Outside corners of the hooks'),
    # ---- Derived (edit the expressions if you want different rules) ----
    ('Bolt_Edge_Offset', 'Lip_Width - Standoff_OD / 2', 'mm',
     'Bolt/standoff center to plate edge: standoffs sit tangent to the outside of the inner walls'),
    ('Side_Plate_Corner_Radius', 'Bolt_Edge_Offset', 'mm',
     'Side plate outside corners: arc centered on the corner bolt, so the corner web matches the edge web'),
    ('Slot_Width', 'Polycarbonate_Thickness + Slot_Clearance', 'mm', 'Slot width for the PC wall'),
    ('Tab_Depth', 'Polycarbonate_Thickness - Tab_Shortfall', 'mm', 'Tab depth into the side plate'),
    ('Hook_Drop', 'Alu_Thickness + Hook_Drop_Extra', 'mm', 'Hook drop below the plate bottom edge'),
    ('Core_Depth', 'Cell_Height + 2 * Busbar_Height', 'mm', 'Cells plus busbars, front to back'),
    ('Cavity_Depth', 'Core_Depth + 2 * Foam_Thickness', 'mm', 'Inside distance between side plates'),
    ('Cell_Core_Width', 'Columns * Cell_Pitch', 'mm', 'Cell block width'),
    ('Cell_Core_Height', 'Rows * Cell_Pitch', 'mm', 'Cell block height'),
    ('Cavity_Width', 'Cell_Core_Width + 2 * Foam_Thickness', 'mm', 'Inside cavity width'),
    ('Cavity_Height', 'Cell_Core_Height + BMS_Height + 2 * Foam_Thickness', 'mm', 'Inside cavity height'),
    ('Plate_Width', 'Cavity_Width + 2 * Polycarbonate_Thickness + 2 * Lip_Width', 'mm', 'Side plate width'),
    ('Plate_Height', 'Cavity_Height + 2 * Polycarbonate_Thickness + 2 * Lip_Width', 'mm', 'Side plate height'),
    ('Base_Plate_X_Length', 'Plate_Width + Base_Front_Extension + Base_Rear_Extension', 'mm', 'Base plate length (X)'),
    ('Base_Plate_Z_Width', 'Cavity_Depth + 2 * Polycarbonate_Thickness + 2 * Side_Extension', 'mm', 'Base plate width (Z)'),
    ('Battery_Latch_Slide', 'Hook_Slot_Length - Hook_Slot_Offset - Hook_Neck_Width / 2 - Hook_Slot_Clearance', 'mm',
     'How far the battery is slid in -X to latch the hooks'),
]


# ----------------------------------------------------------------------------------
# Expression helpers. Expressions are strings in terms of the user parameters. They are
# handed to Fusion as-is (so dimensions stay driven by parameters) and evaluated here
# (to place the initial geometry). "0" is special-cased so we never emit a unitless 0
# next to a length.
# ----------------------------------------------------------------------------------
def neg(a):
    return '0' if a == '0' else '-(%s)' % a

def half(a):
    return '0' if a == '0' else '(%s)/2' % a

def add(a, b):
    if a == '0':
        return b
    if b == '0':
        return a
    return '(%s) + (%s)' % (a, b)

def sub(a, b):
    if b == '0':
        return a
    if a == '0':
        return neg(b)
    return '(%s) - (%s)' % (a, b)

def ev(expr):
    """Evaluate an expression to millimeters (or a plain number)."""
    return float(eval(expr, {'__builtins__': {}}, VALS))

def vi(expr):
    return adsk.core.ValueInput.createByString(expr)

def pt(xe, ye):
    return adsk.core.Point3D.create(ev(xe) * MM, ev(ye) * MM, 0)

def last_error():
    return traceback.format_exc().strip().splitlines()[-1]


# ----------------------------------------------------------------------------------
# Parameters
# ----------------------------------------------------------------------------------
def setup_parameters(design):
    ups = design.userParameters
    for name, expr, units, comment in PARAMS:
        numeric = bool(re.match(r'^[0-9.]+$', expr))
        existing = ups.itemByName(name)
        if existing is None:
            val = vi('%s %s' % (expr, units)) if (units and numeric) else vi(expr)
            ups.add(name, val, units, comment)
        elif not numeric:
            # Derived parameter: always refresh so formula changes in this script take effect
            if existing.expression != expr:
                existing.expression = expr
        elif CONFIG_NAME or not re.match(r'^[0-9.]+( [a-z]+)?$', existing.expression):
            # Package script (builds exactly its pack), or a plain-value parameter that an older
            # version of this script made a formula
            want = '%s %s' % (expr, units) if units else expr
            if existing.expression != want:
                existing.expression = want
        # otherwise: keep the value you edited
    for name, expr, units, comment in PARAMS:
        p = ups.itemByName(name)
        VALS[name] = p.value * 10.0 if units == 'mm' else p.value


def runtime_param(design, name, expr, units, comment):
    """A parameter the script derives from the layout when it runs (tab spacing and length).
    Rewritten on every run; edit the rule parameters above instead and re-run."""
    ups = design.userParameters
    p = ups.itemByName(name)
    if p is None:
        p = ups.add(name, vi(expr), units, comment + ' (set by the script on each run)')
    elif p.expression != expr:
        p.expression = expr
    VALS[name] = p.value * 10.0 if units == 'mm' else p.value


# ----------------------------------------------------------------------------------
# Layout rules. Plain Python (no Fusion calls), kept identical to pack.geometry.edge_tabs and
# its hook check; tests/test_fusion_parity.py runs both and compares.
# ----------------------------------------------------------------------------------
def edge_layout(span, V, min_count=1):
    """Tabs along one side-plate edge whose corner bolts are span apart.
    Returns (count, pitch, tab length, offset). offset is None for the even layout (tabs midway
    between bolts, a bolt between every two tabs); for a tight edge (two tabs forced onto a very
    short edge) it is the tab center distance from the middle, and there is no middle bolt."""
    n = max(1, int(math.ceil(span / V['Tab_Max_Spacing'] - 1e-9)))
    if n < 2 and span / 2.0 >= V['Tab_Min_Spacing']:
        n = 2
    n = max(n, min_count)
    pitch = span / n
    if n == 2 and pitch < V['Tab_Min_Spacing']:
        length = max(2 * V['Min_CNC_Router_Diameter'] + 3.0, V['Tab_Length_Ratio'] * pitch)
        length = round(length * 2) / 2.0
        return n, pitch, length, (span / 2.0 + length / 2.0 - V['Bolt_Hole_Diameter'] / 2.0) / 3.0
    length = min(V['Tab_Max_Length'], max(V['Tab_Min_Length'], V['Tab_Length_Ratio'] * pitch))
    return n, pitch, round(length * 2) / 2.0, None


def hooks_fit(xs, V):
    """Neighbouring base-plate hook slots keep one plate thickness of aluminum between them, and
    every hook neck stays on the straight part of the side plate's bottom edge."""
    gap = min(b - a for a, b in zip(xs, xs[1:])) - V['Hook_Slot_Length']
    straight = V['Plate_Width'] / 2.0 - V['Side_Plate_Corner_Radius']
    return gap >= V['Alu_Thickness'] and max(abs(x) for x in xs) + V['Hook_Neck_Width'] / 2.0 + V['Min_CNC_Router_Diameter'] <= straight


# ----------------------------------------------------------------------------------
# Sketch helpers: draw geometry and fully dimension it from the parameters.
# ----------------------------------------------------------------------------------
def new_sketch(comp, plane, name):
    sk = comp.sketches.add(plane)
    sk.name = name
    SKETCHES.append(sk)
    return sk

def dim_lin(sk, a, b, horizontal, expr):
    """Add a distance dimension bound to expr. If Fusion rejects it, retry with the endpoints
    swapped and with the dimension text on the other side; any rejected dimension is deleted."""
    ori = (adsk.fusion.DimensionOrientations.HorizontalDimensionOrientation if horizontal
           else adsk.fusion.DimensionOrientations.VerticalDimensionOrientation)
    err = ''
    for (p1, p2, side) in ((a, b, -1), (b, a, -1), (a, b, 1), (b, a, 1)):
        d = None
        try:
            g1, g2 = p1.geometry, p2.geometry
            if horizontal:
                tp = adsk.core.Point3D.create((g1.x + g2.x) / 2.0, (min(g1.y, g2.y) if side < 0 else max(g1.y, g2.y)) + side * 0.6, 0)
            else:
                tp = adsk.core.Point3D.create((min(g1.x, g2.x) if side < 0 else max(g1.x, g2.x)) + side * 0.6, (g1.y + g2.y) / 2.0, 0)
            d = sk.sketchDimensions.addDistanceDimension(p1, p2, ori, tp)
            d.parameter.expression = expr
            return True
        except:
            err = last_error()
            if d is not None:
                try:
                    d.deleteMe()
                except:
                    pass
    ISSUES.append('%s: dimension "%s" failed: %s' % (sk.name, expr, err))
    return False

def place(sk, point, xe, ye):
    """Locate a sketch point relative to the origin using parameter-driven dimensions."""
    org = sk.originPoint
    for is_x, e in ((True, xe), (False, ye)):
        v = ev(e)
        if abs(v) < 1e-6:
            try:
                if is_x:
                    sk.geometricConstraints.addVerticalPoints(org, point)
                else:
                    sk.geometricConstraints.addHorizontalPoints(org, point)
            except:
                ISSUES.append('%s: alignment constraint failed: %s' % (sk.name, last_error()))
        else:
            dim_lin(sk, org, point, is_x, e if v > 0 else neg(e))

def rect(sk, x0, x1, y0, y1, w=None, h=None):
    """Draw a rectangle and fully define it: width, height, and corner position."""
    lines = sk.sketchCurves.sketchLines.addTwoPointRectangle(pt(x0, y0), pt(x1, y1))
    # The API does not always add horizontal/vertical constraints; add them explicitly
    # (skipped quietly if a line already has one).
    for i in range(lines.count):
        ln = lines.item(i)
        a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
        try:
            if abs(a.y - b.y) < 1e-9:
                sk.geometricConstraints.addHorizontal(ln)
            else:
                sk.geometricConstraints.addVertical(ln)
        except:
            pass
    pts = []
    for i in range(lines.count):
        ln = lines.item(i)
        pts.append(ln.startSketchPoint)
        pts.append(ln.endSketchPoint)
    bl = min(pts, key=lambda p: p.geometry.x + p.geometry.y)
    br = max(pts, key=lambda p: p.geometry.x - p.geometry.y)
    tl = min(pts, key=lambda p: p.geometry.x - p.geometry.y)
    dim_lin(sk, bl, br, True, w or sub(x1, x0))
    dim_lin(sk, bl, tl, False, h or sub(y1, y0))
    place(sk, bl, x0, y0)
    return lines

def rect_edges(lines):
    hs, vs = [], []
    for i in range(lines.count):
        ln = lines.item(i)
        a, b = ln.startSketchPoint.geometry, ln.endSketchPoint.geometry
        if abs(a.y - b.y) < 1e-9:
            hs.append(ln)
        else:
            vs.append(ln)
    return {
        'bottom': min(hs, key=lambda l: l.startSketchPoint.geometry.y),
        'top': max(hs, key=lambda l: l.startSketchPoint.geometry.y),
        'left': min(vs, key=lambda l: l.startSketchPoint.geometry.x),
        'right': max(vs, key=lambda l: l.startSketchPoint.geometry.x),
    }

def circle(sk, cx, cy, dia, locate=True):
    r = ev(dia) * MM / 2.0
    c = sk.sketchCurves.sketchCircles.addByCenterRadius(pt(cx, cy), r)
    try:
        g = c.centerSketchPoint.geometry
        tp = adsk.core.Point3D.create(g.x + r * 1.6, g.y + r * 1.6, 0)
        d = sk.sketchDimensions.addDiameterDimension(c, tp)
        d.parameter.expression = dia
    except:
        ISSUES.append('%s: diameter dimension "%s" failed: %s' % (sk.name, dia, last_error()))
    if locate:
        place(sk, c.centerSketchPoint, cx, cy)
    return c

def slot(sk, x0, x1, y0, y1, along_x, w, h):
    """Rectangular slot with 4 dogbone circles. Each circle is centered on a long edge and
    tangent to the short end of the slot, so the end stays flat across the full slot width."""
    lines = rect(sk, x0, x1, y0, y1, w, h)
    e = rect_edges(lines)
    dia = 'Min_CNC_Router_Diameter'
    r = half(dia)
    gc = sk.geometricConstraints
    if along_x:     # long edges are top/bottom, short ends are left/right
        ends = (('left', add(x0, r)), ('right', sub(x1, r)))
        sides = (('bottom', y0), ('top', y1))
        combos = [(end, ex, side, sy) for end, ex in ends for side, sy in sides]
    else:           # long edges are left/right, short ends are bottom/top
        ends = (('bottom', add(y0, r)), ('top', sub(y1, r)))
        sides = (('left', x0), ('right', x1))
        combos = [(end, ey, side, sx) for end, ey in ends for side, sx in sides]
    for end, a, side, b in combos:
        cx, cy = (a, b) if along_x else (b, a)
        c = circle(sk, cx, cy, dia, locate=False)
        try:
            gc.addCoincident(c.centerSketchPoint, e[side])   # center sits on the long edge
            gc.addTangent(e[end], c)                         # tangent to the short end
        except:
            ISSUES.append('%s: dogbone constraint failed: %s' % (sk.name, last_error()))

def sketch_axes(sk):
    """How model X / Y / Z map onto this sketch: {axis: (sketch axis 0 or 1, sign)}; axes normal
    to the sketch plane are left out. Uses differences, so occurrence offsets cancel."""
    o = sk.modelToSketchSpace(adsk.core.Point3D.create(0, 0, 0))
    out = {}
    for name, v in (('x', (1, 0, 0)), ('y', (0, 1, 0)), ('z', (0, 0, 1))):
        p = sk.modelToSketchSpace(adsk.core.Point3D.create(*v))
        dx, dy = p.x - o.x, p.y - o.y
        if abs(dx) > 0.5:
            out[name] = (0, 1 if dx > 0 else -1)
        elif abs(dy) > 0.5:
            out[name] = (1, 1 if dy > 0 else -1)
    return out


def model_circle(sk, axes, coords, dia):
    """A dimensioned circle centered at model coordinates {axis: expression} (the two in-plane
    axes of this sketch)."""
    se = ['0', '0']
    for ax, e in coords.items():
        i, s = axes[ax]
        se[i] = e if s > 0 else neg(e)
    return circle(sk, se[0], se[1], dia)


def all_profiles(sk):
    col = adsk.core.ObjectCollection.create()
    for p in sk.profiles:
        col.add(p)
    return col

def offset_plane(comp, base_plane, expr):
    pin = comp.constructionPlanes.createInput()
    pin.setByOffset(base_plane, vi(expr))
    return comp.constructionPlanes.add(pin)


# ----------------------------------------------------------------------------------
def find_edges(body, axis, targets, tol=0.02):
    """Straight edges of body parallel to `axis` ('z' or 'y') whose position in the other
    two coordinates matches one of `targets` (a, b) in mm. Axis z: (x, y); axis y: (x, z)."""
    found = adsk.core.ObjectCollection.create()
    for e in body.edges:
        try:
            if e.geometry.curveType != adsk.core.Curve3DTypes.Line3DCurveType:
                continue
            a, b = e.startVertex.geometry, e.endVertex.geometry
            if axis == 'z':
                if abs(a.x - b.x) > 1e-6 or abs(a.y - b.y) > 1e-6:
                    continue
                pos = (a.x / MM, a.y / MM)
            else:
                if abs(a.x - b.x) > 1e-6 or abs(a.z - b.z) > 1e-6:
                    continue
                pos = (a.x / MM, a.z / MM)
            if any(abs(pos[0] - t[0]) < tol / MM and abs(pos[1] - t[1]) < tol / MM for t in targets):
                found.add(e)
        except:
            pass
    return found

def fillet_edges(comp, edges, radius_param, what):
    if edges.count == 0:
        ISSUES.append('Fillet (%s): no matching edges found' % what)
        return
    try:
        fi = comp.features.filletFeatures
        inp = fi.createInput()
        inp.addConstantRadiusEdgeSet(edges, vi(radius_param), True)
        fi.add(inp)
    except:
        ISSUES.append('Fillet (%s, %s) failed: %s' % (what, radius_param, last_error()))


def find_hardware_file(part):
    """fusion/hardware/<part>*.step or .stp, or None."""
    folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'hardware')
    if not os.path.isdir(folder):
        return None
    for fn in sorted(os.listdir(folder)):
        base, ext = os.path.splitext(fn)
        if ext.lower() in ('.step', '.stp') and base.upper().startswith(part.upper()):
            return os.path.join(folder, fn)
    return None


def screw_frame(body):
    """Work out an imported screw's axis from its geometry (STEP files come in any orientation).
    `body` is the native body, so everything is in its own component's space (cm).
    Returns (under_head_point, unit vector head->tip, length under the head in mm)."""
    bb = body.boundingBox
    lo = [bb.minPoint.x, bb.minPoint.y, bb.minPoint.z]
    hi = [bb.maxPoint.x, bb.maxPoint.y, bb.maxPoint.z]
    ext = [hi[i] - lo[i] for i in range(3)]
    k = ext.index(max(ext))                       # the screw axis is its longest extent
    others = [i for i in range(3) if i != k]
    ctr = [(lo[i] + hi[i]) / 2.0 for i in range(3)]
    probe_r = 0.4 * min(ext[others[0]], ext[others[1]])   # outside the shank, inside the head/flange
    outside = adsk.fusion.PointContainment.PointOutsidePointContainment

    def solid_at(axial):
        for o in others:
            for sgn in (1, -1):
                p = list(ctr)
                p[k] = axial
                p[o] += sgn * probe_r
                if body.pointContainment(adsk.core.Point3D.create(p[0], p[1], p[2])) != outside:
                    return True
        return False

    n = 400
    step = ext[k] / n
    samples = [solid_at(lo[k] + (i + 0.5) * step) for i in range(n)]
    head_lo = any(samples[:n // 4])
    head_hi = any(samples[-(n // 4):])
    if head_lo == head_hi:
        raise RuntimeError('could not tell the screw head from its tip')
    if head_lo:       # head at the low end: under-head is just past the last solid sample
        last = max(i for i in range(n) if samples[i])
        under = lo[k] + (last + 1) * step
        axis_sign = 1.0
        shank = hi[k] - under
    else:
        first = min(i for i in range(n) if samples[i])
        under = lo[k] + first * step
        axis_sign = -1.0
        shank = under - lo[k]
    p = list(ctr)
    p[k] = under
    a = [0.0, 0.0, 0.0]
    a[k] = axis_sign
    return (adsk.core.Point3D.create(p[0], p[1], p[2]),
            adsk.core.Vector3D.create(a[0], a[1], a[2]), shank / MM)


def place_screws(design, target_comp, step_path, targets):
    """Import the screw STEP once and put an occurrence of it at each target.
    targets: [(x_mm, y_mm, z_mm, inward_z_sign)], the point where the underside of the head sits
    and the direction the shank points (+1 / -1 along Z).
    Returns (component, shank length in mm, number placed). Each stage raises with its own name."""
    stage = 'import'
    try:
        # Import into a component of its own inside target_comp. That occurrence stays hidden at
        # the origin; every bolt point gets a copy of it, so nothing is deleted.
        src = target_comp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        screw_comp = src.component
        screw_comp.name = 'McMaster_%s' % SCREW_PART
        im = adsk.core.Application.get().importManager
        im.importToTarget(im.createSTEPImportOptions(step_path), screw_comp)

        stage = 'unground'   # imported occurrences can come in grounded, which blocks moving them
        for o in [src] + list(screw_comp.allOccurrences):
            try:
                o.isGroundToParent = False
            except:
                pass

        stage = 'find body'
        best = None   # (volume, body, transform from the body's component into screw_comp)
        for b in screw_comp.bRepBodies:
            if best is None or b.volume > best[0]:
                best = (b.volume, b, None)
        for o in screw_comp.allOccurrences:   # STEP assemblies come in as nested occurrences
            for b in o.component.bRepBodies:
                if best is None or b.volume > best[0]:
                    best = (b.volume, b, o.transform2)
        if best is None:
            raise RuntimeError('the STEP file has no solid bodies')
        _, body, to_screw = best
        # The screw keeps the appearance from its STEP file: no material or appearance is set on it.

        stage = 'find screw axis'
        under_pt, axis, shank_mm = screw_frame(body)
        if to_screw is not None:
            under_pt.transformBy(to_screw)
            axis.transformBy(to_screw)

        stage = 'placement matrices'
        # Any vector not parallel to the axis gives the from-frame's X
        ref = adsk.core.Vector3D.create(1, 0, 0) if abs(axis.x) < 0.9 else adsk.core.Vector3D.create(0, 1, 0)
        xf = axis.crossProduct(ref)
        xf.normalize()
        yf = axis.crossProduct(xf)
        mats = []
        for (x, y, z, inward) in targets:
            zt = adsk.core.Vector3D.create(0, 0, inward)
            xt = adsk.core.Vector3D.create(1, 0, 0)
            yt = zt.crossProduct(xt)
            m = adsk.core.Matrix3D.create()
            m.setToAlignCoordinateSystems(under_pt, xf, yf, axis,
                                          adsk.core.Point3D.create(x * MM, y * MM, z * MM), xt, yt, zt)
            mats.append(m)

        # A copy at every bolt point. Fusion will not move the nested imported occurrence itself,
        # so that one stays hidden at the origin (it holds the screw's geometry for the copies).
        stage = 'copies'
        for m in mats:
            target_comp.occurrences.addExistingComponent(screw_comp, m)
        placed = len(mats)
        src.isLightBulbOn = False
        return screw_comp, shank_mm, placed
    except Exception:
        raise RuntimeError('stage "%s": %s' % (stage, last_error()))


def apply_looks(app, design, groups):
    """Assign physical materials and appearances by searching Fusion's libraries for keywords.
    Returns one summary line per group so you can see what was (or was not) found."""
    mats, apps = [], []
    try:
        for i in range(app.materialLibraries.count):
            lib = app.materialLibraries.item(i)
            for coll, out in ((lib.materials, mats), (lib.appearances, apps)):
                try:
                    for j in range(coll.count):
                        out.append((coll.item(j).name, coll.item(j)))
                except:
                    pass
    except:
        pass

    def find(items, kwsets, exclude=()):
        """First keyword set that matches wins. Keywords match whole words (so 'abs' does not hit
        'Formlabs'), and among several matches the shortest name is used (the plain variant)."""
        for kws in kwsets:
            hits = [(n, o) for n, o in items
                    if all(re.search(r'(?<![a-z0-9])' + re.escape(k) + r'(?![a-z0-9])', n.lower()) for k in kws)
                    and not any(x in n.lower() for x in exclude)]
            if hits:
                return min(hits, key=lambda h: len(h[0]))[1]
        return None

    def tinted(lib_app, name, rgb):
        ap = design.appearances.itemByName(name)
        if ap is None:
            ap = design.appearances.addByCopy(lib_app, name)
        if rgb:
            for prop in ap.appearanceProperties:
                if isinstance(prop, adsk.core.ColorProperty):
                    prop.value = adsk.core.Color.create(rgb[0], rgb[1], rgb[2], 255)
                    if prop.name == 'Color':
                        break
        return ap

    # Appearance names containing any of these are skipped (colored / see-through finishes)
    COLORED = ('blue', 'red', 'green', 'gold', 'yellow', 'orange', 'purple', 'pink', 'black', 'anodized', 'bronze')
    SEE_THROUGH = ('clear', 'translucent', 'transparent', 'glass', 'smoke', 'tint')

    #  key, label, material keywords, appearance keywords, tint color, appearance name, excluded words
    spec = [
        ('PC', 'Polycarbonate', [('polycarbonate',)],
         [('plastic', 'matte'), ('plastic', 'opaque'), ('plastic',)], (58, 60, 64),
         'Dark_Grey_Polycarbonate', SEE_THROUGH),
        ('BASE', 'Base plate', [('aluminum', '6061'), ('aluminum',)],
         [('aluminum', 'brushed'), ('aluminum', 'satin'), ('aluminum',)], None, 'Brushed_Aluminum', COLORED),
        ('STANDOFF', 'Standoffs', [('aluminum',)],
         [('aluminum', 'satin'), ('aluminum', 'brushed'), ('aluminum',)], (192, 194, 198),
         'Standoff_Aluminum', COLORED),
        ('TRAY', 'BMS tray (ABS)', [('abs',)],
         [('abs',), ('plastic', 'matte'), ('plastic',)], (35, 35, 38), 'ABS_Tray', ()),
        ('BUSBAR', 'Busbars', [('copper',)],
         [('copper', 'polished'), ('copper',), ('nickel',)], None, 'Busbar_Metal', ()),
        ('FOAM', 'Foam', [],
         [('foam',), ('rubber', 'matte'), ('fabric',), ('rubber',)], (40, 40, 44), 'Neoprene_Foam', ()),
        ('CELL', 'Cells', [],
         [('plastic', 'glossy'), ('paint', 'glossy'), ('plastic',)], (25, 95, 200), 'Cell_Wrap_Blue', ()),
    ]
    out = []
    for key, label, mat_kws, app_kws, rgb, ap_name, exclude in spec:
        bodies = groups.get(key, [])
        if not bodies:
            continue
        got_m, got_a = '-', 'not found'
        try:
            m = find(mats, mat_kws) if mat_kws else None
            if m is not None:
                for b in bodies:
                    b.material = m
                got_m = m.name
        except:
            got_m = 'failed'
        try:
            a = find(apps, app_kws, exclude)
            if a is not None:
                ap = tinted(a, ap_name, rgb)
                for b in bodies:
                    b.appearance = ap
                got_a = a.name
        except:
            got_a = 'failed: ' + last_error()
        out.append('%s: appearance=%s, material=%s' % (label, got_a, got_m))
    return out


class Cancelled(Exception):
    pass


def run(context):
    ui = None
    prog = None
    try:
        app = adsk.core.Application.get()
        ui = app.userInterface
        design = app.activeProduct
        if not isinstance(design, adsk.fusion.Design):
            ui.messageBox('Please switch to the Design workspace in Fusion 360 before running this script.')
            return
        try:
            design.designType = adsk.fusion.DesignTypes.ParametricDesignType
        except:
            pass
        rootComp = design.rootComponent
        design.fusionUnitsManager.distanceDisplayUnits = adsk.fusion.DistanceUnits.MillimeterDistanceUnits

        # Progress dialog: shows the current stage, has a Cancel button, and each stage
        # is also written to the Text Commands panel.
        prog = ui.createProgressDialog()
        prog.isCancelButtonShown = True
        prog.show('Generating enclosure', 'Starting...', 0, 6, 0)   # last arg: delay in s before it appears

        def say(msg):
            prog.message = msg
            adsk.doEvents()              # lets Fusion repaint the dialog
            app.log(msg)
            if prog.wasCancelled:
                raise Cancelled()

        timings = []   # (stage, seconds), shown in the result dialog
        t_start = [time.time()]

        def step(msg):
            now = time.time()
            if timings or prog.progressValue:
                timings[-1] = (timings[-1][0], now - t_start[0])
            t_start[0] = now
            timings.append((msg.split('  ', 1)[-1].rstrip('.'), 0.0))
            prog.progressValue += 1
            say(msg)

        step('1/6  Setting up parameters...')
        setup_parameters(design)
        cols = int(round(VALS['Columns']))
        rows = int(round(VALS['Rows']))
        fallback_pattern = False

        # Remove a previously generated assembly
        for o in list(rootComp.occurrences):
            if o.component.name.startswith(('EBike_Battery_Enclosure', '_screw_import')):   # + leftovers from an older screw import
                o.deleteMe()

        occ = rootComp.occurrences.addNewComponent(adsk.core.Matrix3D.create())
        assy = occ.component
        assy.name = 'EBike_Battery_Enclosure_%dS%dP' % (cols, rows)

        part_occs = {}

        def new_part(name, slide=True):
            m = adsk.core.Matrix3D.create()
            if slide and BASE_PLATE:   # battery parts are slid -X relative to the base plate
                m.translation = adsk.core.Vector3D.create(-VALS['Battery_Latch_Slide'] * MM, 0, 0)
            po = assy.occurrences.addNewComponent(m)
            po.component.name = name
            part_occs[name] = po
            return po.component

        # ---- Layout decided at run time (structural; re-run to respace) ----
        # Every side-plate edge runs bolt, tab, bolt, ..., bolt, evenly spaced between its corner
        # bolts (same rule as pack.geometry.edge_tabs). Counts are fixed when the script runs; the
        # spacing and lengths are parameters.
        PW2, PH2 = half('Plate_Width'), half('Plate_Height')
        CW2, CH2 = half('Cavity_Width'), half('Cavity_Height')
        bxe = sub(PW2, 'Bolt_Edge_Offset')
        bye = sub(PH2, 'Bolt_Edge_Offset')

        def edge(prefix, span_expr, min_count):
            n, pitch, length, offset = edge_layout(ev(span_expr), VALS, min_count)
            pname = prefix + '_Tab_Pitch'
            runtime_param(design, pname, '(%s) / %d' % (span_expr, n), 'mm',
                          'Bolt and tab spacing along the %s edges' % prefix.lower())
            runtime_param(design, prefix + '_Tab_Length', '%g mm' % length, 'mm',
                          'Tab (and slot) length on the %s walls' % prefix.lower())
            even = ['(2 * %d + 1 - %d) * %s / 2' % (i, n, pname) for i in range(n)]
            inner_bolts = ['(2 * %d - %d) * %s / 2' % (i, n, pname) for i in range(1, n)]
            if offset is None:
                return even, even, inner_bolts
            oname = prefix + '_Tab_Offset'
            runtime_param(design, oname, '%.4f mm' % offset, 'mm',
                          'Tight edge: tab center distance from the middle (no bolt between the tabs)')
            return [neg(oname), oname], even, []

        tab_xs, hook_slots, long_inner = edge('Long', 'Plate_Width - 2 * Bolt_Edge_Offset', 2)
        tab_ys, _even_ys, short_inner = edge('Short', 'Plate_Height - 2 * Bolt_Edge_Offset', 1)

        # One hook per bottom tab at the even pitch (on a tight edge the tabs are pulled in but the
        # hooks stay spread out); a single centered hook if two would crowd the base plate.
        if not BASE_PLATE:
            hook_xs = []    # no base plate, so nothing for hooks to latch into
        else:
            hook_xs = hook_slots
            if len(hook_xs) > 1 and not hooks_fit([ev(x) for x in hook_xs], VALS):
                hook_xs = ['0']

        # Bolts at the corners and midway between tabs on every edge (the standoffs hug the walls)
        row_xs = [neg(bxe)] + long_inner + [bxe]
        bolt_pts = ([(x, bye) for x in row_xs] + [(x, neg(bye)) for x in row_xs]
                    + [(neg(bxe), y) for y in short_inner] + [(bxe, y) for y in short_inner])

        # ==============================================================================
        # 1. SIDE PLATES (polycarbonate) with slots, dogbones, bolt holes and L-hooks
        # ==============================================================================
        step('2/6  Building side plates (slowest step)...')
        sideComp = new_part('PC_Side_Plates')
        left_plane = offset_plane(sideComp, sideComp.xYConstructionPlane,
                                  '-(Cavity_Depth/2 + Polycarbonate_Thickness)')

        def build_side_plate(plane, name):
            say('2/6  Side plate: ' + name + '...')
            sk = new_sketch(sideComp, plane, name + '_Outline')
            rect(sk, neg(PW2), PW2, neg(PH2), PH2, 'Plate_Width', 'Plate_Height')
            for hx in hook_xs:
                nx0 = sub(hx, half('Hook_Neck_Width'))
                nx1 = add(hx, half('Hook_Neck_Width'))
                y_low = neg(add(PH2, 'Hook_Drop'))
                rect(sk, nx0, nx1, y_low, sub('Hook_Overlap', PH2), 'Hook_Neck_Width', None)
                rect(sk, sub(nx0, 'Hook_Nose'), hx, y_low, neg(add(PH2, 'Alu_Thickness')), None, None)   # nose points -X
            ext_in = sideComp.features.extrudeFeatures.createInput(
                all_profiles(sk), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            ext_in.setDistanceExtent(False, vi('Polycarbonate_Thickness'))
            feat = sideComp.features.extrudeFeatures.add(ext_in)
            bodies = []
            for i in range(feat.bodies.count):
                b = feat.bodies.item(i)
                b.name = name if i == 0 else '%s_%d' % (name, i)
                bodies.append(b)

            # Fillets: plate corners centered on the corner bolts, small on the hooks' outside corners
            pw2, ph2 = VALS['Plate_Width'] / 2.0, VALS['Plate_Height'] / 2.0
            big = [(sx * pw2, sy * ph2) for sx in (-1, 1) for sy in (-1, 1)]
            fillet_edges(sideComp, find_edges(bodies[0], 'z', big), 'Side_Plate_Corner_Radius', 'side plate corners')
            small = []
            for hxs in hook_xs:
                hxv = ev(hxs)
                yl = -(ph2 + VALS['Hook_Drop'])
                small += [(hxv - VALS['Hook_Neck_Width'] / 2.0 - VALS['Hook_Nose'], yl),
                          (hxv - VALS['Hook_Neck_Width'] / 2.0 - VALS['Hook_Nose'], -(ph2 + VALS['Alu_Thickness'])),
                          (hxv + VALS['Hook_Neck_Width'] / 2.0, yl)]
            if small:
                fillet_edges(sideComp, find_edges(bodies[0], 'z', small), 'Fillet_Small', 'hook corners')

            # Slots (with dogbones) and bolt holes
            skc = new_sketch(sideComp, plane, name + '_Slots_Holes')
            slot_y = add(CH2, half('Polycarbonate_Thickness'))
            for tx in tab_xs:
                for sy in (slot_y, neg(slot_y)):
                    slot(skc, sub(tx, half('Long_Tab_Length')), add(tx, half('Long_Tab_Length')),
                         sub(sy, half('Slot_Width')), add(sy, half('Slot_Width')),
                         True, 'Long_Tab_Length', 'Slot_Width')
            slot_x = add(CW2, half('Polycarbonate_Thickness'))
            for sx in (slot_x, neg(slot_x)):
                for ty in tab_ys:
                    slot(skc, sub(sx, half('Slot_Width')), add(sx, half('Slot_Width')),
                         sub(ty, half('Short_Tab_Length')), add(ty, half('Short_Tab_Length')),
                         False, 'Slot_Width', 'Short_Tab_Length')
            for (bx, by) in bolt_pts:
                circle(skc, bx, by, 'Bolt_Hole_Diameter')
            # Hook root reliefs, sized like the slot dogbones: a router-diameter circle centered
            # on the neck's inside edge and tangent to the nose top, so it cuts only upward into
            # the neck. The nose top stays flat for the base plate to seat on and the nose keeps
            # its full height. (A fillet here would hit the base plate when latched.)
            for hx in hook_xs:
                circle(skc, sub(hx, half('Hook_Neck_Width')),
                       neg(sub(add(PH2, 'Alu_Thickness'), half('Min_CNC_Router_Diameter'))),
                       'Min_CNC_Router_Diameter')
            # Neck-to-plate reliefs: where each neck meets the plate's bottom edge, a router circle
            # centered on the edge and tangent to the neck side, so the router leaves no radius in
            # the corner and the plate seats flat on the base plate.
            for hx in hook_xs:
                for xe in (sub(sub(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter')),
                           add(add(hx, half('Hook_Neck_Width')), half('Min_CNC_Router_Diameter'))):
                    circle(skc, xe, neg(PH2), 'Min_CNC_Router_Diameter')

            cut_in = sideComp.features.extrudeFeatures.createInput(
                all_profiles(skc), adsk.fusion.FeatureOperations.CutFeatureOperation)
            cut_in.setDistanceExtent(False, vi('Polycarbonate_Thickness + Cut_Overshoot'))
            cut_in.participantBodies = bodies
            sideComp.features.extrudeFeatures.add(cut_in)
            return bodies

        front_bodies = build_side_plate(left_plane, 'Front_PC_Side_Plate')     # -Z

        # The rear plate is a mirror of the front plate about the mid-plane (Z = 0), so the two
        # stay identical and follow Cavity_Depth automatically.
        say('2/6  Mirroring the rear side plate...')
        try:
            mcol = adsk.core.ObjectCollection.create()
            for b in front_bodies:
                mcol.add(b)
            mf = sideComp.features.mirrorFeatures
            mir = mf.add(mf.createInput(mcol, sideComp.xYConstructionPlane))
            for i in range(mir.bodies.count):
                mir.bodies.item(i).name = 'Rear_PC_Side_Plate' if i == 0 else 'Rear_PC_Side_Plate_%d' % i
        except:
            ISSUES.append('Mirror of the rear side plate failed: %s' % last_error())

        if VALS['Lip_Width'] < VALS['Standoff_OD']:
            ISSUES.append('Warning: Lip_Width is smaller than Standoff_OD: the standoffs overhang the plate edge')

        # Fillet size sanity checks (a fillet that is too big makes the rebuild fail)
        if hook_xs and 2.0 * VALS['Fillet_Small'] > VALS['Hook_Drop_Extra']:
            ISSUES.append('Warning: Fillet_Small is large for the hook nose height (%.2f mm)' % VALS['Hook_Drop_Extra'])
        if hook_xs and VALS['Hook_Slot_Length'] < VALS['Hook_Neck_Width'] + VALS['Hook_Nose']:
            ISSUES.append('Warning: Hook_Slot_Length is shorter than neck + nose: the hooks will not drop through')

        # ==============================================================================
        # 2. INNER WALLS: four separate flat pieces, each with tabs (top/bottom full length, sides between)
        # ==============================================================================
        step('3/6  Building inner walls and tabs...')
        wallComp = new_part('PC_Inner_Walls')
        PCT = 'Polycarbonate_Thickness'

        def make_wall(name, x0, x1, y0, y1, w_expr, h_expr, tabs):
            """One flat wall piece as its own body. tabs = [(x0, x1, y0, y1, w_expr, h_expr)]."""
            skp = new_sketch(wallComp, wallComp.xYConstructionPlane, name + '_Profile')
            rect(skp, x0, x1, y0, y1, w_expr, h_expr)
            wi = wallComp.features.extrudeFeatures.createInput(
                skp.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            wi.setSymmetricExtent(vi('Cavity_Depth/2'), False)
            body = wallComp.features.extrudeFeatures.add(wi).bodies.item(0)
            body.name = name
            skt = new_sketch(wallComp, wallComp.xYConstructionPlane, name + '_Tabs')
            for (tx0, tx1, ty0, ty1, tw, th) in tabs:
                rect(skt, tx0, tx1, ty0, ty1, tw, th)
            ti = wallComp.features.extrudeFeatures.createInput(
                all_profiles(skt), adsk.fusion.FeatureOperations.JoinFeatureOperation)
            ti.setSymmetricExtent(vi('Cavity_Depth/2 + Tab_Depth'), False)
            try:
                ti.participantBodies = [body]
            except:
                pass
            wallComp.features.extrudeFeatures.add(ti)

        top_tabs, bot_tabs = [], []
        for tx in tab_xs:
            tx0, tx1 = sub(tx, half('Long_Tab_Length')), add(tx, half('Long_Tab_Length'))
            top_tabs.append((tx0, tx1, CH2, add(CH2, PCT), 'Long_Tab_Length', PCT))
            bot_tabs.append((tx0, tx1, neg(add(CH2, PCT)), neg(CH2), 'Long_Tab_Length', PCT))

        def short_tabs(xa, xb):
            return [(xa, xb, sub(ty, half('Short_Tab_Length')), add(ty, half('Short_Tab_Length')),
                     PCT, 'Short_Tab_Length') for ty in tab_ys]

        # Top and bottom walls run the full outside width; the left and right walls fit
        # between them (height = cavity height).
        FW = 'Cavity_Width + 2 * ' + PCT
        make_wall('Top_Wall', neg(add(CW2, PCT)), add(CW2, PCT), CH2, add(CH2, PCT), FW, PCT, top_tabs)
        make_wall('Bottom_Wall', neg(add(CW2, PCT)), add(CW2, PCT), neg(add(CH2, PCT)), neg(CH2), FW, PCT, bot_tabs)
        make_wall('Left_Wall', neg(add(CW2, PCT)), neg(CW2), neg(CH2), CH2,
                  PCT, 'Cavity_Height', short_tabs(neg(add(CW2, PCT)), neg(CW2)))
        make_wall('Right_Wall', CW2, add(CW2, PCT), neg(CH2), CH2,
                  PCT, 'Cavity_Height', short_tabs(CW2, add(CW2, PCT)))

        # Tab-root reliefs: both inside corners of every tab get a router circle centered on the
        # wall's end edge and tangent to the tab side, cut into the wall body. The tab keeps its
        # full size and the router leaves no radius where the side plate seats.
        say('3/6  Cutting tab reliefs...')
        walls = dict((b.name, b) for b in wallComp.bRepBodies)
        RD2 = half('Min_CNC_Router_Diameter')
        ZE = half('Cavity_Depth')

        def tab_reliefs(plane, name, along, centers, length_name, bodies):
            skr = new_sketch(wallComp, plane, name)
            axes = sketch_axes(skr)
            for t in centers:
                for pe in (sub(sub(t, half(length_name)), RD2), add(add(t, half(length_name)), RD2)):
                    for ze in (ZE, neg(ZE)):
                        model_circle(skr, axes, {along: pe, 'z': ze}, 'Min_CNC_Router_Diameter')
            ri = wallComp.features.extrudeFeatures.createInput(
                all_profiles(skr), adsk.fusion.FeatureOperations.CutFeatureOperation)
            ri.setAllExtent(adsk.fusion.ExtentDirections.SymmetricExtentDirection)
            ri.participantBodies = [b for b in bodies if b is not None]
            wallComp.features.extrudeFeatures.add(ri)

        try:
            tab_reliefs(wallComp.xZConstructionPlane, 'Long_Wall_Tab_Reliefs', 'x', tab_xs, 'Long_Tab_Length',
                        [walls.get('Top_Wall'), walls.get('Bottom_Wall')])
            tab_reliefs(wallComp.yZConstructionPlane, 'Short_Wall_Tab_Reliefs', 'y', tab_ys, 'Short_Tab_Length',
                        [walls.get('Left_Wall'), walls.get('Right_Wall')])
        except Cancelled:
            raise
        except:
            ISSUES.insert(0, 'Tab reliefs failed: %s' % last_error())

        # ==============================================================================
        # 3. INTERNAL CORE: BMS tray, cells (patterned), busbars, foam liner
        # ==============================================================================
        step('4/6  Building cells, busbars, tray and foam...')
        intComp = new_part('Internal_Core_ABS_Foam_Cells')
        CCW2 = half('Cell_Core_Width')
        y_tray_bot = add(neg(CH2), 'Foam_Thickness')
        y_tray_top = add(y_tray_bot, 'BMS_Height')

        # ABS tray
        sk_abs = new_sketch(intComp, intComp.xYConstructionPlane, 'BMS_Tray')
        rect(sk_abs, neg(CCW2), CCW2, y_tray_bot, y_tray_top, 'Cell_Core_Width', 'BMS_Height')
        abs_in = intComp.features.extrudeFeatures.createInput(
            sk_abs.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        abs_in.setSymmetricExtent(vi('Core_Depth/2'), False)
        intComp.features.extrudeFeatures.add(abs_in).bodies.item(0).name = 'ABS_BMS_Fuse_Wire_Tray'

        # One cell, then a rectangular pattern bound to Columns / Rows / Cell_Pitch
        sk_cell = new_sketch(intComp, intComp.xYConstructionPlane, 'Cell_Layout')
        circle(sk_cell, add(neg(CCW2), half('Cell_Pitch')), add(y_tray_top, half('Cell_Pitch')), 'Cell_Diameter')
        cell_in = intComp.features.extrudeFeatures.createInput(
            sk_cell.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        cell_in.setSymmetricExtent(vi('Cell_Height/2'), False)
        cell_body = intComp.features.extrudeFeatures.add(cell_in).bodies.item(0)
        cell_body.name = '21700_Cell'

        def make_pattern(q1, q2):
            bodies = adsk.core.ObjectCollection.create()
            bodies.add(cell_body)
            pat = intComp.features.rectangularPatternFeatures
            pin = pat.createInput(bodies, intComp.xConstructionAxis, q1, vi('Cell_Pitch'),
                                  adsk.fusion.PatternDistanceType.SpacingPatternDistanceType)
            pin.setDirectionTwo(intComp.yConstructionAxis, q2, vi('Cell_Pitch'))
            return pat.add(pin)

        try:
            make_pattern(vi('Columns'), vi('Rows'))
        except:
            fallback_pattern = True
            make_pattern(adsk.core.ValueInput.createByReal(cols), adsk.core.ValueInput.createByReal(rows))

        # Busbars (plates on both cell ends)
        def make_busbar(plane_expr, name):
            pl = offset_plane(intComp, intComp.xYConstructionPlane, plane_expr)
            sk = new_sketch(intComp, pl, name + '_Sketch')
            rect(sk, neg(CCW2), CCW2, y_tray_top, add(y_tray_top, 'Cell_Core_Height'),
                 'Cell_Core_Width', 'Cell_Core_Height')
            bi = intComp.features.extrudeFeatures.createInput(
                sk.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            bi.setDistanceExtent(False, vi('Busbar_Height'))
            intComp.features.extrudeFeatures.add(bi).bodies.item(0).name = name

        make_busbar('-(Cell_Height/2 + Busbar_Height)', 'Busbar_Front')
        make_busbar('Cell_Height/2', 'Busbar_Rear')

        # Foam liner (perimeter ring)
        sk_foam = new_sketch(intComp, intComp.xYConstructionPlane, 'Foam_Liner')
        rect(sk_foam, neg(CW2), CW2, neg(CH2), CH2, 'Cavity_Width', 'Cavity_Height')
        fi_x = sub(CW2, 'Foam_Thickness')
        fi_y = sub(CH2, 'Foam_Thickness')
        rect(sk_foam, neg(fi_x), fi_x, neg(fi_y), fi_y,
             'Cavity_Width - 2 * Foam_Thickness', 'Cavity_Height - 2 * Foam_Thickness')
        for p in sk_foam.profiles:
            if p.profileLoops.count == 2:
                fe = intComp.features.extrudeFeatures.createInput(
                    p, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
                fe.setSymmetricExtent(vi('Core_Depth/2'), False)
                intComp.features.extrudeFeatures.add(fe).bodies.item(0).name = 'Neoprene_Foam_Perimeter'
                break

        # ==============================================================================
        # 4. ALUMINUM BASE PLATE
        # ==============================================================================
        baseComp = None
        if not BASE_PLATE:
            step('5/6  No base plate (BASE_PLATE = False)')
        else:
            step('5/6  Building aluminum base plate...')
            baseComp = new_part('Alu_6061_Base_Plate', slide=False)
            base_plane = offset_plane(baseComp, baseComp.xYConstructionPlane,
                                      '-(Cavity_Depth/2 + Polycarbonate_Thickness + Side_Extension)')
            sk_base = new_sketch(baseComp, base_plane, 'Base_Profile')
            # Extensions are measured from the battery's slid (latched) position
            bx0 = neg(add(add(PW2, 'Base_Rear_Extension'), 'Battery_Latch_Slide'))
            bx1 = sub(add(PW2, 'Base_Front_Extension'), 'Battery_Latch_Slide')
            rect(sk_base, bx0, bx1, neg(add(PH2, 'Alu_Thickness')), neg(PH2), 'Base_Plate_X_Length', 'Alu_Thickness')
            b_in = baseComp.features.extrudeFeatures.createInput(
                sk_base.profiles.item(0), adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
            b_in.setDistanceExtent(False, vi('Base_Plate_Z_Width'))
            base_body = baseComp.features.extrudeFeatures.add(b_in).bodies.item(0)
            bx0v = -(VALS['Plate_Width'] / 2.0 + VALS['Base_Rear_Extension'] + VALS['Battery_Latch_Slide'])
            bx1v = VALS['Plate_Width'] / 2.0 + VALS['Base_Front_Extension'] - VALS['Battery_Latch_Slide']
            bz = VALS['Base_Plate_Z_Width'] / 2.0
            fillet_edges(baseComp, find_edges(base_body, 'y', [(x, z) for x in (bx0v, bx1v) for z in (-bz, bz)]),
                         'Fillet_Large', 'base plate corners')
            base_body.name = 'Aluminum_6061_Base_Plate'

            # Hook slots: sketched on the XZ plane. Find how sketch axes map to model X / Z.
            sk_bcut = new_sketch(baseComp, baseComp.xZConstructionPlane, 'Base_Hook_Slots')
            m = sk_bcut.modelToSketchSpace(adsk.core.Point3D.create(1, 0, 1))
            fx = 1 if m.x > 0 else -1
            fy = 1 if m.y > 0 else -1

            def to_sketch(f, a, b):
                return (a, b) if f > 0 else (neg(b), neg(a))

            z_ctr = add(half('Cavity_Depth'), half('Polycarbonate_Thickness'))
            for hx in hook_xs:
                # Slots stay fixed in the base plate's own frame (nominal hook positions). The
                # battery is slid -X by Battery_Latch_Slide, which puts each hook neck
                # against the front (-X) end of its slot with the nose under solid plate.
                xa = sub(hx, sub('Hook_Slot_Length', 'Hook_Slot_Offset'))
                xb = add(hx, 'Hook_Slot_Offset')
                for zc in (z_ctr, neg(z_ctr)):
                    za, zb = sub(zc, half('Slot_Width')), add(zc, half('Slot_Width'))
                    sx0, sx1 = to_sketch(fx, xa, xb)
                    sy0, sy1 = to_sketch(fy, za, zb)
                    rect(sk_bcut, sx0, sx1, sy0, sy1, 'Hook_Slot_Length', 'Slot_Width')
            bc_in = baseComp.features.extrudeFeatures.createInput(
                all_profiles(sk_bcut), adsk.fusion.FeatureOperations.CutFeatureOperation)
            bc_in.setAllExtent(adsk.fusion.ExtentDirections.SymmetricExtentDirection)
            bc_in.participantBodies = [base_body]
            baseComp.features.extrudeFeatures.add(bc_in)

        # ==============================================================================
        # 5. HARDWARE: standoff sleeves
        # ==============================================================================
        step('6/6  Building standoffs...')
        hwComp = new_part('Hardware_Standoffs')
        sk_hw = new_sketch(hwComp, hwComp.xYConstructionPlane, 'Standoffs')
        for (px, py) in bolt_pts:
            outer = circle(sk_hw, px, py, 'Standoff_OD')
            inner = circle(sk_hw, px, py, 'Standoff_ID', locate=False)
            try:
                sk_hw.geometricConstraints.addCoincident(inner.centerSketchPoint, outer.centerSketchPoint)
            except:
                ISSUES.append('Standoffs: concentric constraint failed: %s' % last_error())
        s_profs = adsk.core.ObjectCollection.create()
        for p in sk_hw.profiles:
            if p.profileLoops.count == 2:
                s_profs.add(p)
        s_in = hwComp.features.extrudeFeatures.createInput(
            s_profs, adsk.fusion.FeatureOperations.NewBodyFeatureOperation)
        s_in.setSymmetricExtent(vi('Cavity_Depth/2'), False)
        hwComp.features.extrudeFeatures.add(s_in)

        # Screws: one McMaster screw at every bolt point on both side plates, head on the plate's
        # outer face, threading into the standoff. Positions are fixed when the script runs (like
        # the tab and bolt counts): re-run after changing the pack size.
        say('6/6  Placing screws...')
        step_path = find_hardware_file(SCREW_PART)
        if step_path is None:
            ISSUES.insert(0, 'Screws skipped: put the McMaster %s STEP file in fusion/hardware/' % SCREW_PART)
        else:
            try:
                scComp = new_part('Hardware_Screws_%s' % SCREW_PART)
                z_face = VALS['Cavity_Depth'] / 2.0 + VALS['Polycarbonate_Thickness']
                targets = [(ev(px), ev(py), side * z_face, -side) for (px, py) in bolt_pts for side in (-1, 1)]
                screw_comp, shank, placed = place_screws(design, scComp, step_path, targets)
                if placed != len(targets):
                    ISSUES.insert(0, 'Screws: placed %d of %d' % (placed, len(targets)))
                engage = shank - VALS['Polycarbonate_Thickness']
                if engage < 1.5 * 5.0:
                    ISSUES.append('Warning: screws engage only %.1f mm of thread in the standoffs (want >= 7.5)' % engage)
                if engage > VALS['Cavity_Depth'] / 2.0:
                    ISSUES.append('Warning: screws are too long: the two screws in each standoff collide')
            except:
                ISSUES.insert(0, 'Screws failed: %s' % last_error())

        # ==============================================================================
        # 6. GROUND THE BASE PLATE (OR THE SIDE PLATES), THEN MATERIALS AND APPEARANCES
        # ==============================================================================
        say('Grounding and applying materials...')
        anchor = 'Alu_6061_Base_Plate' if BASE_PLATE else 'PC_Side_Plates'
        try:
            part_occs[anchor].isGroundToParent = True
            for nm, po in part_occs.items():
                if nm != anchor:
                    po.isGroundToParent = False
        except:
            ISSUES.append('Grounding %s failed: %s' % (anchor, last_error()))
        look_lines = apply_looks(app, design, {
            'PC': [b for c in (sideComp, wallComp) for b in c.bRepBodies],
            'BASE': list(baseComp.bRepBodies) if baseComp else [],
            'STANDOFF': list(hwComp.bRepBodies),
            'TRAY': [b for b in intComp.bRepBodies if b.name.startswith('ABS')],
            'BUSBAR': [b for b in intComp.bRepBodies if b.name.startswith('Busbar')],
            'FOAM': [b for b in intComp.bRepBodies if b.name.startswith('Neoprene')],
            'CELL': [b for b in intComp.bRepBodies
                     if not b.name.startswith(('ABS', 'Busbar', 'Neoprene'))],
        })

        # Remember where the generated timeline ends, so export_design.py can tell features
        # added by hand afterwards from the ones this script made.
        try:
            design.attributes.add('ebike_enclosure', 'generated_timeline_end', str(design.timeline.count))
        except:
            ISSUES.append('Could not record the timeline marker: %s' % last_error())

        app.activeViewport.fit()
        prog.hide()
        prog = None

        # ---- Report ----
        under = []
        for s in SKETCHES:
            if not s.isFullyConstrained:
                n_loose = sum(1 for i in range(s.sketchCurves.count)
                              if not s.sketchCurves.item(i).isFullyConstrained)
                under.append('%s (%d of %d curves loose; %d dims, %d constraints)' % (
                    s.name, n_loose, s.sketchCurves.count, s.sketchDimensions.count, s.geometricConstraints.count))
        for issue in ISSUES:
            app.log(issue)
        if timings:
            timings[-1] = (timings[-1][0], time.time() - t_start[0])
        msg = '%dS%dP enclosure generated%s.\n' % (cols, rows, '' if BASE_PLATE else ' (no base plate)')
        try:
            here = os.path.abspath(__file__)
        except NameError:
            here = '?'
        msg += 'Script: %s\n' % here
        msg += ('Package script for %s (parameters set to that pack).\n' % CONFIG_NAME if CONFIG_NAME
                else 'Repo script: parameters already in this design were kept.\n')
        msg += 'Time: %.0f s (%s)\n\n' % (sum(t for _, t in timings),
                                          ', '.join('%s %.0f s' % (n, t) for n, t in timings))
        msg += 'Fully defined sketches: %d of %d.\n' % (len(SKETCHES) - len(under), len(SKETCHES))
        if under:
            msg += 'Not fully defined:\n  ' + '\n  '.join(under[:8]) + ('\n  ...' if len(under) > 8 else '') + '\n'
        if ISSUES:
            msg += '\n%d dimension/constraint problems, first few:\n' % len(ISSUES)
            msg += '\n'.join(ISSUES[:5]) + '\n'
        if fallback_pattern:
            msg += '\nNote: the cell pattern could not be bound to Columns/Rows, so it uses fixed counts. '
            msg += 'Re-run the script after changing Columns or Rows.\n'
        if look_lines:
            msg += '\nMaterials:\n  ' + '\n  '.join(look_lines) + '\n'
        msg += '\nEdit values in Modify > Change Parameters.'
        ui.messageBox(msg)

    except Cancelled:
        if prog:
            prog.hide()
        if ui:
            ui.messageBox('Cancelled. The assembly is only partly built; re-run the script to rebuild it.')
    except:
        if prog:
            prog.hide()
        if ui:
            ui.messageBox('Failed:\n{}'.format(traceback.format_exc()))
