#!/usr/bin/env python3
"""Generate SendCutSend-ready DXF files (one part per file) from a pack config.

    python dxf/generate_dxf.py config/default_20s4p.json -o output/dxf

Writes one DXF per distinct part, a manifest.json (material, thickness, quantity, size,
etch label, order notes) and, if matplotlib is installed, a PNG preview of each part.
Cut geometry is on layer CUT; etched part-number text is on layer SCS_SLE.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
for extra in (ROOT / "src", Path(__file__).resolve().parent):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from dxf_io import DxfCircle, DxfDrawing, DxfPolyline, write_dxf  # noqa: E402
from pack.config import ConfigError, load_config  # noqa: E402
from pack.contours import Circle  # noqa: E402
from pack.geometry import Part, build_parts, check_design  # noqa: E402
from pack.labels import Label, make_label  # noqa: E402

CUT_LAYER = "CUT"
ETCH_LAYER = "SCS_SLE"     # SendCutSend's single-line-etch layer name
MM_PER_INCH = 25.4


def part_drawing(part: Part, label: Label) -> DxfDrawing:
    d = DxfDrawing()
    d.polylines.append(DxfPolyline(list(part.outline.vertices), True, CUT_LAYER))
    for c in part.cutouts:
        if isinstance(c, Circle):
            d.circles.append(DxfCircle(c.cx, c.cy, c.r, CUT_LAYER))
        else:
            d.polylines.append(DxfPolyline(list(c.vertices), True, CUT_LAYER))
    if label.etch:
        for stroke in label.strokes:
            d.polylines.append(DxfPolyline([(x, y, 0.0) for x, y in stroke], False, ETCH_LAYER))
    return d


def generate(config_path: Path, out_dir: Path, previews: bool = True) -> dict:
    cfg = load_config(config_path)
    parts = build_parts(cfg)
    warnings = check_design(cfg, parts)
    out_dir.mkdir(parents=True, exist_ok=True)

    render = None
    if previews:
        try:
            import matplotlib  # noqa: F401  (preview imports it only when rendering)
            from preview import render_png as render  # noqa: F401
        except ImportError:
            warnings.append("matplotlib is not installed: previews skipped")

    entries, notes = [], []
    for part in parts:
        label = make_label(part, cfg)
        fname = f"{part.part_number}_{part.key}.dxf"
        write_dxf(out_dir / fname, part_drawing(part, label))
        preview_name = None
        if render is not None:
            preview_name = fname.replace(".dxf", ".png")
            render(out_dir / fname, out_dir / preview_name, f"{part.part_number} {part.description}")
        w, h = part.size
        entries.append({
            "part_number": part.part_number,
            "key": part.key,
            "description": part.description,
            "file": fname,
            "preview": preview_name,
            "material": part.material,
            "thickness_mm": part.thickness_mm,
            "thickness_in": round(part.thickness_mm / MM_PER_INCH, 3),
            "quantity": part.quantity,
            "process": part.process,
            "size_mm": [round(w, 2), round(h, 2)],
            "holes": sum(isinstance(c, Circle) for c in part.cutouts),
            "slots": sum(not isinstance(c, Circle) for c in part.cutouts),
            "label": {"lines": list(label.lines), "etched": label.etch,
                      "layer": ETCH_LAYER if label.etch else None,
                      "note": label.reason or "single-line etch on layer SCS_SLE"},
        })
        if label.etch:
            notes.append(f"{part.part_number}: single-line etch (layer {ETCH_LAYER}). Add an order note; "
                         "etched parts cannot be deburred or finished.")
        else:
            notes.append(f"{part.part_number}: not etched. {label.reason}. Mark it "
                         f"'{part.part_number}' by hand.")

    manifest = {"config": cfg.get("name", config_path.stem), "units": "mm",
                "parts": entries, "order_notes": notes, "warnings": warnings}
    (out_dir / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    return manifest


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("config", type=Path, help="pack config JSON (e.g. config/default_20s4p.json)")
    ap.add_argument("-o", "--out", type=Path, default=Path("output/dxf"), help="output directory")
    ap.add_argument("--no-preview", action="store_true", help="skip PNG previews")
    args = ap.parse_args(argv)
    try:
        manifest = generate(args.config, args.out, previews=not args.no_preview)
    except (ConfigError, ValueError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    for p in manifest["parts"]:
        print(f"{p['file']}: {p['material']} {p['thickness_mm']} mm, qty {p['quantity']}, "
              f"{p['size_mm'][0]} x {p['size_mm'][1]} mm, {p['holes']} holes, {p['slots']} slots")
    for w in manifest["warnings"]:
        print(f"WARNING: {w}")
    print(f"wrote {len(manifest['parts'])} DXF files and manifest.json to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
