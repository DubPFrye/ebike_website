"""Render a DXF (as written by dxf_io) to a PNG so a part can be checked by eye."""
from __future__ import annotations

from pathlib import Path

from dxf_io import read_dxf
from pack.contours import Polyline


def render_png(dxf_path: str | Path, png_path: str | Path, title: str = "") -> None:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    drawing = read_dxf(dxf_path)
    xs, ys = [], []
    fig_ax = []
    for pl in drawing.polylines:
        if pl.closed:
            pts = Polyline(tuple(pl.vertices)).points(0.02)
            pts = pts + [pts[0]]
        else:
            pts = [(x, y) for x, y, _ in pl.vertices]
        xs += [p[0] for p in pts]
        ys += [p[1] for p in pts]
        fig_ax.append((pl.layer, pts))
    for c in drawing.circles:
        xs += [c.cx - c.r, c.cx + c.r]
        ys += [c.cy - c.r, c.cy + c.r]
    w, h = max(xs) - min(xs), max(ys) - min(ys)
    fig_w = 12.0
    fig, ax = plt.subplots(figsize=(fig_w, max(1.8, fig_w * h / w + 0.9)))
    colors = {"CUT": "#111111", "SCS_SLE": "#d62728"}
    for layer, pts in fig_ax:
        ax.plot([p[0] for p in pts], [p[1] for p in pts], color=colors.get(layer, "#1f77b4"),
                linewidth=0.9 if layer == "CUT" else 0.8)
    for c in drawing.circles:
        circ = plt.Circle((c.cx, c.cy), c.r, fill=False, color=colors.get(c.layer, "#1f77b4"), linewidth=0.9)
        ax.add_patch(circ)
    ax.set_aspect("equal")
    ax.set_xlim(min(xs) - 5, max(xs) + 5)
    ax.set_ylim(min(ys) - 5, max(ys) + 5)
    ax.set_xlabel("mm")
    ax.grid(True, linewidth=0.3, alpha=0.5)
    ax.set_title(f"{title}   {w:.1f} x {h:.1f} mm   (black: cut, red: etch)", fontsize=10)
    fig.tight_layout()
    fig.savefig(png_path, dpi=110)
    plt.close(fig)
