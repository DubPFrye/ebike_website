"""Minimal DXF reader/writer: closed/open polylines with arc bulges, circles and lines.

Files are written as AutoCAD R12 (AC1009) ASCII, the most widely supported DXF flavor for
laser and router shops, with units set to millimeters. No third-party packages are needed.
The reader understands what this writer produces plus LWPOLYLINE/LINE, so tests and previews
can check the actual file content (and files saved by other tools).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Iterable, Sequence

Vertex = tuple[float, float, float]   # x, y, bulge


@dataclass
class DxfPolyline:
    vertices: list[Vertex]
    closed: bool
    layer: str


@dataclass
class DxfCircle:
    cx: float
    cy: float
    r: float
    layer: str


@dataclass
class DxfDrawing:
    polylines: list[DxfPolyline] = field(default_factory=list)
    circles: list[DxfCircle] = field(default_factory=list)
    units: str = "mm"

    def layers(self) -> set[str]:
        return {e.layer for e in self.polylines} | {e.layer for e in self.circles}


def _num(v: float) -> str:
    s = f"{v:.6f}".rstrip("0").rstrip(".")
    return "0" if s in ("-0", "") else s


def write_dxf(path: str | Path, drawing: DxfDrawing) -> None:
    """Write the drawing as an R12 ASCII DXF in millimeters."""
    out: list[str] = []

    def g(code: int, value: object) -> None:
        out.append(f"{code:>3}")
        out.append(value if isinstance(value, str) else _num(float(value)) if isinstance(value, float) else str(value))

    layers = sorted(drawing.layers() | {"0"})
    g(0, "SECTION"); g(2, "HEADER")
    g(9, "$ACADVER"); g(1, "AC1009")
    g(9, "$INSUNITS"); g(70, 4)          # 4 = millimeters
    g(9, "$MEASUREMENT"); g(70, 1)       # metric
    g(0, "ENDSEC")
    g(0, "SECTION"); g(2, "TABLES")
    g(0, "TABLE"); g(2, "LTYPE"); g(70, 1)
    g(0, "LTYPE"); g(2, "CONTINUOUS"); g(70, 0); g(3, "Solid line"); g(72, 65); g(73, 0); g(40, 0.0)
    g(0, "ENDTAB")
    g(0, "TABLE"); g(2, "LAYER"); g(70, len(layers))
    for i, name in enumerate(layers):
        g(0, "LAYER"); g(2, name); g(70, 0); g(62, 7 if name != "SCS_SLE" else 1); g(6, "CONTINUOUS")
    g(0, "ENDTAB")
    g(0, "ENDSEC")
    g(0, "SECTION"); g(2, "ENTITIES")
    for pl in drawing.polylines:
        g(0, "POLYLINE"); g(8, pl.layer); g(66, 1)
        g(10, 0.0); g(20, 0.0); g(30, 0.0); g(70, 1 if pl.closed else 0)
        for x, y, b in pl.vertices:
            g(0, "VERTEX"); g(8, pl.layer); g(10, x); g(20, y); g(30, 0.0)
            if b:
                g(42, b)
        g(0, "SEQEND"); g(8, pl.layer)
    for c in drawing.circles:
        g(0, "CIRCLE"); g(8, c.layer); g(10, c.cx); g(20, c.cy); g(30, 0.0); g(40, c.r)
    g(0, "ENDSEC")
    g(0, "EOF")
    Path(path).write_text("\n".join(out) + "\n", encoding="ascii")


def _pairs(text: str) -> list[tuple[int, str]]:
    lines = text.splitlines()
    if len(lines) % 2:
        lines.append("")
    return [(int(lines[i].strip()), lines[i + 1].strip()) for i in range(0, len(lines), 2)]


def read_dxf(path: str | Path) -> DxfDrawing:
    """Read polylines (POLYLINE/VERTEX and LWPOLYLINE), circles and lines from an ASCII DXF."""
    pairs = _pairs(Path(path).read_text(encoding="ascii", errors="replace"))
    drawing = DxfDrawing()
    i, n = 0, len(pairs)
    in_entities = False
    while i < n:
        code, val = pairs[i]
        if code == 0 and val == "SECTION" and i + 1 < n:
            in_entities = pairs[i + 1] == (2, "ENTITIES")
        if code == 9 and val == "$INSUNITS" and i + 1 < n:
            drawing.units = {"4": "mm", "1": "in"}.get(pairs[i + 1][1], "unknown")
        if not (in_entities and code == 0):
            i += 1
            continue
        if val == "POLYLINE":
            layer, closed, verts = "0", False, []
            i += 1
            while i < n and pairs[i][0] != 0:
                c, v = pairs[i]
                layer = v if c == 8 else layer
                closed = bool(int(v) & 1) if c == 70 else closed
                i += 1
            while i < n and pairs[i] != (0, "SEQEND"):
                if pairs[i] == (0, "VERTEX"):
                    x = y = b = 0.0
                    i += 1
                    while i < n and pairs[i][0] != 0:
                        c, v = pairs[i]
                        x, y, b = (float(v) if c == 10 else x, float(v) if c == 20 else y,
                                   float(v) if c == 42 else b)
                        i += 1
                    verts.append((x, y, b))
                else:
                    i += 1
            drawing.polylines.append(DxfPolyline(verts, closed, layer))
        elif val == "LWPOLYLINE":
            layer, closed, verts = "0", False, []
            i += 1
            while i < n and pairs[i][0] != 0:
                c, v = pairs[i]
                if c == 8:
                    layer = v
                elif c == 70:
                    closed = bool(int(v) & 1)
                elif c == 10:
                    verts.append((float(v), 0.0, 0.0))
                elif c == 20 and verts:
                    verts[-1] = (verts[-1][0], float(v), verts[-1][2])
                elif c == 42 and verts:
                    verts[-1] = (verts[-1][0], verts[-1][1], float(v))
                i += 1
            drawing.polylines.append(DxfPolyline(verts, closed, layer))
        elif val == "CIRCLE":
            layer, cx, cy, r = "0", 0.0, 0.0, 0.0
            i += 1
            while i < n and pairs[i][0] != 0:
                c, v = pairs[i]
                layer = v if c == 8 else layer
                cx, cy, r = (float(v) if c == 10 else cx, float(v) if c == 20 else cy,
                             float(v) if c == 40 else r)
                i += 1
            drawing.circles.append(DxfCircle(cx, cy, r, layer))
        elif val == "LINE":
            layer, x1, y1, x2, y2 = "0", 0.0, 0.0, 0.0, 0.0
            i += 1
            while i < n and pairs[i][0] != 0:
                c, v = pairs[i]
                layer = v if c == 8 else layer
                x1, y1, x2, y2 = (float(v) if c == 10 else x1, float(v) if c == 20 else y1,
                                  float(v) if c == 11 else x2, float(v) if c == 21 else y2)
                i += 1
            drawing.polylines.append(DxfPolyline([(x1, y1, 0.0), (x2, y2, 0.0)], False, layer))
        else:
            i += 1
    return drawing
