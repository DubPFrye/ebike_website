#!/usr/bin/env python3
"""Generate a priced bill of materials from a pack config and data/parts.csv.

    python bom/generate_bom.py config/default_20s4p.json -o output/bom

Quantities come from the config and pack.geometry (the same numbers the Fusion script and the
DXF generator use); prices, suppliers and part numbers come from data/parts.csv, never from code.
Writes bom.csv and bom.md, and prints the lines that still have no price.
"""
from __future__ import annotations

import argparse
import csv
import math
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "src") not in sys.path:
    sys.path.insert(0, str(ROOT / "src"))

from pack.config import ConfigError, load_config  # noqa: E402
from pack.geometry import build_parts, derive_dimensions, derive_layout  # noqa: E402

DEFAULT_PARTS = ROOT / "data" / "parts.csv"
PARTS_COLUMNS = ("key", "item", "category", "unit", "pack_qty", "pack_price_usd", "supplier", "part_number", "notes")


@dataclass(frozen=True)
class BomLine:
    key: str
    item: str
    description: str        # what this pack needs, computed from the config
    quantity: float
    unit: str
    packs: int              # packs to buy (quantity rounded up to whole packs)
    pack_qty: int
    pack_price: float | None
    supplier: str
    part_number: str
    notes: str

    @property
    def cost(self) -> float | None:
        return None if self.pack_price is None else round(self.packs * self.pack_price, 2)


def load_parts(path: str | Path = DEFAULT_PARTS) -> dict[str, dict[str, str]]:
    """Read parts.csv into {key: row}. Fails with a clear message on a bad file."""
    with open(path, newline="", encoding="utf-8") as fh:
        reader = csv.DictReader(fh)
        missing = [c for c in PARTS_COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise ConfigError(f"{path} is missing column(s): {', '.join(missing)}")
        rows: dict[str, dict[str, str]] = {}
        for row in reader:
            key = row["key"].strip()
            if key in rows:
                raise ConfigError(f"{path}: duplicate key {key!r}")
            rows[key] = row
    return rows


def _price(row: dict[str, str], key: str) -> float | None:
    text = (row.get("pack_price_usd") or "").strip()
    if not text:
        return None
    try:
        return float(text)
    except ValueError:
        raise ConfigError(f"parts.csv: pack_price_usd for {key!r} is not a number: {text!r}") from None


def _pack_qty(row: dict[str, str], key: str) -> int:
    text = (row.get("pack_qty") or "1").strip() or "1"
    try:
        n = int(text)
    except ValueError:
        raise ConfigError(f"parts.csv: pack_qty for {key!r} must be a whole number, got {text!r}") from None
    if n < 1:
        raise ConfigError(f"parts.csv: pack_qty for {key!r} must be at least 1")
    return n


def quantities(cfg: dict[str, Any]) -> list[tuple[str, float, str]]:
    """(parts.csv key, quantity, description) for everything this pack needs."""
    d = derive_dimensions(cfg)
    lay = derive_layout(d)
    pack = cfg["pack"]
    series, parallel = int(pack["series"]), int(pack["parallel"])
    cells = series * parallel
    bolts = len(lay.bolt_points)
    pitch = d.cell_pitch
    holder_key = f"cell_holder_{pitch:g}"
    # Rough nickel estimate: a strip along every parallel group (one column of cells) at both ends
    strip_m = 2 * d.columns * d.rows * pitch / 1000.0
    # Foam lines the six inside faces of the cavity
    cw, ch, cd = d.cavity_width, d.cavity_height, d.cavity_depth
    foam_m2 = 2 * (cw * ch + cw * cd + ch * cd) / 1e6

    strip_note = "estimate: one strip per parallel group, both ends; add series links"
    if cfg["cell"].get("format") == "18650":
        strip_note += "; 18650 strip is sold at 20.2 mm spacing, which fits these holders"
    out: list[tuple[str, float, str]] = [
        ("cell", cells, f"{cfg['cell'].get('name', cfg['cell']['format'])}, {series}S{parallel}P"),
        (holder_key, 2 * cells, f"{pitch:g} mm pitch, one at each end of {cells} cells"),
        ("nickel_strip", round(strip_m, 2), strip_note),
        ("bms", 1, f"{series}S"),
    ]
    for part in build_parts(cfg):
        w, h = part.size
        out.append((f"cut_{part.part_number.split('-')[-1]}", part.quantity,
                    f"{part.part_number}, {part.material} {part.thickness_mm:g} mm, {w:.1f} x {h:.1f} mm"))
    out += [
        ("screw_m5x16", 2 * bolts, f"{bolts} bolt points x 2 (one each side plate)"),
        ("standoff_m5", bolts, f"{d.cavity_depth:g} mm long, {d.standoff_od:g} mm OD, M5 thread both ends"),
        ("foam_liner", round(foam_m2, 3), f"{d.foam_thickness:g} mm thick (squeezed to {d.foam_gap:g} mm), lines all six faces of the "
                                         f"{cw:.0f} x {ch:.0f} x {cd:.0f} mm cavity"),
        ("bms_tray", 1, f"{d.cell_core_width:.0f} x {d.bms_height:g} mm"),
    ]
    return out


def build_bom(cfg: dict[str, Any], parts: dict[str, dict[str, str]]) -> list[BomLine]:
    lines: list[BomLine] = []
    needed = quantities(cfg)
    missing = [key for key, _, _ in needed if key not in parts]
    if missing:
        raise ConfigError("parts.csv has no row for: " + ", ".join(missing))
    for key, qty, desc in needed:
        row = parts[key]
        pack_qty = _pack_qty(row, key)
        lines.append(BomLine(
            key=key, item=row["item"], description=desc, quantity=qty, unit=row["unit"],
            packs=math.ceil(qty / pack_qty - 1e-9), pack_qty=pack_qty, pack_price=_price(row, key),
            supplier=row["supplier"], part_number=row["part_number"], notes=row["notes"]))
    return lines


def totals(lines: list[BomLine]) -> tuple[float, list[BomLine]]:
    """(sum of the priced lines, the lines with no price yet)."""
    return (round(sum(l.cost for l in lines if l.cost is not None), 2),
            [l for l in lines if l.cost is None])


def _qty_text(q: float) -> str:
    return f"{q:g}"


def write_csv(lines: list[BomLine], path: Path) -> None:
    with open(path, "w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh)
        w.writerow(["key", "item", "description", "quantity", "unit", "packs", "pack_qty",
                    "pack_price_usd", "cost_usd", "supplier", "part_number", "notes"])
        for l in lines:
            w.writerow([l.key, l.item, l.description, _qty_text(l.quantity), l.unit, l.packs, l.pack_qty,
                        "" if l.pack_price is None else f"{l.pack_price:.2f}",
                        "" if l.cost is None else f"{l.cost:.2f}", l.supplier, l.part_number, l.notes])


def write_markdown(lines: list[BomLine], path: Path, title: str) -> None:
    total, unpriced = totals(lines)
    out = [f"# BOM: {title}", "",
           "| Item | For this pack | Qty | Buy | Cost | Supplier / part |",
           "|---|---|---|---|---|---|"]
    for l in lines:
        buy = f"{l.packs} x {l.pack_qty}" if l.pack_qty > 1 else ""
        cost = "-" if l.cost is None else f"${l.cost:,.2f}"
        supplier = " ".join(s for s in (l.supplier, l.part_number) if s)
        out.append(f"| {l.item} | {l.description} | {_qty_text(l.quantity)} {l.unit} | {buy} | {cost} | {supplier} |")
    out += ["", f"**Priced total: ${total:,.2f}** ({len(lines) - len(unpriced)} of {len(lines)} lines priced)."]
    if unpriced:
        out += ["", "No price yet (fill in `data/parts.csv`): " + ", ".join(l.key for l in unpriced) + "."]
    path.write_text("\n".join(out) + "\n", encoding="utf-8")


def generate(config_path: str | Path, out_dir: str | Path, parts_path: str | Path = DEFAULT_PARTS) -> list[BomLine]:
    cfg = load_config(config_path)
    lines = build_bom(cfg, load_parts(parts_path))
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    write_csv(lines, out / "bom.csv")
    p = cfg["pack"]
    write_markdown(lines, out / "bom.md", f"{cfg.get('name', 'pack')} ({p['series']}S{p['parallel']}P)")
    return lines


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("config", type=Path, help="pack config JSON (e.g. config/default_20s4p.json)")
    ap.add_argument("-o", "--out", type=Path, default=Path("output/bom"), help="output directory")
    ap.add_argument("--parts", type=Path, default=DEFAULT_PARTS, help="parts/pricing CSV")
    args = ap.parse_args(argv)
    try:
        lines = generate(args.config, args.out, args.parts)
    except (ConfigError, ValueError, OSError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    for l in lines:
        cost = "no price" if l.cost is None else f"${l.cost:,.2f}"
        print(f"{l.key:16s} {_qty_text(l.quantity):>8s} {l.unit:5s} {cost:>10s}  {l.description}")
    total, unpriced = totals(lines)
    print(f"priced total ${total:,.2f}; {len(unpriced)} line(s) without a price")
    print(f"wrote bom.csv and bom.md to {args.out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
