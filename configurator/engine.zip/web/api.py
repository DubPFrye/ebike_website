"""Configurator API: turn the web form's choices into a config and run the engine on it.

Plain functions (no HTTP) so they can be tested directly; server.py maps routes onto them.

    options()          -> form choices, limits and defaults
    pack(choices)      -> validation errors, warnings, specs, dimensions, part drawings, BOM
    package(choices)   -> (zip file name, zip bytes): DXFs, BOM, config, Fusion script, hardware
"""
from __future__ import annotations

import copy
import io
import json
import re
import sys
import tempfile
import zipfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
for extra in (ROOT / "src", ROOT / "dxf", ROOT / "bom"):
    if str(extra) not in sys.path:
        sys.path.insert(0, str(extra))

from generate_bom import build_bom, load_parts, totals, write_csv, write_markdown  # noqa: E402
from generate_dxf import generate as generate_dxf  # noqa: E402
from pack.cells import apply_cell, load_cells, pack_specs  # noqa: E402
from pack.config import ConfigError, has_base_plate, validate_config  # noqa: E402
from pack.fusion_script import render_fusion_script  # noqa: E402
from pack.geometry import build_parts, check_design, derive_dimensions, derive_layout  # noqa: E402
from pack.svg import part_svg  # noqa: E402

DEFAULT_CONFIG = ROOT / "config" / "default_20s4p.json"
HARDWARE_DIR = ROOT / "fusion" / "hardware"

PITCHES = (23.4, 21.5)
LIMITS = {"series": (2, 30), "parallel": (1, 12), "base_extension_mm": (0, 200)}


class ChoiceError(ValueError):
    """The request itself is malformed (as opposed to a valid request for a pack we can't build)."""


def _default_config() -> dict[str, Any]:
    with open(DEFAULT_CONFIG, encoding="utf-8") as fh:
        return json.load(fh)


def options() -> dict[str, Any]:
    cfg = _default_config()
    cells = load_cells()
    return {
        "cells": [{"key": c.key, "name": c.name, "format": c.format, "diameter_mm": c.diameter_mm}
                  for c in cells.values()],
        "pitches": list(PITCHES),
        "limits": {k: list(v) for k, v in LIMITS.items()},
        "defaults": {
            "series": cfg["pack"]["series"], "parallel": cfg["pack"]["parallel"],
            "cell": next(iter(cells)), "pitch": cfg["pack"]["cell_pitch_mm"],
            "base_front_mm": cfg["enclosure"]["base_front_extension_mm"],
            "base_rear_mm": cfg["enclosure"]["base_rear_extension_mm"],
            "base_plate": has_base_plate(cfg),
        },
    }


def _int(choices: dict, key: str, lo: int, hi: int, default: int) -> int:
    value = choices.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)) or value != int(value):
        raise ChoiceError(f"{key} must be a whole number")
    if not lo <= value <= hi:
        raise ChoiceError(f"{key} must be between {lo} and {hi}")
    return int(value)


def _num(choices: dict, key: str, lo: float, hi: float, default: float) -> float:
    value = choices.get(key, default)
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ChoiceError(f"{key} must be a number")
    if not lo <= value <= hi:
        raise ChoiceError(f"{key} must be between {lo:g} and {hi:g}")
    return float(value)


def _bool(choices: dict, key: str, default: bool) -> bool:
    value = choices.get(key, default)
    if not isinstance(value, bool):
        raise ChoiceError(f"{key} must be true or false")
    return value


def make_config(choices: dict[str, Any]) -> tuple[dict[str, Any], Any]:
    """The default config with the customer's choices applied (not yet validated)."""
    if not isinstance(choices, dict):
        raise ChoiceError("expected a JSON object")
    cfg = _default_config()
    cells = load_cells()
    s = _int(choices, "series", *LIMITS["series"], cfg["pack"]["series"])
    p = _int(choices, "parallel", *LIMITS["parallel"], cfg["pack"]["parallel"])
    cell_key = choices.get("cell", next(iter(cells)))
    if cell_key not in cells:
        raise ChoiceError(f"unknown cell {cell_key!r}")
    pitch = _num(choices, "pitch", 0, 100, cfg["pack"]["cell_pitch_mm"])
    if pitch not in PITCHES:
        raise ChoiceError(f"pitch must be one of {', '.join(f'{x:g}' for x in PITCHES)}")
    lo, hi = LIMITS["base_extension_mm"]
    front = _num(choices, "base_front_mm", lo, hi, cfg["enclosure"]["base_front_extension_mm"])
    rear = _num(choices, "base_rear_mm", lo, hi, cfg["enclosure"]["base_rear_extension_mm"])
    base_plate = _bool(choices, "base_plate", has_base_plate(cfg))

    cell = cells[cell_key]
    apply_cell(cfg, cell)
    cfg["name"] = f"{s}S{p}P_{cell.key}" + ("" if base_plate else "_nobase")
    cfg["pack"].update(series=s, columns=s, parallel=p, rows=p, cell_pitch_mm=pitch)
    cfg["enclosure"].update(base_plate=base_plate, base_front_extension_mm=front, base_rear_extension_mm=rear)
    return cfg, cell


def pack(choices: dict[str, Any]) -> dict[str, Any]:
    """Everything the configurator page shows. Never raises for an unbuildable pack: it returns
    ok=False with the reasons, so the page can explain them."""
    cfg, cell = make_config(choices)
    s, p = cfg["pack"]["series"], cfg["pack"]["parallel"]
    result: dict[str, Any] = {"ok": False, "name": f"{s}S{p}P", "errors": [], "warnings": [],
                              "specs": pack_specs(cell, s, p)}
    try:
        validate_config(cfg)
    except ConfigError as exc:
        result["errors"] = [line.strip()[2:] for line in str(exc).splitlines()[1:]] or [str(exc)]
        return result

    d = derive_dimensions(cfg)
    lay = derive_layout(d)
    parts = build_parts(cfg)
    result["warnings"] = check_design(cfg, parts)
    result["dims"] = {
        "plate_mm": [round(d.plate_width, 1), round(d.plate_height, 1)],
        # with a base plate the hooks hang below the side plates by hook_drop
        "pack_mm": [round(d.plate_width, 1), round(d.plate_height + (d.hook_drop if d.base_plate else 0), 1),
                    round(d.cavity_depth + 2 * d.polycarbonate_thickness, 1)],
        "base_plate_mm": ([round(d.base_plate_x_length, 1), round(d.base_plate_z_width, 1)]
                          if d.base_plate else None),
        "cavity_mm": [round(d.cavity_width, 1), round(d.cavity_height, 1), round(d.cavity_depth, 1)],
        "bolts": len(lay.bolt_points), "tabs_per_long_wall": len(lay.tab_xs),
        "tabs_per_short_wall": len(lay.short_tab_ys), "hooks": len(lay.hook_xs),
    }
    result["parts"] = [{
        "part_number": pt.part_number, "description": pt.description, "material": pt.material,
        "thickness_mm": pt.thickness_mm, "quantity": pt.quantity, "process": pt.process,
        "size_mm": [round(pt.size[0], 1), round(pt.size[1], 1)], "svg": part_svg(pt),
    } for pt in parts]
    lines = build_bom(cfg, load_parts())
    total, unpriced = totals(lines)
    result["bom"] = {
        "lines": [{"key": l.key, "item": l.item, "description": l.description, "quantity": l.quantity,
                   "unit": l.unit, "cost": l.cost, "supplier": l.supplier, "part_number": l.part_number}
                  for l in lines],
        "priced_total": total, "unpriced": [l.key for l in unpriced],
    }
    result["ok"] = True
    return result


PACKAGE_README = """Build package for {name}

config.json            the full configuration this package was made from
dxf/                   one SendCutSend-ready DXF per part, manifest.json, PNG previews
bom/                   bom.csv and bom.md (prices from data/parts.csv; blanks are unpriced)
fusion/{script}/      Fusion script folder: {script}.py (this pack's parameters),
                       {script}.manifest, hardware/ (McMaster screw STEP)

Fusion:
  1. Unzip this package first (Fusion cannot run a script from inside a zip).
  2. File > New Design.
  3. Utilities > Scripts and Add-Ins (Shift+S) > '+' next to Scripts > pick the FOLDER
     fusion/{script} (or its .py file, depending on your Fusion version) > Run.
The script sets the design's parameters to this pack. Its result dialog shows which script file
ran and which pack it built.
"""

FUSION_MANIFEST = {
    "autodeskProduct": "Fusion",
    "type": "script",
    "author": "FryePower",
    "description": {"": ""},
    "supportedOS": "windows|mac",
    "editEnabled": True,
}


def script_name(config_name: str) -> str:
    """Fusion script (and folder) name for a pack, e.g. ebike_2S1P_21700_50e."""
    return "ebike_" + re.sub(r"[^A-Za-z0-9_]", "_", config_name)


def package(choices: dict[str, Any]) -> tuple[str, bytes]:
    """Zip with everything needed to build the pack. Raises ConfigError for an unbuildable pack."""
    cfg, _cell = make_config(choices)
    validate_config(cfg)
    name = cfg["name"]
    buf = io.BytesIO()
    with tempfile.TemporaryDirectory() as tmp, zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as zf:
        tmp_path = Path(tmp)
        cfg_path = tmp_path / "config.json"
        cfg_path.write_text(json.dumps(cfg, indent=2), encoding="utf-8")
        zf.write(cfg_path, "config.json")

        dxf_dir = tmp_path / "dxf"
        generate_dxf(cfg_path, dxf_dir, previews=True)
        for f in sorted(dxf_dir.iterdir()):
            zf.write(f, f"dxf/{f.name}")

        bom_dir = tmp_path / "bom"
        bom_dir.mkdir()
        lines = build_bom(cfg, load_parts())
        write_csv(lines, bom_dir / "bom.csv")
        write_markdown(lines, bom_dir / "bom.md", name)
        for f in sorted(bom_dir.iterdir()):
            zf.write(f, f"bom/{f.name}")

        # Fusion wants a script folder named like the script, holding <name>.py and <name>.manifest
        script = script_name(name)
        folder = f"fusion/{script}"
        zf.writestr(f"{folder}/{script}.py", render_fusion_script(cfg))
        manifest = dict(FUSION_MANIFEST, description={"": f"FryePower battery enclosure, {name}"})
        zf.writestr(f"{folder}/{script}.manifest", json.dumps(manifest, indent=2))
        if HARDWARE_DIR.is_dir():
            for f in sorted(HARDWARE_DIR.iterdir()):
                if f.is_file():
                    zf.write(f, f"{folder}/hardware/{f.name}")
        zf.writestr("README.txt", PACKAGE_README.format(name=name, script=script))
    return f"{name}_build_package.zip", buf.getvalue()
