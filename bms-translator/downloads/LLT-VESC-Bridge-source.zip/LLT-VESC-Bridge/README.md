# LLT → VESC BMS Bridge

An STM32F103 "Blue Pill" that reads cell data from an inexpensive LLT (JBD-style)
BMS over UART and re-broadcasts it on CAN in the format a VESC expects from a
VESC-compatible BMS.

The point: let the VESC enforce **per-cell** voltage cutoffs instead of relying on
whole-pack voltage. The cheap 20A BMS then only handles charging and balancing,
and its FET output switch can be left unconnected.

> **Alpha / safety warning.** With the BMS FET switch bypassed, this bridge and
> the VESC are your only over-discharge protection. Bench-test thoroughly before
> riding. Use at your own risk.

## Hardware

- STM32F103C8 "Blue Pill"
- SN65HVD230 CAN transceiver board (unterminated, mid-bus stub)
- LLT / JBD BMS with UART port
- One or more VESCs on the CAN bus (terminated at the two ends)

## Repository layout

| Path        | Contents                                              |
|-------------|-------------------------------------------------------|
| `firmware/` | STM32CubeIDE project (C, STM32 HAL)                   |
| `hardware/` | Wiring diagrams (SVG illustration, WireViz sources)   |
| `docs/`     | The build guide published at fryepower.com/bms-translator/ |

## License

- Firmware and other code: [GPL-3.0](LICENSE)
- Guide, diagrams and photos (`docs/`, `hardware/`): [CC BY-SA 4.0](docs/LICENSE)
