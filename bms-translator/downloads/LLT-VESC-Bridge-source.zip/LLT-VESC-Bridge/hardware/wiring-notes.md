# Wiring notes (prototype)

Source for the wiring diagrams. Photo: `docs/images/breadboard-prototype.jpg`.

## Confirmed

| From | To | Notes |
|---|---|---|
| SN65HVD230 CTX | Blue Pill PB9 (CAN_TX) | confirmed by builder |
| SN65HVD230 CRX | Blue Pill PB8 (CAN_RX) | confirmed by builder |
| VESC CAN connector 5V | Blue Pill 5V | VESC powers the bridge |
| VESC CAN connector GND | Blue Pill G, SN65HVD230 GND, ST-Link GND (via Blue Pill) | common ground |
| Blue Pill 3.3 | SN65HVD230 3V3 | Blue Pill regulator feeds transceiver |
| VESC CAN connector CANH / CANL | SN65HVD230 CANH / CANL | wire colors TBD |
| ST-Link SWDIO / SWCLK / GND | Blue Pill SWD header | ST-Link 3.3V wire left **disconnected** so the PC's USB supply doesn't back-feed the Blue Pill rail |

Power: 10S Li-ion pack → VESC → 5V on the CAN connector → bridge. ST-Link is powered from PC USB only.

## Firmware pin map (from VESC2LLT.ioc)

| Function | Pin | Setting |
|---|---|---|
| CAN RX / TX | PB8 / PB9 | remapped, 500 kbps, extended IDs |
| BMS UART TX / RX | PA9 / PA10 (USART1) | 9600 8N1 |
| Status LED | PC13 | |

## Flipsky Mini FSESC6.7 PRO connectors (from Flipsky wiring diagram)

| # | Connector | Pins in order |
|---|---|---|
| 1 | CAN (4-pin) | − (GND), CAL (CANL), CAH (CANH), 5V |
| 2 | SENSE (6-pin) | −, H3, H2, H1, TMP, 5V |
| 3 | COMM (8-pin) | ADC3, ADC2, TX/SCL, RX/SDA, ADC1, GND, 3.3V, 5V |
| 4 | SWD (5-pin) | 3.3V, SWCLK, GND, SWDIO, NRST |
| 5 | USB | |

Receiver lead (3-pin servo plug, supplied): GND (black), 5V (red/orange), SIN (white) — PPM throttle input.
In the prototype photo the loose black/orange/white plug is this receiver lead; it is not the BMS.

Bridge → VESC CAN connector: GND → −, SN65 CANL → CAL, SN65 CANH → CAH, Blue Pill 5V → 5V.

## Still to confirm

- Which harness wire colors land on CAL vs CAH (check at the connector against the pin order above).
- LLT BMS UART connector pinout and how it lands on PA9 / PA10 / GND.
