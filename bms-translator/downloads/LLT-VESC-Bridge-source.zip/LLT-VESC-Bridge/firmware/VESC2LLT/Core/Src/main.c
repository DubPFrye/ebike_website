/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : LLT BMS to VESC CAN Bridge
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* LLT BMS data structure - holds all values parsed from UART responses */
typedef struct {
    float    pack_voltage;        /* Total pack voltage in volts */
    float    pack_current;        /* Pack current in amps (positive = discharge) */
    float    remaining_capacity;  /* Remaining capacity in Ah */
    float    nominal_capacity;    /* Nominal capacity in Ah */
    uint8_t  soc_percent;         /* State of charge 0-100% */
    uint8_t  num_cells;           /* Number of cells in series */
    uint8_t  num_temps;           /* Number of temperature sensors */
    uint16_t cell_mv[24];         /* Individual cell voltages in mV (up to 24 cells) */
    int16_t  temps_dc[8];         /* Temperatures in tenths of degrees C (up to 8 sensors) */
    uint16_t protection_status;   /* Protection status bitmask from BMS */
    uint8_t  fet_status;          /* FET status byte (charge/discharge enable bits) */
    uint8_t  data_valid;          /* 1 if data has been successfully received */
} LLT_BMS_Data_t;

/* VESC BMS CAN message structure - holds all CAN frames to be transmitted */
typedef struct {
    /* CAN_PACKET_BMS_V_TOT (0x370) - total voltage and current */
    float    v_tot;               /* Total pack voltage */
    float    v_charge;            /* Charge voltage (same as pack voltage here) */
    float    current;             /* Pack current */
    float    current_charging;    /* Charging current (0 if discharging) */

    /* CAN_PACKET_BMS_SOC_SOH_TEMP_STAT (0x371) - SoC, SoH, temp, status */
    float    soc;                 /* State of charge 0.0-1.0 */
    float    soh;                 /* State of health 0.0-1.0 (assume 1.0) */
    float    temp_cell_max;       /* Max cell temperature in Celsius */
    float    temp_cell_min;       /* Min cell temperature in Celsius */

    /* CAN_PACKET_BMS_TEMPS (0x372) - temperature array */
    float    temps[8];            /* Temperatures in Celsius */
    uint8_t  num_temps;

    /* CAN_PACKET_BMS_AH_WH (0x373) - capacity */
    float    ah_cnt;              /* Remaining capacity in Ah */
    float    wh_cnt;              /* Remaining energy in Wh (estimated) */

    /* CAN_PACKET_BMS_V_CELL (0x374) - cell voltages */
    float    v_cell[24];          /* Cell voltages in volts */
    uint8_t  num_cells;

    /* CAN_PACKET_BMS_BAL (0x375) - balancing status */
    uint8_t  is_balancing;        /* 1 if any balancing active */

    /* Status flags derived from protection_status */
    uint8_t  is_charging;         /* 1 if charge FET on */
    uint8_t  chg_ok;              /* Charge OK flag */
    uint8_t  is_charge_allowed;   /* Charge allowed flag */
} VESC_BMS_Data_t;

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* Uncomment to enable CAN test mode — sends synthetic BMS data instead of real LLT data.
   Comment out this line to revert to real BMS operation. */
#define CAN_TEST_MODE

/* LLT BMS UART protocol defines */
#define LLT_START_BYTE          0xDD
#define LLT_END_BYTE            0x77
#define LLT_READ_CMD            0xA5
#define LLT_CMD_BASIC_INFO      0x03    /* Basic info: voltage, current, SoC, status */
#define LLT_CMD_CELL_VOLTAGES   0x04    /* Individual cell voltages */

#define LLT_BASIC_INFO_LEN      34      /* Expected basic info response length (typical) */
#define LLT_MAX_RESPONSE_LEN    128     /* Buffer size for UART receive */
#define LLT_UART_TIMEOUT_MS     500     /* UART receive timeout in ms */

/* VESC BMS CAN packet IDs - from VESC firmware datatypes.h */
#define VESC_CAN_BMS_V_TOT              0x370
#define VESC_CAN_BMS_I                  0x371
#define VESC_CAN_BMS_SOC_SOH_TEMP_STAT  0x372
#define VESC_CAN_BMS_TEMPS              0x373
#define VESC_CAN_BMS_AH_WH              0x374
#define VESC_CAN_BMS_V_CELL             0x375
#define VESC_CAN_BMS_BAL                0x376

/* VESC controller CAN IDs - set to match your VESC tool config */
#define VESC_CAN_ID_REAR        0x01
#define VESC_CAN_ID_FRONT       0x02

/* LLT protection status bitmask bits */
#define LLT_PROT_CELL_OV        (1 << 0)   /* Cell overvoltage */
#define LLT_PROT_CELL_UV        (1 << 1)   /* Cell undervoltage */
#define LLT_PROT_PACK_OV        (1 << 2)   /* Pack overvoltage */
#define LLT_PROT_PACK_UV        (1 << 3)   /* Pack undervoltage */
#define LLT_PROT_CHG_OT         (1 << 4)   /* Charge overtemp */
#define LLT_PROT_CHG_UT         (1 << 5)   /* Charge undertemp */
#define LLT_PROT_DIS_OT         (1 << 6)   /* Discharge overtemp */
#define LLT_PROT_DIS_UT         (1 << 7)   /* Discharge undertemp */
#define LLT_PROT_CHG_OC         (1 << 8)   /* Charge overcurrent */
#define LLT_PROT_DIS_OC         (1 << 9)   /* Discharge overcurrent */
#define LLT_PROT_SHORT          (1 << 10)  /* Short circuit */

/* LLT FET status bits */
#define LLT_FET_CHG             (1 << 0)   /* Charge FET on */
#define LLT_FET_DIS             (1 << 1)   /* Discharge FET on */

/* Main loop period */
#define LOOP_PERIOD_MS          500

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */
/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
CAN_HandleTypeDef hcan;
UART_HandleTypeDef huart1;

/* USER CODE BEGIN PV */

static LLT_BMS_Data_t  bms_data;
static VESC_BMS_Data_t vesc_data;
static uint8_t uart_rx_buf[LLT_MAX_RESPONSE_LEN];
static uint32_t can_tx_ok_count  = 0;   /* increments on successful CAN send */
static uint32_t can_tx_err_count = 0;   /* increments on failed CAN send */

/* BMS and VESC data structure instances */
static LLT_BMS_Data_t  bms_data;
static VESC_BMS_Data_t vesc_data;

/* UART receive buffer */
static uint8_t uart_rx_buf[LLT_MAX_RESPONSE_LEN];

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MX_GPIO_Init(void);
static void MX_CAN_Init(void);
static void MX_USART1_UART_Init(void);

/* USER CODE BEGIN PFP */

static HAL_StatusTypeDef LLT_GetData(LLT_BMS_Data_t *bms);
static void              LLT_Translate(const LLT_BMS_Data_t *bms, VESC_BMS_Data_t *vesc);
static HAL_StatusTypeDef VESC_SendCANMessages(const VESC_BMS_Data_t *vesc);
static HAL_StatusTypeDef CAN_SendFrame(uint32_t id, uint8_t *data, uint8_t len);
static uint16_t          LLT_Checksum(const uint8_t *data, uint8_t len);
static void              FloatToBytes_BE(float val, uint8_t *buf);
static float             BytesToFloat_BE(const uint8_t *buf);
static uint16_t          FloatToFloat16(float val, float scale);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/**
  * @brief  Pack a float into 4 bytes big-endian (VESC CAN convention)
  */
static void FloatToBytes_BE(float val, uint8_t *buf)
{
    uint32_t u;
    memcpy(&u, &val, 4);
    buf[0] = (u >> 24) & 0xFF;
    buf[1] = (u >> 16) & 0xFF;
    buf[2] = (u >>  8) & 0xFF;
    buf[3] = (u      ) & 0xFF;
}

/**
  * @brief  Unpack a float from 4 bytes big-endian
  */
static float BytesToFloat_BE(const uint8_t *buf)
{
    uint32_t u = ((uint32_t)buf[0] << 24)
               | ((uint32_t)buf[1] << 16)
               | ((uint32_t)buf[2] <<  8)
               | ((uint32_t)buf[3]);
    float val;
    memcpy(&val, &u, 4);
    return val;
}

/**
  * @brief  Compute LLT BMS checksum (two's complement sum of data bytes)
  */
static uint16_t LLT_Checksum(const uint8_t *data, uint8_t len)
{
    uint16_t sum = 0;
    for (uint8_t i = 0; i < len; i++) {
        sum += data[i];
    }
    return (uint16_t)(~sum + 1);
}

/* USER CODE BEGIN 0 - Test Mode */
#ifdef CAN_TEST_MODE
/**
  * @brief  Generate synthetic BMS data for CAN bus testing.
  *         Values slowly change each call to produce visible movement
  *         in the VESC Tool BMS screen.
  */
static void LLT_GetTestData(LLT_BMS_Data_t *bms)
{
    static uint32_t tick = 0;
    tick++;

    /* Sweep pack voltage 48.0V - 54.6V over ~20 steps (10 second full cycle) */
    float sweep = (float)(tick % 20) / 20.0f;                  /* 0.0 -> 1.0 */
    if ((tick % 40) >= 20) sweep = 1.0f - sweep;               /* triangle wave */

    bms->pack_voltage       = 48.0f + sweep * 6.6f;            /* 48.0 - 54.6V */
    bms->nominal_capacity   = 17.5f;                           /* 17.5Ah pack */
    bms->remaining_capacity = 2.0f + sweep * 15.5f;            /* 2.0 - 17.5Ah */
    bms->soc_percent        = (uint8_t)(sweep * 100.0f);

    /* Alternate between mild discharge and mild charge */
    bms->pack_current = ((tick % 10) < 5) ? 3.5f : -2.0f;     /* +3.5A dis, -2.0A chg */

    /* 13 cells, slight spread between them */
    bms->num_cells = 13;
    float cell_base_mv = (bms->pack_voltage / 13.0f) * 1000.0f;
    for (uint8_t i = 0; i < 13; i++) {
        /* Spread cells +/- a few mV so they're not all identical */
        int16_t offset = (int16_t)((i % 3) - 1) * 5;          /* -5, 0, +5 mV pattern */
        bms->cell_mv[i] = (uint16_t)(cell_base_mv + offset);
    }

    /* 2 temperature sensors, slowly drifting 25 - 35 deg C */
    bms->num_temps = 2;
    int16_t temp_base = (int16_t)(250 + sweep * 100);          /* 25.0 - 35.0 deg C in tenths */
    bms->temps_dc[0] = temp_base;
    bms->temps_dc[1] = temp_base + 5;                         /* sensor 2 slightly warmer */

    /* No protection faults, both FETs on */
    bms->protection_status = 0x0000;
    bms->fet_status        = LLT_FET_CHG | LLT_FET_DIS;

    bms->data_valid = 1;
}
#endif /* CAN_TEST_MODE */
/* END USER CODE - Test Mode */

/**
  * @brief  Convert float to VESC-style float16 big-endian bytes
  *         VESC uses integer scaling: stored_val = (int16_t)(float_val * scale)
  *         e.g. scale=1000 for mV precision on a voltage in volts
  */
static uint16_t FloatToFloat16(float val, float scale)
{
    return (uint16_t)((int16_t)(val * scale));
}

/**
  * @brief  Send a CAN transmit frame with extended ID
  */
static HAL_StatusTypeDef CAN_SendFrame(uint32_t id, uint8_t *data, uint8_t len)
{
    CAN_TxHeaderTypeDef tx_header;
    uint32_t tx_mailbox;

    tx_header.ExtId              = id;
    tx_header.IDE                = CAN_ID_EXT;
    tx_header.RTR                = CAN_RTR_DATA;
    tx_header.DLC                = len;
    tx_header.TransmitGlobalTime = DISABLE;

    /* Wait for a free mailbox (up to 10ms) */
    uint32_t start = HAL_GetTick();
    while (HAL_CAN_GetTxMailboxesFreeLevel(&hcan) == 0) {
        if ((HAL_GetTick() - start) > 10) {
            return HAL_TIMEOUT;
        }
    }

    return HAL_CAN_AddTxMessage(&hcan, &tx_header, data, &tx_mailbox);
}

/**
  * @brief  Request and receive data from LLT BMS over UART
  *         Sends a read request for basic info (0x03) then cell voltages (0x04)
  *         and parses the responses into the bms structure.
  */
static HAL_StatusTypeDef LLT_GetData(LLT_BMS_Data_t *bms)
{
    /* LLT read request frame: 0xDD 0xA5 <cmd> 0x00 <checksum_hi> <checksum_lo> 0x77 */
    uint8_t req[7];
    HAL_StatusTypeDef status;

    /* ---- Request basic info (cmd 0x03) ---- */
    req[0] = LLT_START_BYTE;
    req[1] = LLT_READ_CMD;
    req[2] = LLT_CMD_BASIC_INFO;
    req[3] = 0x00;                  /* data length = 0 for a read request */
    uint16_t chk = LLT_Checksum(&req[2], 2);
    req[4] = (chk >> 8) & 0xFF;
    req[5] = chk & 0xFF;
    req[6] = LLT_END_BYTE;

    memset(uart_rx_buf, 0, sizeof(uart_rx_buf));

    status = HAL_UART_Transmit(&huart1, req, 7, LLT_UART_TIMEOUT_MS);
    if (status != HAL_OK) return status;

    status = HAL_UART_Receive(&huart1, uart_rx_buf, LLT_MAX_RESPONSE_LEN, LLT_UART_TIMEOUT_MS);
    /* HAL_TIMEOUT is acceptable here — it fires when the buffer isn't completely
       filled, which is normal since the response is shorter than the buffer.
       Check we got at least the minimum valid response instead. */
    if (status != HAL_OK && status != HAL_TIMEOUT) return status;

    /* Validate response: start=0xDD, cmd=0x03, status=0x00 */
    if (uart_rx_buf[0] != 0xDD || uart_rx_buf[1] != 0x03 || uart_rx_buf[2] != 0x00) {
        return HAL_ERROR;
    }

    uint8_t data_len = uart_rx_buf[3];

    /* Parse basic info fields (all big-endian from BMS) */
    /* Byte offsets are relative to start of data payload (index 4) */
    bms->pack_voltage       = (float)((uart_rx_buf[4]  << 8) | uart_rx_buf[5])  / 100.0f;
    int16_t raw_current     = (int16_t)((uart_rx_buf[6] << 8) | uart_rx_buf[7]);
    bms->pack_current       = (float)raw_current / 100.0f;
    bms->remaining_capacity = (float)((uart_rx_buf[8]  << 8) | uart_rx_buf[9])  / 100.0f;
    bms->nominal_capacity   = (float)((uart_rx_buf[10] << 8) | uart_rx_buf[11]) / 100.0f;
    /* Bytes 12-15: cycle count, production date - skip */
    bms->protection_status  = (uint16_t)((uart_rx_buf[20] << 8) | uart_rx_buf[21]);
    bms->fet_status         = uart_rx_buf[22];
    bms->num_cells          = uart_rx_buf[23];
    bms->num_temps          = uart_rx_buf[24];

    /* Parse temperatures (each is (raw - 2731) / 10.0 to get degrees C) */
    for (uint8_t i = 0; i < bms->num_temps && i < 8; i++) {
        uint16_t raw_temp = (uint16_t)((uart_rx_buf[25 + i*2] << 8) | uart_rx_buf[26 + i*2]);
        bms->temps_dc[i] = (int16_t)(raw_temp - 2731);  /* stored as tenths of deg C */
    }

    /* SoC is not directly in basic info packet on all LLT versions;
       compute from remaining/nominal capacity */
    if (bms->nominal_capacity > 0.0f) {
        bms->soc_percent = (uint8_t)((bms->remaining_capacity / bms->nominal_capacity) * 100.0f);
    } else {
        bms->soc_percent = 0;
    }

    /* ---- Request cell voltages (cmd 0x04) ---- */
    req[2] = LLT_CMD_CELL_VOLTAGES;
    chk = LLT_Checksum(&req[2], 2);
    req[4] = (chk >> 8) & 0xFF;
    req[5] = chk & 0xFF;

    memset(uart_rx_buf, 0, sizeof(uart_rx_buf));

    status = HAL_UART_Transmit(&huart1, req, 7, LLT_UART_TIMEOUT_MS);
    if (status != HAL_OK) return status;

    status = HAL_UART_Receive(&huart1, uart_rx_buf, LLT_MAX_RESPONSE_LEN, LLT_UART_TIMEOUT_MS);
    if (status != HAL_OK && status != HAL_TIMEOUT) return status;

    if (uart_rx_buf[0] != 0xDD || uart_rx_buf[1] != 0x04 || uart_rx_buf[2] != 0x00) {
        return HAL_ERROR;
    }

    /* Parse cell voltages — 2 bytes each, in mV */
    uint8_t num_cells = uart_rx_buf[3] / 2;
    if (num_cells > 24) num_cells = 24;
    bms->num_cells = num_cells;
    for (uint8_t i = 0; i < num_cells; i++) {
        bms->cell_mv[i] = (uint16_t)((uart_rx_buf[4 + i*2] << 8) | uart_rx_buf[5 + i*2]);
    }

    bms->data_valid = 1;
    return HAL_OK;
}

/**
  * @brief  Translate LLT BMS data structure into VESC BMS CAN data structure
  */
static void LLT_Translate(const LLT_BMS_Data_t *bms, VESC_BMS_Data_t *vesc)
{
    /* Voltage and current */
    vesc->v_tot    = bms->pack_voltage;
    vesc->v_charge = bms->pack_voltage;
    vesc->current  = bms->pack_current;
    vesc->current_charging = (bms->pack_current < 0.0f) ? -bms->pack_current : 0.0f;

    /* SoC and SoH */
    vesc->soc = (float)bms->soc_percent / 100.0f;
    vesc->soh = 1.0f;  /* LLT doesn't report SoH; assume healthy */

    /* Temperatures */
    vesc->num_temps = bms->num_temps;
    float temp_max = -100.0f, temp_min = 200.0f;
    for (uint8_t i = 0; i < bms->num_temps && i < 8; i++) {
        float t = (float)bms->temps_dc[i] / 10.0f;
        vesc->temps[i] = t;
        if (t > temp_max) temp_max = t;
        if (t < temp_min) temp_min = t;
    }
    vesc->temp_cell_max = (bms->num_temps > 0) ? temp_max : 25.0f;
    vesc->temp_cell_min = (bms->num_temps > 0) ? temp_min : 25.0f;

    /* Capacity */
    vesc->ah_cnt = bms->remaining_capacity;
    vesc->wh_cnt = bms->remaining_capacity * bms->pack_voltage;  /* Wh estimate */

    /* Cell voltages */
    vesc->num_cells = bms->num_cells;
    for (uint8_t i = 0; i < bms->num_cells && i < 24; i++) {
        vesc->v_cell[i] = (float)bms->cell_mv[i] / 1000.0f;
    }

    /* Balancing — LLT doesn't report per-cell balancing; set to 0 */
    vesc->is_balancing = 0;

    /* Status flags */
    vesc->is_charging       = (bms->fet_status & LLT_FET_CHG) ? 1 : 0;
    vesc->chg_ok            = (bms->protection_status == 0) ? 1 : 0;
    vesc->is_charge_allowed = ((bms->protection_status &
                                (LLT_PROT_CELL_OV | LLT_PROT_PACK_OV |
                                 LLT_PROT_CHG_OT  | LLT_PROT_CHG_UT  |
                                 LLT_PROT_CHG_OC)) == 0) ? 1 : 0;
}

/**
  * @brief  Transmit all VESC BMS CAN frames with correct byte layouts
  *         sourced from VESC firmware bms.c / comm_can.c
  */
static HAL_StatusTypeDef VESC_SendCANMessages(const VESC_BMS_Data_t *vesc)
{
    uint8_t buf[8];
    HAL_StatusTypeDef status;
    uint16_t f16;

    /* Single VESC for testing — add VESC_CAN_ID_FRONT and change 1 to 2 when second VESC is on bus */
    uint8_t vesc_ids[1] = {VESC_CAN_ID_REAR};

    for (uint8_t v = 0; v < 1; v++) {
        uint8_t vid = vesc_ids[v];

        /* ---- CAN_PACKET_BMS_V_TOT (0x370) ----
         * Bytes 0-3: v_tot  (float32 BE)
         * Bytes 4-7: v_charge (float32 BE) */
        FloatToBytes_BE(vesc->v_tot,    &buf[0]);
        FloatToBytes_BE(vesc->v_charge, &buf[4]);
        status = CAN_SendFrame((uint32_t)(VESC_CAN_BMS_V_TOT << 8) | vid, buf, 8);
        if (status != HAL_OK) return status;

        /* ---- CAN_PACKET_BMS_I (0x371) ----
         * Bytes 0-3: current      (float32 BE, positive = discharge)
         * Bytes 4-7: current_charging (float32 BE, positive = charge) */
        FloatToBytes_BE(vesc->current,          &buf[0]);
        FloatToBytes_BE(vesc->current_charging, &buf[4]);
        status = CAN_SendFrame((uint32_t)(VESC_CAN_BMS_I << 8) | vid, buf, 8);
        if (status != HAL_OK) return status;

        /* ---- CAN_PACKET_BMS_SOC_SOH_TEMP_STAT (0x372) ----
         * Bytes 0-1: v_cell_min (float16, scale 1000 = 1mV precision)
         * Bytes 2-3: v_cell_max (float16, scale 1000 = 1mV precision)
         * Byte  4:   soc        (uint8, 0-255 = 0.0-1.0)
         * Byte  5:   soh        (uint8, 0-255 = 0.0-1.0)
         * Byte  6:   temp_max   (int8,  degrees C)
         * Byte  7:   status     (bit0=is_charging, bit1=is_balancing, bit2=is_charge_allowed) */
        float v_min = 5.0f, v_max = 0.0f;
        for (uint8_t i = 0; i < vesc->num_cells; i++) {
            if (vesc->v_cell[i] < v_min) v_min = vesc->v_cell[i];
            if (vesc->v_cell[i] > v_max) v_max = vesc->v_cell[i];
        }
        f16 = FloatToFloat16(v_min, 1000.0f);
        buf[0] = (f16 >> 8) & 0xFF;
        buf[1] = f16 & 0xFF;
        f16 = FloatToFloat16(v_max, 1000.0f);
        buf[2] = (f16 >> 8) & 0xFF;
        buf[3] = f16 & 0xFF;
        buf[4] = (uint8_t)(vesc->soc * 255.0f);
        buf[5] = (uint8_t)(vesc->soh * 255.0f);
        buf[6] = (int8_t)vesc->temp_cell_max;
        buf[7] = (vesc->is_charging       ? 0x01 : 0x00)
               | (vesc->is_balancing      ? 0x02 : 0x00)
               | (vesc->is_charge_allowed ? 0x04 : 0x00);
        status = CAN_SendFrame((uint32_t)(VESC_CAN_BMS_SOC_SOH_TEMP_STAT << 8) | vid, buf, 8);
        if (status != HAL_OK) return status;

        /* ---- CAN_PACKET_BMS_TEMPS (0x373) ----
         * Each frame: 4x float16 temperatures (scale 1e2 = 0.01 deg C precision)
         * Multiple frames sent if num_temps > 4 */
        for (uint8_t i = 0; i < vesc->num_temps; i += 4) {
            uint8_t ind = 0;
            for (uint8_t j = i; j < i + 4; j++) {
                float t = (j < vesc->num_temps) ? vesc->temps[j] : 0.0f;
                f16 = FloatToFloat16(t, 100.0f);
                buf[ind++] = (f16 >> 8) & 0xFF;
                buf[ind++] = f16 & 0xFF;
            }
            status = CAN_SendFrame((uint32_t)((VESC_CAN_BMS_TEMPS + (i / 4)) << 8) | vid, buf, 8);
            if (status != HAL_OK) return status;
        }

        /* ---- CAN_PACKET_BMS_AH_WH (0x374) ----
         * Bytes 0-3: ah_cnt (float32 BE)
         * Bytes 4-7: wh_cnt (float32 BE) */
        FloatToBytes_BE(vesc->ah_cnt, &buf[0]);
        FloatToBytes_BE(vesc->wh_cnt, &buf[4]);
        status = CAN_SendFrame((uint32_t)(VESC_CAN_BMS_AH_WH << 8) | vid, buf, 8);
        if (status != HAL_OK) return status;

        /* ---- CAN_PACKET_BMS_V_CELL (0x375) ----
         * Byte  0:   cell offset (starting cell index for this frame)
         * Byte  1:   total num_cells
         * Bytes 2-3: v_cell[offset+0] (float16, scale 1000 = 1mV precision)
         * Bytes 4-5: v_cell[offset+1] (float16)
         * Bytes 6-7: v_cell[offset+2] (float16)
         * 3 cells per frame */
        for (uint8_t i = 0; i < vesc->num_cells; i += 3) {
            buf[0] = i;                     /* cell offset */
            buf[1] = vesc->num_cells;       /* total cells */
            for (uint8_t j = 0; j < 3; j++) {
                float cv = ((i + j) < vesc->num_cells) ? vesc->v_cell[i + j] : 0.0f;
                f16 = FloatToFloat16(cv, 1000.0f);
                buf[2 + j * 2] = (f16 >> 8) & 0xFF;
                buf[3 + j * 2] = f16 & 0xFF;
            }
            status = CAN_SendFrame((uint32_t)(VESC_CAN_BMS_V_CELL << 8) | vid, buf, 8);
            if (status != HAL_OK) return status;
        }

        /* ---- CAN_PACKET_BMS_BAL (0x376) ----
         * Bytes 0-3: balancing bitfield (one bit per cell, uint32 BE)
         * All zeros since LLT doesn't report per-cell balancing */
        memset(buf, 0, 8);
        status = CAN_SendFrame((uint32_t)(VESC_CAN_BMS_BAL << 8) | vid, buf, 4);
        if (status != HAL_OK) return status;
    }

    return HAL_OK;
}

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  HAL_Init();

  /* USER CODE BEGIN Init */
  /* USER CODE END Init */

  SystemClock_Config();

  /* USER CODE BEGIN SysInit */
  /* USER CODE END SysInit */

  MX_GPIO_Init();
  MX_CAN_Init();
  MX_USART1_UART_Init();

  /* USER CODE BEGIN 2 */

  /* Initialise data structures */
  memset(&bms_data,  0, sizeof(bms_data));
  memset(&vesc_data, 0, sizeof(vesc_data));

  /* Configure CAN filter — pass all extended frames into FIFO0 */
  CAN_FilterTypeDef can_filter;
  can_filter.FilterBank           = 0;
  can_filter.FilterMode           = CAN_FILTERMODE_IDMASK;
  can_filter.FilterScale          = CAN_FILTERSCALE_32BIT;
  can_filter.FilterIdHigh         = 0x0000;
  can_filter.FilterIdLow          = 0x0000;
  can_filter.FilterMaskIdHigh     = 0x0000;
  can_filter.FilterMaskIdLow      = 0x0000;
  can_filter.FilterFIFOAssignment = CAN_FILTER_FIFO0;
  can_filter.FilterActivation     = CAN_FILTER_ENABLE;
  can_filter.SlaveStartFilterBank = 14;
  HAL_CAN_ConfigFilter(&hcan, &can_filter);

  /* Start CAN peripheral */
  HAL_CAN_Start(&hcan);

  /* USER CODE END 2 */

  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

    /* Toggle heartbeat LED — on for 500ms, off for 500ms */
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);

    /* Step 1: Get data from LLT BMS (or generate test data) */
#ifdef CAN_TEST_MODE
    LLT_GetTestData(&bms_data);
    HAL_StatusTypeDef bms_status = HAL_OK;
#else
    HAL_StatusTypeDef bms_status = LLT_GetData(&bms_data);
#endif

    if (bms_status == HAL_OK && bms_data.data_valid) {
        /* Step 2: Translate BMS data to VESC format */
        LLT_Translate(&bms_data, &vesc_data);

        /* Step 3: Send VESC CAN messages */
        if (VESC_SendCANMessages(&vesc_data) == HAL_OK) {
            can_tx_ok_count++;
        } else {
            can_tx_err_count++;
        }
    }

    /* 500ms loop period */
    HAL_Delay(LOOP_PERIOD_MS);

    /* USER CODE END 3 */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  RCC_OscInitStruct.OscillatorType      = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState            = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue      = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState            = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState        = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource       = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL         = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK) { Error_Handler(); }

  RCC_ClkInitStruct.ClockType      = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK
                                   | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource   = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider  = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;
  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK) { Error_Handler(); }
}

/**
  * @brief CAN Initialization Function
  */
static void MX_CAN_Init(void)
{
  /* USER CODE BEGIN CAN_Init 0 */
  /* USER CODE END CAN_Init 0 */
  /* USER CODE BEGIN CAN_Init 1 */
  __HAL_RCC_AFIO_CLK_ENABLE();      /* Required for any pin remap on STM32F1 */
  __HAL_AFIO_REMAP_CAN1_2();        /* Remap CAN1 from PA11/PA12 to PB8/PB9 */
  /* USER CODE END CAN_Init 1 */
  hcan.Instance                = CAN1;
  hcan.Init.Prescaler          = 4;
  hcan.Init.Mode               = CAN_MODE_NORMAL;
  hcan.Init.SyncJumpWidth      = CAN_SJW_1TQ;
  hcan.Init.TimeSeg1           = CAN_BS1_13TQ;
  hcan.Init.TimeSeg2           = CAN_BS2_4TQ;
  hcan.Init.TimeTriggeredMode  = DISABLE;
  hcan.Init.AutoBusOff         = DISABLE;
  hcan.Init.AutoWakeUp         = DISABLE;
  hcan.Init.AutoRetransmission = ENABLE;
  hcan.Init.ReceiveFifoLocked  = DISABLE;
  hcan.Init.TransmitFifoPriority = DISABLE;
  if (HAL_CAN_Init(&hcan) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN CAN_Init 2 */
  /* USER CODE END CAN_Init 2 */
}

/**
  * @brief USART1 Initialization Function
  */
static void MX_USART1_UART_Init(void)
{
  /* USER CODE BEGIN USART1_Init 0 */
  /* USER CODE END USART1_Init 0 */
  /* USER CODE BEGIN USART1_Init 1 */
  /* USER CODE END USART1_Init 1 */
  huart1.Instance          = USART1;
  huart1.Init.BaudRate     = 9600;
  huart1.Init.WordLength   = UART_WORDLENGTH_8B;
  huart1.Init.StopBits     = UART_STOPBITS_1;
  huart1.Init.Parity       = UART_PARITY_NONE;
  huart1.Init.Mode         = UART_MODE_TX_RX;
  huart1.Init.HwFlowCtl    = UART_HWCONTROL_NONE;
  huart1.Init.OverSampling = UART_OVERSAMPLING_16;
  if (HAL_UART_Init(&huart1) != HAL_OK) { Error_Handler(); }
  /* USER CODE BEGIN USART1_Init 2 */
  /* USER CODE END USART1_Init 2 */
}

/**
  * @brief GPIO Initialization Function
  */
static void MX_GPIO_Init(void)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};

  __HAL_RCC_GPIOC_CLK_ENABLE();
  __HAL_RCC_GPIOD_CLK_ENABLE();
  __HAL_RCC_GPIOA_CLK_ENABLE();
  __HAL_RCC_GPIOB_CLK_ENABLE();

  HAL_GPIO_WritePin(GPIOC, GPIO_PIN_13, GPIO_PIN_RESET);

  GPIO_InitStruct.Pin   = GPIO_PIN_13;
  GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_PP;
  GPIO_InitStruct.Pull  = GPIO_NOPULL;
  GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
  HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);
}

/* USER CODE BEGIN 4 */
/* USER CODE END 4 */

void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  __disable_irq();
  while (1) { }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef USE_FULL_ASSERT
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* USER CODE END 6 */
}
#endif
